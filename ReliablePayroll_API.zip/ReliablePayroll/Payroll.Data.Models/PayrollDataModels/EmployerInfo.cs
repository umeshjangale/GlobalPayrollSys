﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EmployerInfo
    {
        [Key]
        public int EmployerInfoId { get; set; }

        public string LegalName { get; set; }

        public string LegalAddress1 { get; set; }

        public string LegalAddress2 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        public string Country { get; set; }

        public string BusinessPhone { get; set; }

        public string BusinessFax { get; set; }

        public bool SameAsLegalInfo { get; set; }

        public string BusinessName { get; set; }

        public string BusinessAddress1 { get; set; }

        public string BusinessAddress2 { get; set; }

        public string BusinessCity { get; set; }

        public string BusinessState { get; set; }

        public string BusinessZipCode { get; set; }

        public string BusinessCountry { get; set; }

        public string NAICSCode { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
    }
}