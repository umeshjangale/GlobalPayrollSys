﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EmployerEarning
    {
        [Key]
        public int EmployerEarningId { get; set; }

        public string UserId { get; set; }

        [ForeignKey("UserId")]
        public ApplicationUser ApplicationTenant { get; set; }

        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public EarningDeductionCategory EarningDeductionCategory { get; set; }

        public int EarningDeductionId { get; set; }

        [ForeignKey("EarningDeductionId")]
        public EarningDeduction EarningDeduction { get; set; }

        public string Description { get; set; }

        public bool W2Box14 { get; set; }

        public string W2Box14Literal { get; set; }

        public string Name { get; set; }

        public string WorksheetName { get; set; }

        public bool IsAmountEnabled { get; set; }

        public bool IsHoursEnabled { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
    }
}