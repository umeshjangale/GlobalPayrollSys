﻿using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class AccrualFrequency
    {
        [Key]
        public int AccrualFrequencyId { get; set; }

        public string AccrualFrequencyName { get; set; }

        public bool IsActive { get; set; }
    }
}