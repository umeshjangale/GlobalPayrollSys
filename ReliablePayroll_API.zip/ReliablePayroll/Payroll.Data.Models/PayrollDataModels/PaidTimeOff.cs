﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class PaidTimeOff
    {
        public long PaidTimeOffId { get; set; }

        public int TimeOffCategoryId { get; set; }

        [ForeignKey("TimeOffCategoryId")]
        public TimeOffCategory TimeOffCategory { get; set; }

        public int AccrualFrequencyId { get; set; }

        [ForeignKey("AccrualFrequencyId")]
        public AccrualFrequency AccrualFrequency { get; set; }

        public string Description { get; set; }

        public string HoursEarnedPerYear { get; set; }

        public string MaximumAvailable { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
    }
}