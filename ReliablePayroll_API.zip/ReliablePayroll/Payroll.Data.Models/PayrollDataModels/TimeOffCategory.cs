﻿using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class TimeOffCategory
    {
        [Key]
        public int TimeOffCategoryId { get; set; }

        public string TimeOffCategoryName { get; set; }

        public bool IsActive { get; set; }
    }
}