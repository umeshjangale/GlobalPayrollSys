﻿using Microsoft.AspNetCore.Identity;
using Payroll.Entities.PayrollEntity;
using System;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class ApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string SocialSecurityNumber { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public DateTime? HireDate { get; set; }

        public bool IsPersonalTaxInfoChecked { get; set; }

        public string GenderId { get; set; }

        public bool CompanyPaidPension { get; set; }

        public bool JobTaxCredit { get; set; }

        public bool StatutoryEmployee { get; set; }

        public string TIN { get; set; }

        public string CompanyName { get; set; }

        public bool IsContractor { get; set; }

        public bool IsAccessGiven { get; set; }

        public bool IsActive { get; set; }

        public EmployeeStatus EmployeeStatus { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
    }

    public class ApplicationRole : IdentityRole
    {
        public ApplicationRole() : base()
        {
        }

        public ApplicationRole(string name) : base(name)
        {
        }
    }
}