﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class TenantOtpInfo
    {
        [Key]
        public Guid OtpId { get; set; }

        public string OtpCode { get; set; }
        public bool IsActive { get; set; }
        public DateTime SentDateTine { get; set; }
        public string UserId { get; set; }

        [ForeignKey("UserId")]
        public ApplicationUser ApplicationTenant { get; set; }
    }
}