﻿using Payroll.Entities.PayrollEntity;
using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EmployerTaxInfo
    {
        [Key]
        public int TaxInfoId { get; set; }

        public string IncomeTaxState { get; set; }
        public string EIN { get; set; }
        public string StateUIN { get; set; }
        public DateTime EffectiveDate { get; set; }
        public decimal SUIRate { get; set; }

        //Is Company Exempt From Federal Unemployment Tax
        public bool IsCompanyExemptFromFUTA { get; set; }

        public bool IsEmployeeWorkingInThisState { get; set; }
        public string CompanyType { get; set; }    

        public DepositFrerquency DepositFrerquency { get; set; }

        public TaxType TaxType { get; set; }
        public string UserId { get; set; }

        public DateTime CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
    }
}