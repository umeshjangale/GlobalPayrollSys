﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EarningDeduction
    {
        [Key]
        public int EarningDeductionId { get; set; }        

        public string CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public EarningDeductionCategory EarningDeductionCategory { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
        
    }
}