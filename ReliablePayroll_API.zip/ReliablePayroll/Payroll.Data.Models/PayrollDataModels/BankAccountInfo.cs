﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class BankAccountInfo
    {
        [Key]
        public int BankAccountInfoId { get; set; }

        public bool ActivateEmpDirectDeposit { get; set; }

        public string Name { get; set; }

        public string RoutingNumber { get; set; }

        public string AccountNumber { get; set; }

        public bool IncludeEmpAddressOnCheck { get; set; }

        public string NameAndAddressOrTransitNumber { get; set; }

        public bool ShouldPrintOnCheck { get; set; }

        public bool PrintBusinessPhoneOnPayStube { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
    }
}