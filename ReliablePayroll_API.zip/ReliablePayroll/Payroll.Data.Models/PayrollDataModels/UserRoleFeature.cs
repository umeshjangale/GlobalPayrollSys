﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class UserRoleFeature
    {
        [Key]
        public int UserRoleFeatureId { get; set; }

        public Guid RoleId { get; set; }

        public int FeatureId { get; set; }
    }
}