﻿using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class TenantFeature
    {
        [Key]
        public int TenantFeatureId { get; set; }

        public int FeatureId { get; set; }

        public string FeatureName { get; set; }

        public string FeatureCode { get; set; }
    }
}