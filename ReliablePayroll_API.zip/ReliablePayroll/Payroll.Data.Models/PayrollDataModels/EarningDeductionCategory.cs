﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EarningDeductionCategory
    {
        [Key]
        public int CategoryId { get; set; }

        public string CategoryName { get; set; }
        
        public Type Type { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }
        
    }

    public enum Type
    {
        Earning = 0,
        Deduction = 1
    }
}