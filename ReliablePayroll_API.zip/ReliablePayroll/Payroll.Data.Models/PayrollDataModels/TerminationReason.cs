﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class TerminationReason
    {
        [Key]
        public int TerminationReasonId { get; set; }

        public string Reason { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
    }
}