﻿using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.PayrollDataModels
{
    public class EmployerContactInfo
    {
        [Key]
        public int ContactInformationId { get; set; }

        public string PayrollFirstName { get; set; }

        public string PayrollLastName { get; set; }

        public string PayrollTitle { get; set; }

        public string PayrollPhone { get; set; }

        public string PayrollExtension { get; set; }

        public string PayrollEmail { get; set; }

        public string BillingFirstName { get; set; }

        public string BillingLastName { get; set; }

        public string BillingTitle { get; set; }

        public string BillingPhone { get; set; }

        public string BillingExtension { get; set; }

        public string BillingEmail { get; set; }

        public bool IsActive { get; set; }
    }
}