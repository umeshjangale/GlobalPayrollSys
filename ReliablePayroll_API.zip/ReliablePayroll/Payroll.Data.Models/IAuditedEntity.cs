﻿using System;

namespace Payroll.Data.Models
{
    public interface IAuditedEntity
    {
        String Domain { get; }
        String DomainRefColumn { get; }
        string[] IgnorePropertyNames { get; }
    }
}