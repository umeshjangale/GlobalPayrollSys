﻿using System;

namespace Payroll.Data.Models
{
    public interface IAuditableEntity
    {
        DateTime CreatedDateTime { get; set; } // CreatedDateTimeUtc
        string CreatedBy { get; set; } // CreatedBy (length: 50)
        DateTime? UpdatedDateTime { get; set; } // UpdatedDateTimeUtc
        string UpdatedBy { get; set; } // UpdatedBy (length: 50)
    }
}