﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models
{
    public class AuditLog
    {
        [Key]
        public Guid AuditLogId { get; set; }

        public string AuditType { get; set; }

        public string TableName { get; set; }

        public string RefId { get; set; }

        public string ColumnName { get; set; }

        public string OldValue { get; set; }

        public string NewValue { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }
    }
}