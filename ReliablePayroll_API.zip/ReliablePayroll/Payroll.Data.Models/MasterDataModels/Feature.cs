﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.MasterDataModels
{
    public class Feature
    {
        [Key]
        public int FeatureId { get; set; }

        public string FeatureName { get; set; }

        public string FeatureCode { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime CreatedDateTime { get; set; }

        public DateTime? DisabledDateTime { get; set; }
    }
}