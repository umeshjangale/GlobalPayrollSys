﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.MasterDataModels
{
    public class SubscriptionFeature
    {
        [Key]
        public int SubscriptionFeatureId { get; set; }

        public Guid SubscriptionId { get; set; }

        [ForeignKey("SubscriptionId")]
        public Subscription Subscription { get; set; }

        public int FeatureId { get; set; }

        [ForeignKey("FeatureId")]
        public Feature Feature { get; set; }
    }
}