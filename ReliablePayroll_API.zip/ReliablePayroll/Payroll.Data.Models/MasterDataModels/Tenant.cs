﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.MasterDataModels
{
    public class Tenant
    {
        [Key]
        public Guid TenantId { get; set; }

        public string UserId { get; set; }

        [ForeignKey("UserId")]
        public ApplicationTenantUsers ApplicationTenantUsers { get; set; }

        public string ConnectionString { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? DisabledOn { get; set; }
    }
}