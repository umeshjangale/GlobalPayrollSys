﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payroll.Data.Models.MasterDataModels
{
    public class Subscription
    {
        [Key]
        public Guid SubscriptionId { get; set; }

        public string SubscriptionName { get; set; }
        public double Amount { get; set; }
        public bool IsActive { get; set; }
    }
}