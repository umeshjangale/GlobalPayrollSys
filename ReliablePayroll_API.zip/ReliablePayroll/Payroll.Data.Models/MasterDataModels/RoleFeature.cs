﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.MasterDataModels
{
    public class RoleFeature
    {
        [Key]
        public int RoleFeatureId { get; set; }

        public Guid RoleId { get; set; }

        public Guid SubscriptionId { get; set; }

        [ForeignKey("SubscriptionId")]
        public Subscription Subscription { get; set; }

        public int FeatureId { get; set; }

        [ForeignKey("FeatureId")]
        public Feature Feature { get; set; }

        public bool IsActive { get; set; }
    }
}