﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payroll.Data.Models.MasterDataModels
{
    public class CompanySubscription
    {
        [Key]
        public int CompanySubscriptionId { get; set; }

        public string UserId { get; set; }

        [ForeignKey("UserId")]
        public ApplicationTenantUsers ApplicationTenantUsers { get; set; }

        public Guid SubscriptionId { get; set; }

        [ForeignKey("SubscriptionId")]
        public Subscription SubscriptionInfo { get; set; }

        public Guid TenantId { get; set; }

        [ForeignKey("TenantId")]
        public Tenant Tenant { get; set; }

        public DateTime StartDateTime { get; set; }
        public DateTime? RenewDateTime { get; set; }
        public DateTime ExpiryDateTime { get; set; }
    }
}