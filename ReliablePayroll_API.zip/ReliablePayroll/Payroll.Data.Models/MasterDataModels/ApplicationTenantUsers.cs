﻿using Microsoft.AspNetCore.Identity;
using System;

namespace Payroll.Data.Models.MasterDataModels
{
    public class ApplicationTenantUsers : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public double NumberOfEmployees { get; set; }
        public string NatureOfBusiness { get; set; }
        public string CompanyCode { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CompanyCreatedDateTime { get; set; }
        public string CompanyCreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
        public int CompanyCodeIdentity { get; set; }
    }

    public class ApplicationTenantRoles : IdentityRole
    {
    }
}