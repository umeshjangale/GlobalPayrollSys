﻿using System;

namespace Payroll.Data.Models.MasterDataModels
{
    public class CompanyPayment
    {
        public Guid CompanyPaymentId { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public string PaymentSource { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string PaymentStatus { get; set; }
        public string ReferenceNumber { get; set; }
        public DateTime PaymentDate { get; set; }
        public bool IsRefund { get; set; }
        public DateTime? RefundPaymentDate { get; set; }
        public string RefundReferenceNumber { get; set; }
        public decimal RefundAmount { get; set; }
        public string RefundStatus { get; set; }
    }
}