﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext
{
    public abstract class MasterRepositoryBase<T> where T : class
    {
        #region Properties

        private readonly DbSet<T> dbSet;
        public MasterDbContext DbContext { get; private set; }
        internal IMapper Mapper { get; private set; }

        #endregion Properties

        protected MasterRepositoryBase(MasterDbContext dbContext, IMapper mapper)
        {
            DbContext = dbContext;
            dbSet = DbContext.Set<T>();
            Mapper = mapper;
        }

        #region Implementation

        public virtual async Task<T> AddAsync(T entity)
        {
            await dbSet.AddAsync(entity);
            return entity;
        }

        public virtual async Task AddRange(List<T> entities)
        {
            await dbSet.AddRangeAsync(entities);
        }

        public virtual Task Update(T entity)
        {
            dbSet.Attach(entity);
            DbContext.Entry(entity).State = EntityState.Modified;
            return Task.CompletedTask;
        }

        public virtual Task Delete(T entity)
        {
            dbSet.Remove(entity);
            return Task.CompletedTask;
        }

        public virtual void Delete(Expression<Func<T, bool>> where)
        {
            IEnumerable<T> objects = dbSet.Where<T>(where).AsEnumerable();
            foreach (T obj in objects)
                dbSet.Remove(obj);
        }

        public virtual async Task<T> GetByIdAsync(object id)
        {
            return await dbSet.FindAsync(id);
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await dbSet.ToListAsync();
        }

        public virtual IEnumerable<T> GetMany(Expression<Func<T, bool>> where)
        {
            return dbSet.Where(where).ToList();
        }

        public T Get(Expression<Func<T, bool>> where)
        {
            return dbSet.Where(where).FirstOrDefault<T>();
        }

        public R Get<R>(Expression<Func<T, bool>> where) where R : class
        {
            return dbSet
            .Where(where)
            .AsNoTracking()
            .ProjectTo<R>(Mapper.ConfigurationProvider)
            .FirstOrDefault();
        }

        public List<R> GetAll<R>() where R : class
        {
            return dbSet
            .AsNoTracking()
            .ProjectTo<R>(Mapper.ConfigurationProvider)
            .ToList();
        }

        #endregion Implementation
    }
}