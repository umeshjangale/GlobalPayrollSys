﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.MasterContext.Contracts;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Entities.Constants;
using Payroll.Entities.MasterEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext.Repository
{
    public class MasterRepository : MasterRepositoryBase<ApplicationTenantUsers>, IMasterRepository
    {
        private readonly MasterDbContext masterDbContext;
        private readonly RoleManager<IdentityRole> roleManager;

        public MasterRepository(MasterDbContext masterDbContext, IMapper mapper,
            RoleManager<IdentityRole> roleManager) : base(masterDbContext, mapper)
        {
            this.masterDbContext = masterDbContext;
            this.roleManager = roleManager;
        }

        public async Task<Subscription> GetSubscriptionInfoAsync(Guid subscriptionId) =>
            await masterDbContext.Subscription.Where(t => t.SubscriptionId == subscriptionId).FirstOrDefaultAsync();

        public async Task<IEnumerable<Subscription>> GetSubscriptionAsync() =>
           await masterDbContext.Subscription.Where(x => x.IsActive).ToListAsync();

        public async Task<OtpInfo> GetOtpAsync(string userId)
        {
            return await masterDbContext.OtpInfo.Where(x => x.UserId == userId && x.IsActive).FirstOrDefaultAsync();
        }

        public async Task AddOtpAsync(OtpInfo otpInfo)
        {
            await masterDbContext.OtpInfo.AddAsync(otpInfo);
        }

        public Task UpdateOtp(OtpInfo otpInfo)
        {
            masterDbContext.OtpInfo.Update(otpInfo);
            return Task.CompletedTask;
        }

        public async Task InActiveUserOtpAsync(string userId)
        {
            var otp = masterDbContext.OtpInfo.Where(it => it.UserId == userId && it.IsActive);
            if (otp.Count() > 0)
                await otp.ForEachAsync(it => it.IsActive = false);
            await masterDbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<Feature>> GetFeaturesBySubscriptionIdAsync(Guid subscriptionId)
        {
            return await masterDbContext.SubscriptionFeatures
                     .Include(it => it.Feature)
                     .Where(it => it.SubscriptionId == subscriptionId && it.Feature.IsActive)
                     .Select(it => it.Feature)
                     .ToListAsync();
        }

        public async Task<IEnumerable<RoleFeature>> GetRoleFeaturesBySubscriptionIdAsync(Guid subscriptionId)
        {
            return await masterDbContext.RoleFeatures
                     .Include(it => it.Feature)
                     .Where(it => it.SubscriptionId == subscriptionId && it.Feature.IsActive)
                     .Select(it => it)
                     .ToListAsync();
        }

        public async Task<IEnumerable<IdentityRole>> GetRolesAsync() =>
           await roleManager.Roles.ToListAsync();

        public async Task<bool> CheckCompanyCodeExistAsync(string companyCode)
        {
            return await masterDbContext.Users.AnyAsync(t => t.CompanyCode == companyCode);
        }

        public async Task<IEnumerable<Feature>> GetFeaturesBySubscriptionAndRoleAsync(Guid subscriptionId, Guid roleId)
        {
            return await masterDbContext.RoleFeatures
                .Include(it => it.Feature)
                .Where(it => it.SubscriptionId == subscriptionId && it.RoleId == roleId && it.Feature.IsActive)
                .Select(it => it.Feature)
                .ToListAsync();
        }

        public async Task<IEnumerable<string>> GetFeaturesByRoleAsync(Guid roleId)
        {
            return await masterDbContext.RoleFeatures
                     .Include(it => it.Feature)
                     .Where(it => it.RoleId == roleId && it.Feature.IsActive)
                     .Select(it => it.Feature.FeatureName).ToListAsync();
        }

        public async Task<int> GetCompanyCodeIdentity()
        {
            return await masterDbContext.Users.MaxAsync(m => m.CompanyCodeIdentity) + 1;
        }

        public async Task<List<ApplicationTenantUsers>> GetEmployerAsync(EmployerSearchModel employerSearchModel)
        {

            var employers = from employer in masterDbContext.Users
                            join userrole in masterDbContext.UserRoles on employer.Id equals userrole.UserId
                            join role in masterDbContext.Roles on userrole.RoleId equals role.Id
                            where employer.IsActive == employerSearchModel.EmployeeStatus && role.Name == Roles.Employer
                            select employer;

            if (!string.IsNullOrEmpty(employerSearchModel.EmployerName))
                employers = employers.Where(m => !string.IsNullOrEmpty(m.CompanyName) && m.CompanyName.StartsWith(employerSearchModel.EmployerName));

            if (employerSearchModel.NoOfEmployeeFrom > 0)
                employers = employers.Where(m => m.NumberOfEmployees >= employerSearchModel.NoOfEmployeeFrom);

            if (employerSearchModel.NoOfEmployeeTo > 0)
                employers = employers.Where(m => m.NumberOfEmployees <= employerSearchModel.NoOfEmployeeTo);

            return await employers.ToListAsync();
        }

    }
}