﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.MasterContext.Contracts;
using Payroll.Data.Models.MasterDataModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext.Repository
{
    public class TenantDetailsRepository : MasterRepositoryBase<Tenant>, ITenantDetailsRepository
    {
        private readonly MasterDbContext masterDbContext;
        private readonly IMapper mapper;

        public TenantDetailsRepository(MasterDbContext masterDbContext, IMapper mapper) : base(masterDbContext, mapper)
        {
            this.masterDbContext = masterDbContext;
            this.mapper = mapper;
        }

        public async Task AddCompanySubscriptionDetails(CompanySubscription companySubscrptionInfo) =>
            await masterDbContext.CompanySubscriptionInfoes.AddAsync(companySubscrptionInfo);

        public async Task<CompanySubscription> GetCompanySubscriptionByUserId(string userId) =>
           await masterDbContext.CompanySubscriptionInfoes.Where(t => t.UserId == userId).FirstOrDefaultAsync();

        public async Task AddPaymentStatusAsync(CompanyPayment companyPayment)
        {
            await masterDbContext.CompanyPayments.AddAsync(companyPayment);
        }

        public Task UpdatePaymentStatusAsync(CompanyPayment companyPayment)
        {
            masterDbContext.CompanyPayments.Update(companyPayment);
            return Task.CompletedTask;
        }

        public async Task<IEnumerable<CompanyPayment>> GetPaymentAsync() =>
           await masterDbContext.CompanyPayments.ToListAsync();
    }
}