﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models;
using Payroll.Data.Models.MasterDataModels;

namespace Payroll.Data.MasterContext
{
    public class MasterDbContext : IdentityDbContext<ApplicationTenantUsers>
    {
        public MasterDbContext(DbContextOptions<MasterDbContext> options) : base(options)
        {
        }

        public DbSet<Subscription> Subscription { get; set; }

        public DbSet<CompanySubscription> CompanySubscriptionInfoes { get; set; }
        public DbSet<RoleFeature> RoleFeatures { get; set; }
        public DbSet<OtpInfo> OtpInfo { get; set; }
        public DbSet<Tenant> Tenants { get; set; }
        public DbSet<Feature> Features { get; set; }
        public DbSet<SubscriptionFeature> SubscriptionFeatures { get; set; }
        public DbSet<AuditLog> AuditLog { get; set; }
        public DbSet<CompanyPayment> CompanyPayments { get; set; }
    }
}