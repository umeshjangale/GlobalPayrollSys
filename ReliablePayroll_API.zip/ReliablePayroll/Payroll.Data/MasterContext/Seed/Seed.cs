﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.MasterContext;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Entities.Constants;
using Payroll.Entities.MasterEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.Seed
{
    public class Seed : ISeeder
    {
        private readonly MasterDbContext masterDbContext;
        private readonly UserManager<ApplicationTenantUsers> userManager;
        private readonly RoleManager<IdentityRole> roleManager;

        private readonly IMapper mapper;

        public Seed(MasterDbContext masterDbContext, UserManager<ApplicationTenantUsers> userManager,
            RoleManager<IdentityRole> roleManager, IMapper mapper)
        {
            this.masterDbContext = masterDbContext;
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.mapper = mapper;
        }

        private async Task SeedDefaultUserAsync()
        {
            if (masterDbContext.Roles.Any(r => r.Name == Roles.Admin)) return;

            await roleManager.CreateAsync(new IdentityRole(Roles.Admin));
            await roleManager.CreateAsync(new IdentityRole(Roles.Employee));
            await roleManager.CreateAsync(new IdentityRole(Roles.Employer));

            await userManager.CreateAsync(new ApplicationTenantUsers
            {
                UserName = "admin@gmail.com",
                FirstName = "Admin",
                LastName = "Admin",
                Email = "admin@gmail.com",
                EmailConfirmed = true,
                PhoneNumber = "1234567890",
                IsActive = true
            }, "Admin@123");

            ApplicationTenantUsers user = await userManager.FindByNameAsync("admin@gmail.com");

            await userManager.AddToRoleAsync(user, Roles.Admin);
        }

        public async Task AddMigrationAsync()
        {
            await masterDbContext.Database.MigrateAsync();

            await SeedDefaultUserAsync();

            await SeedSubscriptionAsync();

            await FeatureSeedingAsync();

            await SubscrptionFeatureSeedingAsync();

            await RoleFeatureSeedingAsync();
        }

        private async Task SeedSubscriptionAsync()
        {
            if (masterDbContext.Subscription.Any()) return;

            await masterDbContext.Subscription.AddAsync(
                new Subscription
                {
                    SubscriptionName = Subscriptions.CorePlan,
                    IsActive = true,
                    Amount = 1200
                });

            await masterDbContext.Subscription.AddAsync(
                new Subscription
                {
                    SubscriptionName = Subscriptions.CompletePlan,
                    IsActive = true,
                    Amount = 1500
                });
            await masterDbContext.SaveChangesAsync();
        }

        private async Task FeatureSeedingAsync()
        {
            if (masterDbContext.Features.Any()) return;

            var features = mapper.Map<IEnumerable<FeatureListModel>, IEnumerable<Feature>>(FeaturModel.GetFeatureList());
            await masterDbContext.Features.AddRangeAsync(features);
            await masterDbContext.SaveChangesAsync();
        }

        private async Task SubscrptionFeatureSeedingAsync()
        {
            if (masterDbContext.SubscriptionFeatures.Any()) return;

            Subscription corePlanId = await masterDbContext.Subscription.Where(sub => sub.SubscriptionName == Subscriptions.CorePlan).FirstOrDefaultAsync();
            Subscription completePlanId = await masterDbContext.Subscription.Where(sub => sub.SubscriptionName == Subscriptions.CompletePlan).FirstOrDefaultAsync();
            List<Feature> features = masterDbContext.Features.ToList();
            List<SubscriptionFeature> featurelist = new List<SubscriptionFeature>();
            SubscriptionFeature coreFeatures;
            foreach (var data in features)
            {
                if (data.FeatureId <= 10)
                {
                    coreFeatures = new SubscriptionFeature
                    {
                        SubscriptionId = corePlanId.SubscriptionId,
                        FeatureId = data.FeatureId
                    };
                    featurelist.Add(coreFeatures);
                }
                if (data.FeatureId <= 14)
                {
                    coreFeatures = new SubscriptionFeature
                    {
                        SubscriptionId = completePlanId.SubscriptionId,
                        FeatureId = data.FeatureId
                    };
                    featurelist.Add(coreFeatures);
                }
            }
            await masterDbContext.SubscriptionFeatures.AddRangeAsync(featurelist);
            await masterDbContext.SaveChangesAsync();
        }

        private async Task RoleFeatureSeedingAsync()
        {
            if (masterDbContext.RoleFeatures.Any()) return;

            IEnumerable<IdentityRole> roles = await roleManager.Roles.ToListAsync();
            Subscription corePlanId = await masterDbContext.Subscription.Where(sub => sub.SubscriptionName == Subscriptions.CorePlan).FirstOrDefaultAsync();
            Subscription completePlanId = await masterDbContext.Subscription.Where(sub => sub.SubscriptionName == Subscriptions.CompletePlan).FirstOrDefaultAsync();
            List<Feature> features = masterDbContext.Features.ToList();
            List<RoleFeature> featurelist = new List<RoleFeature>();
            Guid roleIdEmpoyer = Guid.Parse(roles.FirstOrDefault(it => it.Name == Roles.Employer).Id);
            Guid roleIdEmpoyee = Guid.Parse(roles.FirstOrDefault(it => it.Name == Roles.Employee).Id);
            RoleFeature coreFeatures;
            foreach (var data in features)
            {
                if (data.FeatureId <= 10)
                {
                    coreFeatures = new RoleFeature
                    {
                        RoleId = roleIdEmpoyer,
                        SubscriptionId = corePlanId.SubscriptionId,
                        FeatureId = data.FeatureId,
                        IsActive = true
                    };
                    featurelist.Add(coreFeatures);
                }
                if (data.FeatureId <= 14)
                {
                    coreFeatures = new RoleFeature
                    {
                        RoleId = roleIdEmpoyer,
                        SubscriptionId = completePlanId.SubscriptionId,
                        FeatureId = data.FeatureId,
                        IsActive = true
                    };
                    featurelist.Add(coreFeatures);
                }
                //Employee
                if (data.FeatureId.Equals(11) || data.FeatureId.Equals(12) || data.FeatureId.Equals(13) || data.FeatureId.Equals(14))
                {
                    coreFeatures = new RoleFeature
                    {
                        RoleId = roleIdEmpoyee,
                        SubscriptionId = corePlanId.SubscriptionId,
                        FeatureId = data.FeatureId,
                        IsActive = true
                    };
                    featurelist.Add(coreFeatures);
                }
                if (data.FeatureId.Equals(11) || data.FeatureId.Equals(12) || data.FeatureId.Equals(13) || data.FeatureId.Equals(14))
                {
                    coreFeatures = new RoleFeature
                    {
                        RoleId = roleIdEmpoyee,
                        SubscriptionId = completePlanId.SubscriptionId,
                        FeatureId = data.FeatureId,
                        IsActive = true
                    };
                    featurelist.Add(coreFeatures);
                }
            }
            await masterDbContext.RoleFeatures.AddRangeAsync(featurelist);
            await masterDbContext.SaveChangesAsync();
        }
    }
}