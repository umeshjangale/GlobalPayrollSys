﻿using System.Threading.Tasks;

namespace Payroll.Data.Seed
{
    public interface ISeeder
    {
        Task AddMigrationAsync();
    }
}