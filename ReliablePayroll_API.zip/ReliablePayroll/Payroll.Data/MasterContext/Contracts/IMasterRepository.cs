﻿using Microsoft.AspNetCore.Identity;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Entities.MasterEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext.Contracts
{
    public interface IMasterRepository : IRepository<ApplicationTenantUsers>
    {
        Task<Subscription> GetSubscriptionInfoAsync(Guid subscriptionId);

        Task<IEnumerable<Subscription>> GetSubscriptionAsync();

        Task<OtpInfo> GetOtpAsync(string userId);

        Task AddOtpAsync(OtpInfo masterOtpDetails);

        Task UpdateOtp(OtpInfo masterOtpDetails);

        Task InActiveUserOtpAsync(string userId);

        Task<IEnumerable<Feature>> GetFeaturesBySubscriptionIdAsync(Guid subscriptionId);

        Task<IEnumerable<IdentityRole>> GetRolesAsync();

        Task<bool> CheckCompanyCodeExistAsync(string companyCode);

        Task<IEnumerable<Feature>> GetFeaturesBySubscriptionAndRoleAsync(Guid subscriptionId, Guid roleId);

        Task<IEnumerable<RoleFeature>> GetRoleFeaturesBySubscriptionIdAsync(Guid subscriptionId);

        Task<IEnumerable<string>> GetFeaturesByRoleAsync(Guid roleId);

        Task<int> GetCompanyCodeIdentity();

        Task<List<ApplicationTenantUsers>> GetEmployerAsync(EmployerSearchModel employerSearchModel);
    }
}