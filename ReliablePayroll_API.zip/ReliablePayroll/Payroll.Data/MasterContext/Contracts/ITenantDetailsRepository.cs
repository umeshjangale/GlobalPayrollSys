﻿using Payroll.Data.Models.MasterDataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext.Contracts
{
    public interface ITenantDetailsRepository : IRepository<Tenant>
    {
        Task AddCompanySubscriptionDetails(CompanySubscription tenantSubscriptionDetails);

        Task<CompanySubscription> GetCompanySubscriptionByUserId(string userId);

        Task AddPaymentStatusAsync(CompanyPayment companyPayment);

        Task UpdatePaymentStatusAsync(CompanyPayment companyPayment);

        Task<IEnumerable<CompanyPayment>> GetPaymentAsync();
    }
}