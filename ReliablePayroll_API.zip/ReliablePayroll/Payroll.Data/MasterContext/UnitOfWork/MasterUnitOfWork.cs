﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Payroll.Data.IdentityRepository;
using Payroll.Data.MasterContext.Contracts;
using Payroll.Data.MasterContext.Repository;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Entities.Login;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.MasterContext.UnitOfWork
{
    public class MasterUnitOfWork : IMasterUnitOfWork
    {
        private readonly MasterDbContext masterDbContext;
        private readonly IMapper mapper;
        private readonly UserManager<ApplicationTenantUsers> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private IMasterRepository masterUserRepository;
        private ITenantDetailsRepository tenantDetailsRepository;
        private IIdentityUserRepository<ApplicationTenantUsers> identityUsers;
        private readonly ServerSettings serverSettings;
        private readonly IHttpContextAccessor httpContextAccessor;

        public MasterUnitOfWork(MasterDbContext masterDbContext, IMapper mapper, UserManager<ApplicationTenantUsers> userManager,
            RoleManager<IdentityRole> roleManager, IOptions<ServerSettings> serverSettings, IHttpContextAccessor httpContextAccessor)
        {
            this.masterDbContext = masterDbContext;
            this.mapper = mapper;
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.serverSettings = serverSettings.Value;
            this.httpContextAccessor = httpContextAccessor;
        }

        public IMasterRepository MasterUsersRepository
        {
            get
            {
                if (masterUserRepository == null)
                {
                    masterUserRepository = new MasterRepository(masterDbContext, mapper, roleManager);
                }
                return masterUserRepository;
            }
        }

        public ITenantDetailsRepository TenantDetailsRepository
        {
            get
            {
                if (tenantDetailsRepository == null)
                {
                    tenantDetailsRepository = new TenantDetailsRepository(masterDbContext, mapper);
                }
                return tenantDetailsRepository;
            }
        }

        public IIdentityUserRepository<ApplicationTenantUsers> IdentityUsersRepository
        {
            get
            {
                if (identityUsers == null)
                {
                    identityUsers = new IdentityUserRepository<ApplicationTenantUsers>(userManager, roleManager, null);
                }
                return identityUsers;
            }
        }

        public async Task SaveChangesAsync()
        {
            await masterDbContext.SaveChangesAsync();
        }

        public void SaveChanges()
        {
            AuditLogEntries auditLogEntries = new AuditLogEntries(masterDbContext, httpContextAccessor.HttpContext.User.Identity.Name);
            auditLogEntries.SetAuditableFields();
            var retryEntities = auditLogEntries.LogAuditEntries();
            if (retryEntities.Any())
            {
                masterDbContext.SaveChanges();
                auditLogEntries.LogAuditEntries(retryEntities, true);
                masterDbContext.SaveChanges();
            }
            else
            {
                masterDbContext.SaveChanges();
            }
        }
    }
}