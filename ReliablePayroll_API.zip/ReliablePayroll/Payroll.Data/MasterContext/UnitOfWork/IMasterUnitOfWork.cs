﻿using Payroll.Data.MasterContext.Contracts;
using Payroll.Data.Models.MasterDataModels;

namespace Payroll.Data.MasterContext.UnitOfWork
{
    public interface IMasterUnitOfWork : IUnitOfWork<ApplicationTenantUsers>
    {
        IMasterRepository MasterUsersRepository { get; }
        ITenantDetailsRepository TenantDetailsRepository { get; }
    }
}