﻿using Microsoft.AspNetCore.Identity;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Utils.Exceptions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Data.IdentityRepository
{
    public class IdentityUserRepository<T> : IIdentityUserRepository<T> where T : class
    {
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly RoleManager<ApplicationRole> tenantRoleManager;
        private readonly UserManager<T> userManager;

        public IdentityUserRepository(UserManager<T> userManager, RoleManager<IdentityRole> roleManager,
            RoleManager<ApplicationRole> tenantRoleManager)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
            this.tenantRoleManager = tenantRoleManager;
        }

        public async Task<IdentityResult> CreateUserAsync(T user, string password = null)
        {
            if (!String.IsNullOrEmpty(password))
                return await userManager.CreateAsync(user, password);
            else
                return await userManager.CreateAsync(user);
        }

        public async Task<T> FindUserByNameAsync(string UserName)
        {
            var user = await userManager.FindByNameAsync(UserName);
            if (user == null)
            {
                throw new ServiceException(HttpStatusCode.Unauthorized, "UserNotFound");
            }
            return user;
        }

        public async Task<IEnumerable<T>> GetUsersInRoleAsync(string Role)
        {
            return await userManager.GetUsersInRoleAsync(Role);
        }

        public async Task<T> IsUserExistAsync(string UserName)
        {
            return await userManager.FindByNameAsync(UserName);
        }

        public async Task AddUserToRoleAsync(T user, string role) =>
            await userManager.AddToRoleAsync(user, role);

        public async Task AddUserToRolesAsync(T user, IEnumerable<string> roles) =>
            await userManager.AddToRolesAsync(user, roles);

        public async Task<T> FindUserByEmailAsync(string Email) =>
            await userManager.FindByEmailAsync(Email);

        public async Task<bool> CheckUserPasswordAsync(T User, string Password) =>
            await userManager.CheckPasswordAsync(User, Password);

        public async Task<IEnumerable<string>> GetUserRolesAsync(T user) =>
            await userManager.GetRolesAsync(user);

        public async Task<IdentityResult> ChangeUserPasswordAsync(string userName, string currentPassword, string newPassword)
        {
            var user = await userManager.FindByNameAsync(userName);
            if (user == null)
                throw new ServiceException(HttpStatusCode.NotFound, "UserNotFound");
            return await userManager.ChangePasswordAsync(user, currentPassword, newPassword);
        }

        public async Task<bool> ResetUserPasswordAsync(T user, string newPassword)
        {
            if (await userManager.HasPasswordAsync(user))
                await userManager.RemovePasswordAsync(user);

            var result = await userManager.AddPasswordAsync(user, newPassword);
            return result.Succeeded;
        }

        public async Task AddRoleAsync(string role)
        {
            await roleManager.CreateAsync(new IdentityRole(role));
        }

        public async Task AddTenantRoleAsync(string role)
        {
            await tenantRoleManager.CreateAsync(new ApplicationRole(role));
        }

        public async Task<ApplicationRole> FindTenantRoleByNameAsync(string roleName) =>
           await tenantRoleManager.FindByNameAsync(roleName);

        public async Task<IdentityRole> FindRoleByNameAsync(string roleName) =>
           await roleManager.FindByNameAsync(roleName);
    }
}