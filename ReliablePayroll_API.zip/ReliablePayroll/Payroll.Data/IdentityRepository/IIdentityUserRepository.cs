﻿using Microsoft.AspNetCore.Identity;
using Payroll.Data.Models.PayrollDataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.IdentityRepository
{
    public interface IIdentityUserRepository<T> where T : class
    {
        Task<IdentityResult> CreateUserAsync(T user, string password = null);

        Task<bool> CheckUserPasswordAsync(T applicationUser, string password);

        Task<T> FindUserByNameAsync(string userName);

        Task<IEnumerable<string>> GetUserRolesAsync(T applicationUser);

        Task<IdentityResult> ChangeUserPasswordAsync(string userName, string currentPassword, string newPassword);

        Task<bool> ResetUserPasswordAsync(T user, string newPassword);

        Task AddUserToRoleAsync(T user, string role);

        Task AddUserToRolesAsync(T user, IEnumerable<string> roles);

        Task AddRoleAsync(string role);

        Task AddTenantRoleAsync(string role);

        Task<T> IsUserExistAsync(string UserName);

        Task<IEnumerable<T>> GetUsersInRoleAsync(string Role);

        Task<ApplicationRole> FindTenantRoleByNameAsync(string roleName);

        Task<IdentityRole> FindRoleByNameAsync(string roleName);
    }
}