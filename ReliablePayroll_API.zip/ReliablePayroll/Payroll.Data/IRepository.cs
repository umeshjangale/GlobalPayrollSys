﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data
{
    public interface IRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllAsync();

        Task<T> AddAsync(T entity);

        Task Update(T entity);

        Task Delete(T entity);

        Task<T> GetByIdAsync(object id);
    }
}