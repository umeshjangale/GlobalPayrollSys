﻿using AutoMapper;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.PayrollEntity;

namespace Payroll.Data.AutoMapper
{
    public class PayrollDbMappingProfile : Profile
    {
        public PayrollDbMappingProfile()
        {
            CreateMap<EmployerInfo, EmployerInfoEntity>()
                .ForMember(des => des.EmployerInfoId, opt => opt.MapFrom(src => src.EmployerInfoId))
                .ForMember(des => des.LegalName, opt => opt.MapFrom(src => src.LegalName))
                .ForMember(des => des.LegalAddress1, opt => opt.MapFrom(src => src.LegalAddress1))
                .ForMember(des => des.LegalAddress2, opt => opt.MapFrom(src => src.LegalAddress2))
                .ForMember(des => des.City, opt => opt.MapFrom(src => src.City))
                .ForMember(des => des.State, opt => opt.MapFrom(src => src.State))
                .ForMember(des => des.ZipCode, opt => opt.MapFrom(src => src.ZipCode))
                .ForMember(des => des.Country, opt => opt.MapFrom(src => src.Country))
                .ForMember(des => des.BusinessPhone, opt => opt.MapFrom(src => src.BusinessPhone))
                .ForMember(des => des.BusinessFax, opt => opt.MapFrom(src => src.BusinessFax))
                .ForMember(des => des.SameAsLegalInfo, opt => opt.MapFrom(src => src.SameAsLegalInfo))
                .ForMember(des => des.BusinessName, opt => opt.MapFrom(src => src.BusinessName))
                .ForMember(des => des.BusinessAddress1, opt => opt.MapFrom(src => src.BusinessAddress1))
                .ForMember(des => des.BusinessAddress2, opt => opt.MapFrom(src => src.BusinessAddress2))
                .ForMember(des => des.BusinessCity, opt => opt.MapFrom(src => src.BusinessCity))
                .ForMember(des => des.BusinessState, opt => opt.MapFrom(src => src.BusinessState))
                .ForMember(des => des.BusinessZipCode, opt => opt.MapFrom(src => src.BusinessZipCode))
                .ForMember(des => des.BusinessCountry, opt => opt.MapFrom(src => src.BusinessCountry))
                .ForMember(des => des.NAICSCode, opt => opt.MapFrom(src => src.NAICSCode))
                .ReverseMap();

            CreateMap<LoggedInUserEntity, ApplicationUser>()
                .ForMember(des => des.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(des => des.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(des => des.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(des => des.Email, opt => opt.MapFrom(src => src.Email))
                .ReverseMap();

            CreateMap<PayFrequency, PayFrequencyEntity>()
               .ForMember(des => des.PayFrequencyId, opt => opt.MapFrom(src => src.PayFrequencyId))
               .ForMember(des => des.PayFrequencyType, opt => opt.MapFrom(src => src.PayFrequencyType))
               .ForMember(des => des.CheckDate, opt => opt.MapFrom(src => src.CheckDate))
               .ForMember(des => des.StartDate, opt => opt.MapFrom(src => src.StartDate))
               .ForMember(des => des.EndDate, opt => opt.MapFrom(src => src.EndDate))
               .ReverseMap();

            CreateMap<EmployerContactInfo, EmployerContactInfoEntity>()
               .ForMember(des => des.ContactInformationId, opt => opt.MapFrom(src => src.ContactInformationId))
               .ForMember(des => des.PayrollFirstName, opt => opt.MapFrom(src => src.PayrollFirstName))
               .ForMember(des => des.PayrollLastName, opt => opt.MapFrom(src => src.PayrollLastName))
               .ForMember(des => des.PayrollTitle, opt => opt.MapFrom(src => src.PayrollTitle))
               .ForMember(des => des.PayrollPhone, opt => opt.MapFrom(src => src.PayrollPhone))
               .ForMember(des => des.PayrollExtension, opt => opt.MapFrom(src => src.PayrollExtension))
               .ForMember(des => des.PayrollEmail, opt => opt.MapFrom(src => src.PayrollEmail))
               .ForMember(des => des.BillingFirstName, opt => opt.MapFrom(src => src.BillingFirstName))
               .ForMember(des => des.BillingLastName, opt => opt.MapFrom(src => src.BillingLastName))
               .ForMember(des => des.BillingTitle, opt => opt.MapFrom(src => src.BillingTitle))
               .ForMember(des => des.BillingPhone, opt => opt.MapFrom(src => src.BillingPhone))
               .ForMember(des => des.BillingExtension, opt => opt.MapFrom(src => src.BillingExtension))
               .ForMember(des => des.BillingEmail, opt => opt.MapFrom(src => src.BillingEmail))
               .ReverseMap();

            CreateMap<BankAccountInfo, BankAccountInfoEntity>()
               .ForMember(des => des.BankAccountInfoId, opt => opt.MapFrom(src => src.BankAccountInfoId))
               .ForMember(des => des.ActivateEmpDirectDeposit, opt => opt.MapFrom(src => src.ActivateEmpDirectDeposit))
               .ForMember(des => des.Name, opt => opt.MapFrom(src => src.Name))
               .ForMember(des => des.RoutingNumber, opt => opt.MapFrom(src => src.RoutingNumber))
               .ForMember(des => des.AccountNumber, opt => opt.MapFrom(src => src.AccountNumber))
               .ForMember(des => des.IncludeEmpAddressOnCheck, opt => opt.MapFrom(src => src.IncludeEmpAddressOnCheck))
               .ForMember(des => des.NameAndAddressOrTransitNumber, opt => opt.MapFrom(src => src.NameAndAddressOrTransitNumber))
               .ForMember(des => des.ShouldPrintOnCheck, opt => opt.MapFrom(src => src.ShouldPrintOnCheck))
               .ForMember(des => des.PrintBusinessPhoneOnPayStube, opt => opt.MapFrom(src => src.PrintBusinessPhoneOnPayStube))
               .ReverseMap();

            CreateMap<Termination, TerminationEntity>()
              .ForMember(des => des.TerminationId, opt => opt.MapFrom(src => src.TerminationId))
              .ForMember(des => des.TerminationReason, opt => opt.MapFrom(src => src.TerminationReason))
              .ForMember(des => des.TerminationDate, opt => opt.MapFrom(src => src.TerminationDate))
              .ForMember(des => des.LastDateOfWork, opt => opt.MapFrom(src => src.LastDateOfWork))
              .ForMember(des => des.LengthOfService, opt => opt.MapFrom(src => src.LengthOfService))
              .ReverseMap();

            CreateMap<TerminationReason, TerminationReasonEntity>()
             .ForMember(des => des.TerminationReasonId, opt => opt.MapFrom(src => src.TerminationReasonId))
             .ForMember(des => des.Reason, opt => opt.MapFrom(src => src.Reason))
             .ReverseMap();

            CreateMap<EmployeeEntityModel, ApplicationUser>()
                .ForMember(des => des.FirstName, opts => opts.MapFrom(src => src.FirstName))
                .ForMember(des => des.MiddleName, opts => opts.MapFrom(src => src.MiddleName))
                .ForMember(des => des.LastName, opts => opts.MapFrom(src => src.LastName))
                .ForMember(des => des.SocialSecurityNumber, opts => opts.MapFrom(src => src.SocialSecurityNumber))
                .ForMember(des => des.DateOfBirth, opts => opts.MapFrom(src => src.DateOfBirth))
                .ForMember(des => des.Email, opts => opts.MapFrom(src => src.EmailAddress))
                .ForMember(des => des.HireDate, opts => opts.MapFrom(src => src.HireDate))
                .ForMember(des => des.IsPersonalTaxInfoChecked, opts => opts.MapFrom(src => src.IsPersonalTaxInfoChecked))
                .ForMember(des => des.UserName, opts => opts.MapFrom(src => src.EmailAddress))
                .ForMember(des => des.TIN, opts => opts.MapFrom(src => src.TIN))
                .ForMember(des => des.CompanyName, opts => opts.MapFrom(src => src.CompanyName))
                .ReverseMap();

            CreateMap<WorkContact, WorkContactEntity>()
                .ForMember(des => des.WorkContactId, opts => opts.MapFrom(src => src.WorkContactId))
                .ForMember(des => des.StateId, opts => opts.MapFrom(src => src.StateId))
                .ForMember(des => des.AddressLine1, opts => opts.MapFrom(src => src.AddressLine1))
                .ForMember(des => des.AddressLine2, opts => opts.MapFrom(src => src.AddressLine2))
                .ForMember(des => des.WorkEmail, opts => opts.MapFrom(src => src.WorkEmail))
                .ForMember(des => des.WorkPhoneNumber, opts => opts.MapFrom(src => src.WorkPhoneNumber))
                .ForMember(des => des.ZipCode, opts => opts.MapFrom(src => src.ZipCode))
                .ForMember(des => des.City, opts => opts.MapFrom(src => src.City))
                .ForMember(des => des.UserId, opts => opts.MapFrom(src => src.UserId))
                .ReverseMap();

            CreateMap<CountryEntity, Country>()
               .ForMember(des => des.CountryId, opt => opt.MapFrom(it => it.CountryId))
               .ForMember(des => des.CountryName, opt => opt.MapFrom(it => it.Name))
               .ForMember(des => des.CountryCode, opt => opt.MapFrom(it => it.CountryCode))
               .ReverseMap();

            CreateMap<StateEntity, State>()
                .ForMember(des => des.StateId, opt => opt.MapFrom(it => it.StateId))
                .ForMember(des => des.StateName, opt => opt.MapFrom(it => it.Name))
                .ForMember(des => des.StateCode, opt => opt.MapFrom(it => it.StateCode))
                .ForMember(des => des.CountryId, opt => opt.MapFrom(it => it.CountryId))
                .ReverseMap();

            CreateMap<UserContactEntity, UserContact>()
               .ForMember(des => des.UserContactId, opts => opts.MapFrom(src => src.UserContactId))
               .ForMember(des => des.MiddleInitial, opts => opts.MapFrom(src => src.MiddleInitial))
               .ForMember(des => des.PreferredName, opts => opts.MapFrom(src => src.PreferredName))
               .ForMember(des => des.AlternateName, opts => opts.MapFrom(src => src.AlternateName))
               .ForMember(des => des.AddressLine1, opts => opts.MapFrom(src => src.AddressLine1))
               .ForMember(des => des.AddressLine2, opts => opts.MapFrom(src => src.AddressLine2))
               .ForMember(des => des.City, opts => opts.MapFrom(src => src.City))
               .ForMember(des => des.StateId, opts => opts.MapFrom(src => src.StateId))
               .ForMember(des => des.ZipCode, opts => opts.MapFrom(src => src.ZipCode))
               .ForMember(des => des.HomePhoneNumber, opts => opts.MapFrom(src => src.HomePhoneNumber))
               .ForMember(des => des.WorkPhoneNumber, opts => opts.MapFrom(src => src.WorkPhoneNumber))
               .ForMember(des => des.WorkExtension, opts => opts.MapFrom(src => src.WorkExtension))
               .ForMember(des => des.AlternatePhoneNumber, opts => opts.MapFrom(src => src.AlternatePhoneNumber))
               .ForMember(des => des.AlternateExtension, opts => opts.MapFrom(src => src.AlternateExtension))
               .ReverseMap();

            CreateMap<EmploymentInfoEntity, ApplicationUser>()
              .ForMember(des => des.HireDate, opts => opts.MapFrom(src => src.HireDate))
              .ForMember(des => des.SocialSecurityNumber, opts => opts.MapFrom(src => src.SocialSecurityNumber))
              .ForMember(des => des.CompanyPaidPension, opts => opts.MapFrom(src => src.CompanyPaidPension))
              .ForMember(des => des.JobTaxCredit, opts => opts.MapFrom(src => src.JobTaxCredit))
              .ForMember(des => des.StatutoryEmployee, opts => opts.MapFrom(src => src.StatutoryEmployee))
              .ForMember(des => des.DateOfBirth, opts => opts.MapFrom(src => src.BirthDate))
              .ForMember(des => des.GenderId, opts => opts.MapFrom(src => src.GenderId))
              .ForMember(des => des.Id, opts => opts.MapFrom(src => src.UserId))
              .ReverseMap();

            CreateMap<EmploymentInfoEntity, Termination>()
              .ForMember(des => des.TerminationDate, opts => opts.MapFrom(src => src.TerminationDate))
              .ForMember(des => des.TerminationReason, opts => opts.MapFrom(src => src.TerminationReason))
              .ForMember(des => des.LastDateOfWork, opts => opts.MapFrom(src => src.LastDayWorked))
              .ForMember(des => des.TerminationId, opts => opts.MapFrom(src => src.TerminationId))
              .ReverseMap();

            CreateMap<EmploymentInfoEntity, TerminationEntity>()
             .ForMember(des => des.TerminationDate, opts => opts.MapFrom(src => src.TerminationDate))
             .ForMember(des => des.TerminationReason, opts => opts.MapFrom(src => src.TerminationReason))
             .ForMember(des => des.LastDateOfWork, opts => opts.MapFrom(src => src.LastDayWorked))
             .ReverseMap();

            CreateMap<PaidTimeOffEntity, PaidTimeOff>()
             .ForMember(des => des.PaidTimeOffId, opts => opts.MapFrom(src => src.PaidTimeOffId))
             .ForMember(des => des.TimeOffCategoryId, opts => opts.MapFrom(src => src.TimeOffCategoryId))
             .ForMember(des => des.Description, opts => opts.MapFrom(src => src.Description))
             .ForMember(des => des.AccrualFrequencyId, opts => opts.MapFrom(src => src.AccrualFrequencyId))
             .ForMember(des => des.HoursEarnedPerYear, opts => opts.MapFrom(src => src.HoursEarnedPerYear))
             .ForMember(des => des.MaximumAvailable, opts => opts.MapFrom(src => src.MaximumAvailable))
             .ReverseMap();

            CreateMap<TimeOffCategoryEntity, TimeOffCategory>()
            .ForMember(des => des.TimeOffCategoryId, opts => opts.MapFrom(src => src.TimeOffCategoryId))
            .ForMember(des => des.TimeOffCategoryName, opts => opts.MapFrom(src => src.TimeOffCategoryName))
            .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
            .ReverseMap();

            CreateMap<AccrualFrequencyEntity, AccrualFrequency>()
            .ForMember(des => des.AccrualFrequencyId, opts => opts.MapFrom(src => src.AccrualFrequencyId))
            .ForMember(des => des.AccrualFrequencyName, opts => opts.MapFrom(src => src.AccrualFrequencyName))
            .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
            .ReverseMap();

            CreateMap<EmployerEarningEntity, EmployerEarning>()
            .ForMember(des => des.EmployerEarningId, opts => opts.MapFrom(src => src.EmployerEarningId))
            .ForMember(des => des.UserId, opts => opts.MapFrom(src => src.UserId))
            .ForMember(des => des.CategoryId, opts => opts.MapFrom(src => src.CategoryId))
            .ForMember(des => des.EarningDeductionId, opts => opts.MapFrom(src => src.EarningDeductionId))
            .ForMember(des => des.Description, opts => opts.MapFrom(src => src.Description))
            .ForMember(des => des.W2Box14, opts => opts.MapFrom(src => src.W2Box14))
            .ForMember(des => des.W2Box14Literal, opts => opts.MapFrom(src => src.W2Box14Literal))
            .ForMember(des => des.Name, opts => opts.MapFrom(src => src.Name))
            .ForMember(des => des.WorksheetName, opts => opts.MapFrom(src => src.WorksheetName))
            .ForMember(des => des.IsAmountEnabled, opts => opts.MapFrom(src => src.IsAmountEnabled))
            .ForMember(des => des.IsHoursEnabled, opts => opts.MapFrom(src => src.IsHoursEnabled))
            .ReverseMap();

            CreateMap<EmployerDeductionEntity, EmployerDeduction>()
            .ForMember(des => des.EmployerDeductionId, opts => opts.MapFrom(src => src.EmployerDeductionId))
            .ForMember(des => des.UserId, opts => opts.MapFrom(src => src.UserId))
            .ForMember(des => des.CategoryId, opts => opts.MapFrom(src => src.CategoryId))
            .ForMember(des => des.EarningDeductionId, opts => opts.MapFrom(src => src.EarningDeductionId))
            .ForMember(des => des.Description, opts => opts.MapFrom(src => src.Description))
            .ForMember(des => des.AllowPartialAmount, opts => opts.MapFrom(src => src.AllowPartialAmount))
            .ForMember(des => des.W2Box14, opts => opts.MapFrom(src => src.W2Box14))
            .ForMember(des => des.W2Box14Literal, opts => opts.MapFrom(src => src.W2Box14Literal))
            .ReverseMap();

            CreateMap<EarningDeductionEntity, EarningDeduction>()
            .ForMember(des => des.EarningDeductionId, opts => opts.MapFrom(src => src.EarningDeductionId))
            .ForMember(des => des.CategoryId, opts => opts.MapFrom(src => src.CategoryId))
            .ForMember(des => des.Name, opts => opts.MapFrom(src => src.Name))
            .ForMember(des => des.Description, opts => opts.MapFrom(src => src.Description))
            .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
            .ReverseMap();

            CreateMap<EarningDeductionCategoryEntity, EarningDeductionCategory>()
           .ForMember(des => des.CategoryId, opts => opts.MapFrom(src => src.CategoryId))
           .ForMember(des => des.CategoryName, opts => opts.MapFrom(src => src.CategoryName))
           .ForMember(des => des.Type, opts => opts.MapFrom(src => src.Type))
           .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
           .ReverseMap();

            CreateMap<EmployerTaxInfo, EmployerTaxInfoEntity>()
              .ForMember(des => des.TaxInfoId, opt => opt.MapFrom(src => src.TaxInfoId))
              .ForMember(des => des.UserId, opt => opt.MapFrom(src => src.UserId))
              .ForMember(des => des.EIN, opt => opt.MapFrom(src => src.EIN))
              .ForMember(des => des.StateUIN, opt => opt.MapFrom(src => src.StateUIN))
              .ForMember(des => des.IncomeTaxState, opt => opt.MapFrom(src => src.IncomeTaxState))
              .ForPath(des => des.DepositFrerquency, opt => opt.MapFrom(src => src.DepositFrerquency))              
              .ForMember(des => des.EffectiveDate, opt => opt.MapFrom(src => src.EffectiveDate))
              .ForPath(des => des.TaxType, opt => opt.MapFrom(src => src.TaxType))
              .ForPath(des => des.TaxTypeName, opt => opt.MapFrom(src => src.TaxType.ToString()))
              .ForMember(des => des.SUIRate, opt => opt.MapFrom(src => src.SUIRate))
              .ForMember(des => des.IsCompanyExemptFromFUTA, opt => opt.MapFrom(src => src.IsCompanyExemptFromFUTA))
              .ForMember(des => des.IsEmployeeWorkingInThisState, opt => opt.MapFrom(src => src.IsEmployeeWorkingInThisState))
              .ForPath(des => des.CompanyType, opt => opt.MapFrom(src => src.CompanyType))
              .ReverseMap();
        }
    }
}