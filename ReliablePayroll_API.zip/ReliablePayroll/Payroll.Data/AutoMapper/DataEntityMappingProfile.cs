﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.MasterEntity;
using Payroll.Entities.PayrollEntity;
using System;

namespace Payroll.Data.AutoMapper
{
    public class DataEntityMappingProfile : Profile
    {
        public DataEntityMappingProfile()
        {
            CreateMap<MasterSignupEntity, ApplicationTenantUsers>()
                 .ForMember(des => des.FirstName, opts => opts.MapFrom(src => src.FirstName))
                 .ForMember(des => des.LastName, opts => opts.MapFrom(src => src.LastName))
                 .ForMember(des => des.Email, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.CompanyName, opts => opts.MapFrom(src => src.CompanyName))
                 .ForMember(des => des.CompanyAddress, opts => opts.MapFrom(src => src.CompanyAddress))
                 .ForMember(des => des.City, opts => opts.MapFrom(src => src.City))
                 .ForMember(des => des.NumberOfEmployees, opts => opts.MapFrom(src => src.NumberOfEmployees))
                 .ForMember(des => des.NatureOfBusiness, opts => opts.MapFrom(src => src.NatureOfBusiness))
                 .ForMember(des => des.PhoneNumber, opts => opts.MapFrom(src => src.PhoneNumber))
                 .ForMember(des => des.State, opts => opts.MapFrom(src => src.State))
                 .ForMember(des => des.ZipCode, opts => opts.MapFrom(src => src.ZipCode))
                 .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
                 .ForMember(des => des.UserName, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.CreatedDateTime, opts => opts.MapFrom(src => DateTime.UtcNow))
                 .ReverseMap();

            CreateMap<MasterSignupEntity, CompanyPayment>()
                 .ForMember(des => des.Email, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.PaymentSource, opts => opts.MapFrom(src => src.PaymentSource))
                 .ForMember(des => des.Amount, opts => opts.MapFrom(src => src.Amount))
                 .ForMember(des => des.Currency, opts => opts.MapFrom(src => src.Currency))
                 .ForMember(des => des.ReferenceNumber, opts => opts.MapFrom(src => src.ReferenceNumber))
                 .ForMember(des => des.IsRefund, opts => opts.MapFrom(src => false))
                 .ForMember(des => des.PaymentDate, opts => opts.MapFrom(src => DateTime.UtcNow))
                 .ReverseMap();

            CreateMap<OtpInfo, MasterOtpDetaildbo>()
              .ForMember(des => des.Otp, opt => opt.MapFrom(it => it.OtpCode))
              .ForMember(des => des.IsActive, opt => opt.MapFrom(it => it.IsActive))
              .ForMember(des => des.Timer, opt => opt.MapFrom(it => it.SentDateTine))
              .ReverseMap();

            CreateMap<Feature, TenantFeature>()
              .ForMember(des => des.FeatureId, opt => opt.MapFrom(it => it.FeatureId))
              .ForMember(des => des.FeatureName, opt => opt.MapFrom(it => it.FeatureName))
              .ReverseMap();

            CreateMap<Subscription, SubscriptionEntity>()
                .ForMember(des => des.SubscriptionId, opt => opt.MapFrom(src => src.SubscriptionId))
                .ForMember(des => des.SubscriptionName, opt => opt.MapFrom(src => src.SubscriptionName))
                .ForMember(des => des.Amount, opt => opt.MapFrom(src => src.Amount))
                .ReverseMap();

            CreateMap<IdentityRole, RoleEntity>()
                .ForMember(des => des.RoleId, opt => opt.MapFrom(src => src.Id))
                .ForMember(des => des.RoleName, opt => opt.MapFrom(src => src.Name))
                .ReverseMap();

            CreateMap<SignupEntityModel, ApplicationUser>()
                 .ForMember(des => des.FirstName, opts => opts.MapFrom(src => src.FirstName))
                 .ForMember(des => des.LastName, opts => opts.MapFrom(src => src.LastName))
                 .ForMember(des => des.Email, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.PhoneNumber, opts => opts.MapFrom(src => src.PhoneNumber))
                 .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsApproved))
                 .ForMember(des => des.UserName, opts => opts.MapFrom(src => src.Email))
                 .ReverseMap();

            CreateMap<ApplicationTenantUsers, ApplicationUser>()
                .ForMember(des => des.FirstName, opts => opts.MapFrom(src => src.FirstName))
                 .ForMember(des => des.LastName, opts => opts.MapFrom(src => src.LastName))
                 .ForMember(des => des.Email, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.PhoneNumber, opts => opts.MapFrom(src => src.PhoneNumber))
                 .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
                 .ForMember(des => des.UserName, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.IsAccessGiven, opts => opts.MapFrom(src => true))
                 .ReverseMap();

            CreateMap<ApplicationTenantUsers, EmployersEntityModel>()
                .ForMember(des => des.FirstName, opts => opts.MapFrom(src => src.FirstName))
                 .ForMember(des => des.LastName, opts => opts.MapFrom(src => src.LastName))
                 .ForMember(des => des.Email, opts => opts.MapFrom(src => src.Email))
                 .ForMember(des => des.PhoneNumber, opts => opts.MapFrom(src => src.PhoneNumber))
                 .ForMember(des => des.IsActive, opts => opts.MapFrom(src => src.IsActive))
                 .ForMember(des => des.CompanyName, opts => opts.MapFrom(src => src.CompanyName))
                 .ForMember(des => des.UserId, opts => opts.MapFrom(src => src.Id))
                 .ForMember(des => des.NumberOfEmployees, opts => opts.MapFrom(src => src.NumberOfEmployees))
                 .ForMember(des => des.CompanyCode, opts => opts.MapFrom(src => src.CompanyCode))
                 .ReverseMap();

            CreateMap<FeatureListModel, Feature>()
              .ForMember(des => des.FeatureName, opt => opt.MapFrom(it => it.FeatureName))
              .ForMember(des => des.Description, opt => opt.MapFrom(it => it.Description))
              .ForMember(des => des.FeatureCode, opt => opt.MapFrom(it => it.Code))
              .ForMember(des => des.CreatedDateTime, opt => opt.MapFrom(it => DateTime.UtcNow))
              .ForMember(des => des.IsActive, opt => opt.MapFrom(it => true))
              .ReverseMap();

            CreateMap<Feature, FeatureEntity>()
                .ForMember(des => des.FeatureId, opt => opt.MapFrom(src => src.FeatureId))
                .ForMember(des => des.FeatureName, opt => opt.MapFrom(src => src.FeatureName))
                .ForMember(des => des.Description, opt => opt.MapFrom(src => src.Description))
                .ReverseMap();

            CreateMap<RoleFeature, UserRoleFeature>()
                .ForMember(des => des.FeatureId, opt => opt.MapFrom(src => src.FeatureId))
                .ReverseMap();

            CreateMap<LoggedInUserEntity, ApplicationTenantUsers>()
                .ForMember(des => des.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(des => des.FirstName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(des => des.LastName, opt => opt.MapFrom(src => src.LastName))
                .ForMember(des => des.Email, opt => opt.MapFrom(src => src.Email))
                .ReverseMap();
        }
    }
}