﻿using Payroll.Data.IdentityRepository;
using System.Threading.Tasks;

namespace Payroll.Data
{
    public interface IUnitOfWork<T> where T : class
    {
        Task SaveChangesAsync();

        void SaveChanges();

        IIdentityUserRepository<T> IdentityUsersRepository { get; }
    }
}