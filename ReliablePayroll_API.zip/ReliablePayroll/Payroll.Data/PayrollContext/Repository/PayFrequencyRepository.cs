﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Repository
{
    public class PayFrequencyRepository : PayrollRepositoryBase<PayFrequency>, IPayFrequencyRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;

        public PayFrequencyRepository(PayrollDbContext payrollDbContext, IMapper mapper) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<PayFrequency>> GetPayFrequencyInfoAsync() =>
           await payrollDbContext.PayFrequencies.Where(x => x.IsActive).ToListAsync();

        public async Task<PayFrequency> GetPayFrequencyByIdAsync(int id)
        {
            return await payrollDbContext.PayFrequencies.FirstOrDefaultAsync(x => x.PayFrequencyId == id && x.IsActive);
        }
    }
}