﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Repository
{
    public class BankAccountRepository : PayrollRepositoryBase<BankAccountInfo>, IBankAccountRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;

        public BankAccountRepository(PayrollDbContext payrollDbContext, IMapper mapper) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
        }

        public async Task<BankAccountInfo> GetBankAccountInfoAsync() =>
           await payrollDbContext.BankAccountInfos.FirstOrDefaultAsync(x => x.IsActive);
    }
}