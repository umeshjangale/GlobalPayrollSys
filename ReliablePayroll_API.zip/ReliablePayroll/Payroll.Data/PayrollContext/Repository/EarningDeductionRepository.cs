﻿using AutoMapper;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;

namespace Payroll.Data.PayrollContext.Repository
{
    public class EarningDeductionRepository : PayrollRepositoryBase<EmployerEarning>, IEarningDeductionRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;

        public EarningDeductionRepository(PayrollDbContext payrollDbContext, IMapper mapper) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
        }
    }
}