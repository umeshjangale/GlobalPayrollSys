﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using Payroll.Entities.Constants;
using Payroll.Entities.PayrollEntity;
using Payroll.Utils.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Repository
{
    public class UserRepository : PayrollRepositoryBase<ApplicationUser>, IUserRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;

        public UserRepository(PayrollDbContext payrollDbContext, IMapper mapper,
            UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
            this.userManager = userManager;
            this.roleManager = roleManager;
        }

        public async Task AddRoleAsync(string role)
        {
            await roleManager.CreateAsync(new ApplicationRole(role));
        }

        public async Task<TenantOtpInfo> GetOtpAsync(string userId)
        {
            return await payrollDbContext.TenantOtpInfos.Where(x => x.UserId == userId && x.IsActive).FirstOrDefaultAsync();
        }

        public async Task InActiveUserOtpAsync(string userId)
        {
            var otp = payrollDbContext.TenantOtpInfos.Where(it => it.UserId == userId && it.IsActive);
            if (otp.Count() > 0)
                await otp.ForEachAsync(it => it.IsActive = false);
            await payrollDbContext.SaveChangesAsync();
        }

        public async Task AddOtpAsync(TenantOtpInfo masterOtpDetails)
        {
            await payrollDbContext.TenantOtpInfos.AddAsync(masterOtpDetails);
        }

        public async Task<IEnumerable<string>> GetUserFeaturesByRoleAsync(Guid roleId)
        {
            return await (from userFeature in payrollDbContext.UserRoleFeatures
                          join tenantFeature in payrollDbContext.TenantFeatures
                          on userFeature.FeatureId equals tenantFeature.FeatureId
                          where userFeature.RoleId == roleId
                          select tenantFeature.FeatureCode).ToListAsync();
        }

        public async Task<IEnumerable<EmployeeEntityViewModel>> GetEmployeesAsync(EmployeeSearchModel employeeSearch)
        {
            var employees = from user in payrollDbContext.Users
                            join userterminate in payrollDbContext.Terminations on user.Id equals userterminate.UserId into tr
                            from terminate in tr.DefaultIfEmpty()
                            where user.IsActive
                            select new { terminate.TerminationDate, user };

            if (employeeSearch.EmployeeStatus > 0)
            {
                employees = employees.Where(i => i.user.EmployeeStatus == employeeSearch.EmployeeStatus);
            }
            if (employeeSearch.EmployeeStatus == EmployeeStatus.Terminate && employeeSearch.TerminationDate != null)
            {
                employees = employees.Where(i => i.TerminationDate == employeeSearch.TerminationDate.Value.Date);
            }
            if (employeeSearch.JoiningDateFrom != null)
            {
                employees = employees.Where(i => i.user.HireDate >= employeeSearch.JoiningDateFrom.Value.Date);
            }
            if (employeeSearch.JoiningDateTo != null)
            {
                employees = employees.Where(i => i.user.HireDate <= employeeSearch.JoiningDateTo.Value.Date);
            }

            if (!String.IsNullOrWhiteSpace(employeeSearch.FirstName))
            {
                employees = employees.Where(i => i.user.FirstName.StartsWith(employeeSearch.FirstName));
            }
            if (!String.IsNullOrWhiteSpace(employeeSearch.LastName))
            {
                employees = employees.Where(i => i.user.LastName.StartsWith(employeeSearch.LastName));
            }

            return await (from employee in employees
                          join userrole in payrollDbContext.UserRoles on employee.user.Id equals userrole.UserId
                          join role in payrollDbContext.Roles on userrole.RoleId equals role.Id
                          join usercontact in payrollDbContext.UserContacts.Include(i => i.State) on employee.user.Id equals usercontact.UserId into cont
                          from contact in cont.DefaultIfEmpty()
                          where role.Name != Roles.Employer
                          select new EmployeeEntityViewModel
                          {
                              Id = employee.user.Id,
                              FirstName = employee.user.FirstName,
                              LastName = employee.user.LastName,
                              Email = employee.user.Email,
                              UserName = employee.user.UserName,
                              AddressLine1 = contact.AddressLine1,
                              AddressLine2 = contact.AddressLine2,
                              ZipCode = contact.ZipCode,
                              State = contact.State.StateName,
                              City = contact.City,
                              PhoneNumber = contact.WorkPhoneNumber,
                              IsContractor = employee.user.IsContractor,
                              Status = employee.user.EmployeeStatus.ToString()
                          }).ToListAsync();
        }

        public async Task IsEmailExistAsync(string emailId)
        {
            if (await userManager.Users.AnyAsync(p => p.Email == emailId))
                throw new ServiceException(HttpStatusCode.BadRequest, "EmailAlreadyExist");
        }
    }
}