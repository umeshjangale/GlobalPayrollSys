﻿using Payroll.Data.PayrollContext.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll.Data.PayrollContext.Repository
{
    public class PayCheckPrintRepository : IPayCheckPrintRepository
    {
        public PayCheckPrintRepository()
        {

        }
    }
}
