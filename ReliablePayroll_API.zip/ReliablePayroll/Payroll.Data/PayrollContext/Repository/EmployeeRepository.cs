﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using Payroll.Entities.PayrollEntity;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Repository
{
    public class EmployeeRepository : PayrollRepositoryBase<Termination>, IEmployeeRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;

        public EmployeeRepository(PayrollDbContext payrollDbContext, IMapper mapper) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
        }

        public async Task<Termination> GetTerminationByUserIdAsync(string userId)
        {
            return await payrollDbContext.Terminations.FirstOrDefaultAsync(x => x.UserId == userId);
        }

        public async Task<WorkContact> GetWorkContactByUserIdAsync(string userId)
        {
            return await payrollDbContext.WorkContacts.FirstOrDefaultAsync(x => x.UserId == userId);
        }

        public async Task<WorkContact> GetWorkContactByIdAsync(long id)
        {
            return await payrollDbContext.WorkContacts.FirstOrDefaultAsync(x => x.WorkContactId == id);
        }

        public async Task AddWorkContactAsync(WorkContact workContact)
        {
            await payrollDbContext.WorkContacts.AddAsync(workContact);
        }

        public Task UpdateWorkContactAsync(WorkContact workContact)
        {
            payrollDbContext.WorkContacts.Update(workContact);
            return Task.CompletedTask;
        }

        public async Task AddUserContactAsync(UserContact userContact)
        {
            await payrollDbContext.UserContacts.AddAsync(userContact);
        }

        public Task UpdateUserContactAsync(UserContact userContact)
        {
            payrollDbContext.UserContacts.Update(userContact);
            return Task.CompletedTask;
        }

        public async Task<UserContact> GetUserContactByIdAsync(long id)
        {
            return await payrollDbContext.UserContacts.FirstOrDefaultAsync(x => x.UserContactId == id);
        }

        public async Task<UserContactEntity> GetUserContactByUserIdAsync(string userId)
        {
            return await payrollDbContext.UserContacts
                        .Include(x => x.User)
                        .Where(x => x.User.Id == userId)
                        .Select(userContact => new UserContactEntity
                        {
                            UserContactId = userContact.UserContactId,
                            UserId = userContact.UserId,
                            FirstName = userContact.User.FirstName,
                            MiddleInitial = userContact.MiddleInitial,
                            LastName = userContact.User.LastName,
                            PreferredName = userContact.PreferredName,
                            AlternateName = userContact.AlternateName,
                            AddressLine1 = userContact.AddressLine1,
                            AddressLine2 = userContact.AddressLine2,
                            City = userContact.City,
                            StateId = userContact.StateId,
                            ZipCode = userContact.ZipCode,
                            HomePhoneNumber = userContact.HomePhoneNumber,
                            WorkPhoneNumber = userContact.WorkPhoneNumber,
                            WorkExtension = userContact.WorkExtension,
                            AlternatePhoneNumber = userContact.AlternatePhoneNumber,
                            AlternateExtension = userContact.AlternateExtension
                        }).FirstOrDefaultAsync();
        }
    }
}