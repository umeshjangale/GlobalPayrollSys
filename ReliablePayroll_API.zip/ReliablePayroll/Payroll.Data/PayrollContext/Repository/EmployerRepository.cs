﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Repository
{
    public class EmployerRepository : PayrollRepositoryBase<EmployerInfo>, IEmployerRepository
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;

        public EmployerRepository(PayrollDbContext payrollDbContext, IMapper mapper) : base(payrollDbContext, mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.mapper = mapper;
        }

        public async Task AddEmployerContactAsync(EmployerContactInfo employerContactInfo)
        {
            await payrollDbContext.EmployerContactInfos.AddAsync(employerContactInfo);
        }

        public Task UpdateEmployerContactAsync(EmployerContactInfo employerContactInfo)
        {
            payrollDbContext.EmployerContactInfos.Update(employerContactInfo);
            return Task.CompletedTask;
        }

        public async Task<EmployerContactInfo> GetEmployerContactByIdAsync(int id)
        {
            return await payrollDbContext.EmployerContactInfos.FirstOrDefaultAsync(x => x.ContactInformationId == id);
        }

        public async Task AddPaidTimeOffAsync(PaidTimeOff paidTimeOff)
        {
            await payrollDbContext.PaidTimeOffs.AddAsync(paidTimeOff);
        }

        public Task UpdatePaidTimeOffAsync(PaidTimeOff paidTimeOff)
        {
            payrollDbContext.PaidTimeOffs.Update(paidTimeOff);
            return Task.CompletedTask;
        }

        public async Task<PaidTimeOff> GetPaidTimeOffByIdAsync(long id)
        {
            return await payrollDbContext.PaidTimeOffs.FirstOrDefaultAsync(x => x.PaidTimeOffId == id && x.IsActive);
        }

        public async Task<IEnumerable<PaidTimeOffEntity>> GetPaidTimeOffAsync()
        {
            return await payrollDbContext.PaidTimeOffs
                        .Include(x => x.TimeOffCategory)
                        .Include(x => x.AccrualFrequency)
                        .Where(x => x.IsActive)
                        .Select(paidTimeOff => new PaidTimeOffEntity
                        {
                            PaidTimeOffId = paidTimeOff.PaidTimeOffId,
                            TimeOffCategoryId = paidTimeOff.TimeOffCategoryId,
                            TimeOffCategoryName = paidTimeOff.TimeOffCategory.TimeOffCategoryName,
                            Description = paidTimeOff.Description,
                            AccrualFrequencyId = paidTimeOff.AccrualFrequencyId,
                            AccrualFrequencyName = paidTimeOff.AccrualFrequency.AccrualFrequencyName,
                            HoursEarnedPerYear = paidTimeOff.HoursEarnedPerYear,
                            MaximumAvailable = paidTimeOff.MaximumAvailable
                        }).ToListAsync();
        }

        public async Task<EmployerContactInfo> GetEmployerContactAsync() =>
                await payrollDbContext.EmployerContactInfos.FirstOrDefaultAsync(x => x.IsActive);

        public async Task<EmployerInfo> GetEmployerInfoAsync() =>
            await payrollDbContext.EmployerInfos.FirstOrDefaultAsync(x => x.IsActive);

        public async Task<IEnumerable<State>> GetStateAsync()
        {
            return await payrollDbContext.States.ToListAsync();
        }

        public async Task<IEnumerable<EmployerTaxInfo>> GetEmployerTaxInfoAsync()
        {
            return await payrollDbContext.EmployerTaxInfos.ToListAsync();
        }

        public async Task AddEmployerTaxInfoAsync(EmployerTaxInfo employerTaxInfo)
        {
            await payrollDbContext.EmployerTaxInfos.AddAsync(employerTaxInfo);
        }

        public Task UpdateEmployerTaxInfoAsync(EmployerTaxInfo employerTaxInfo)
        {
            payrollDbContext.EmployerTaxInfos.Update(employerTaxInfo);
            return Task.CompletedTask;
        }
    }
}