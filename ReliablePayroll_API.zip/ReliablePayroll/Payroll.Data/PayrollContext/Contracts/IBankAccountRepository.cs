﻿using Payroll.Data.Models.PayrollDataModels;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IBankAccountRepository : IRepository<BankAccountInfo>
    {
        Task<BankAccountInfo> GetBankAccountInfoAsync();
    }
}