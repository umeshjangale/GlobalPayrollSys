﻿using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.PayrollEntity;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IEmployeeRepository : IRepository<Termination>
    {
        Task<Termination> GetTerminationByUserIdAsync(string userId);

        Task AddUserContactAsync(UserContact userContact);

        Task UpdateUserContactAsync(UserContact userContact);

        Task<UserContactEntity> GetUserContactByUserIdAsync(string userId);

        Task<UserContact> GetUserContactByIdAsync(long id);

        Task<WorkContact> GetWorkContactByUserIdAsync(string UserId);

        Task AddWorkContactAsync(WorkContact workContact);

        Task UpdateWorkContactAsync(WorkContact workContact);

        Task<WorkContact> GetWorkContactByIdAsync(long id);
    }
}