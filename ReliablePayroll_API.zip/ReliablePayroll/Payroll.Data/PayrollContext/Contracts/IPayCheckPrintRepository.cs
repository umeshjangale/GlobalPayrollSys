﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IPayCheckPrintRepository
    {
    }
}
