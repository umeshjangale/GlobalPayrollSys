﻿using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IEmployerRepository : IRepository<EmployerInfo>
    {
        Task AddEmployerContactAsync(EmployerContactInfo employerContactInfo);

        Task UpdateEmployerContactAsync(EmployerContactInfo employerContactInfo);

        Task<EmployerContactInfo> GetEmployerContactByIdAsync(int id);

        Task<EmployerContactInfo> GetEmployerContactAsync();

        Task<EmployerInfo> GetEmployerInfoAsync();

        Task<IEnumerable<State>> GetStateAsync();

        Task AddPaidTimeOffAsync(PaidTimeOff paidTimeOff);

        Task UpdatePaidTimeOffAsync(PaidTimeOff paidTimeOff);

        Task<IEnumerable<PaidTimeOffEntity>> GetPaidTimeOffAsync();

        Task<PaidTimeOff> GetPaidTimeOffByIdAsync(long id);

        Task<IEnumerable<EmployerTaxInfo>> GetEmployerTaxInfoAsync();

        Task AddEmployerTaxInfoAsync(EmployerTaxInfo employerTaxInfo);

        Task UpdateEmployerTaxInfoAsync(EmployerTaxInfo employerTaxInfo);
    }
}