﻿using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.PayrollEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IUserRepository : IRepository<ApplicationUser>
    {
        Task AddOtpAsync(TenantOtpInfo masterOtpDetails);

        Task AddRoleAsync(string role);

        Task<TenantOtpInfo> GetOtpAsync(string userId);

        Task InActiveUserOtpAsync(string userId);

        Task<IEnumerable<string>> GetUserFeaturesByRoleAsync(Guid roleId);

        Task<IEnumerable<EmployeeEntityViewModel>> GetEmployeesAsync(EmployeeSearchModel employeeSearch);

        Task IsEmailExistAsync(string emailId);
    }
}