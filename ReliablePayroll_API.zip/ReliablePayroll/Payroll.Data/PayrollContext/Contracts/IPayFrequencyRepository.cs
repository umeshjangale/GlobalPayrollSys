﻿using Payroll.Data.Models.PayrollDataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IPayFrequencyRepository : IRepository<PayFrequency>
    {
        Task<IEnumerable<PayFrequency>> GetPayFrequencyInfoAsync();

        Task<PayFrequency> GetPayFrequencyByIdAsync(int id);
    }
}