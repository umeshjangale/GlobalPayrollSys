﻿using Payroll.Data.Models.PayrollDataModels;

namespace Payroll.Data.PayrollContext.Contracts
{
    public interface IEarningDeductionRepository : IRepository<EmployerEarning>
    {
    }
}