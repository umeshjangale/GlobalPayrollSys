﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Payroll.Data.Models;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities.Login;
using Payroll.Utils.ExtensionMethods;
using System;

namespace Payroll.Data.PayrollContext
{
    public class PayrollDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, string>
    {
        private string tenant;
        private readonly ServerSettings serverSettings;
        private readonly IHttpContextAccessor httpContextAccessor;

        public DbSet<AuditLog> AuditLog { get; set; }

        public DbSet<TenantOtpInfo> TenantOtpInfos { get; set; }

        public DbSet<UserRoleFeature> UserRoleFeatures { get; set; }

        public DbSet<TenantFeature> TenantFeatures { get; set; }

        public DbSet<EmployerInfo> EmployerInfos { get; set; }

        public DbSet<BankAccountInfo> BankAccountInfos { get; set; }

        public DbSet<PayFrequency> PayFrequencies { get; set; }

        public DbSet<EmployerContactInfo> EmployerContactInfos { get; set; }

        public DbSet<Termination> Terminations { get; set; }

        public DbSet<WorkContact> WorkContacts { get; set; }

        public DbSet<UserContact> UserContacts { get; set; }

        public DbSet<State> States { get; set; }

        public DbSet<Country> Countries { get; set; }

        public DbSet<PaidTimeOff> PaidTimeOffs { get; set; }

        public DbSet<TimeOffCategory> TimeOffCategories { get; set; }

        public DbSet<AccrualFrequency> AccrualFrequencies { get; set; }
        public DbSet<EmployerTaxInfo> EmployerTaxInfos { get; set; }

        public PayrollDbContext(IHttpContextAccessor httpContextAccessor,
            IOptions<ServerSettings> serverSettings)
        {
            this.serverSettings = serverSettings.Value;
            this.httpContextAccessor = httpContextAccessor;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            builder.UseSqlServer(GetConnectionString());
            base.OnConfiguring(builder);
        }

        public void AddTenantForMigration(string tenant)
        {
            this.tenant = tenant;
        }

        private string GetConnectionString()
        {
            if (String.IsNullOrEmpty(tenant))
                tenant = GetTenantFromHttpContext();

            tenant = "GPS_" + tenant;
            string connectionString = String.Format(@"Data Source = {0}; Initial Catalog = {1}; User ID = {2}; Password = {3}; Integrated Security = {4};",
                        serverSettings.ServerName, tenant, serverSettings.UserId, serverSettings.Password, serverSettings.IntegratedSequirity);

            tenant = string.Empty;
            return connectionString;
        }

        private string GetTenantFromHttpContext()
        {
            return httpContextAccessor.HttpContext.User.GetTenantName() ?? GetTenantFromHttpHeader();
        }

        private string GetTenantFromHttpHeader()
        {
            string tenant = httpContextAccessor.HttpContext.Request.Headers["tenant"];
            return tenant;
        }
    }
}