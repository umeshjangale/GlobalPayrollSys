﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.UnitOfWork;
using Payroll.Entities.Constants;
using Payroll.Utils.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext
{
    public class TeanantSeed : ITenantSeed
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly IPayrollUnitOfWork payrollUnitOfWork;
        private readonly IMapper mapper;

        public TeanantSeed(PayrollDbContext payrollDbContext, UserManager<ApplicationUser> userManager,
            RoleManager<ApplicationRole> roleManager, IPayrollUnitOfWork payrollUnitOfWork,
            IMapper mapper)
        {
            this.payrollDbContext = payrollDbContext;
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.payrollUnitOfWork = payrollUnitOfWork;
            this.mapper = mapper;
        }

        public async Task MigrationAsync(string companyCode, IEnumerable<TenantFeature> tenantFeatures)
        {
            payrollDbContext.AddTenantForMigration(companyCode);
            await MigrationAsync();
            await AddTenantRoleAsync();
            await AddTenantFeatureAsync(tenantFeatures);
            await CountryAndStateSeedingAsync();
            await TimeOffCategoryAndAccrualFreqSeedingAsync();
        }

        private async Task AddTenantRoleAsync()
        {
            await payrollUnitOfWork.IdentityUsersRepository.AddTenantRoleAsync(Roles.Employer);
            await payrollUnitOfWork.IdentityUsersRepository.AddTenantRoleAsync(Roles.Employee);
        }

        public async Task AddDefaultUserAsync(ApplicationUser user)
        {
            IdentityResult res = await userManager.CreateAsync(user);
            if (!res.Succeeded)
            {
                var message = string.Join(", ", res);
                throw new ServiceException(HttpStatusCode.BadRequest, $"User not created. Error: {message}");
            }
            await userManager.AddToRoleAsync(user, Roles.Employer);
        }

        private async Task AddTenantFeatureAsync(IEnumerable<TenantFeature> tenantFeatures)
        {
            await payrollDbContext.TenantFeatures.AddRangeAsync(tenantFeatures);
            await payrollDbContext.SaveChangesAsync();
        }

        public async Task MigrationAsync()
        {
            await payrollDbContext.Database.MigrateAsync();
        }

        public async Task AddRoleFeatureAsync(List<UserRoleFeature> employerFeatures, List<UserRoleFeature> employeeFeatures)
        {
            Guid roleId = Guid.Parse((await roleManager.FindByNameAsync(Roles.Employer)).Id);
            employerFeatures.ForEach(it => it.RoleId = roleId);

            roleId = Guid.Parse((await roleManager.FindByNameAsync(Roles.Employee)).Id);
            employeeFeatures.ForEach(it => it.RoleId = roleId);

            await payrollDbContext.UserRoleFeatures.AddRangeAsync(employerFeatures);
            await payrollDbContext.UserRoleFeatures.AddRangeAsync(employeeFeatures);
            await payrollDbContext.SaveChangesAsync();
        }

        private async Task CountryAndStateSeedingAsync()
        {
            if (payrollDbContext.Countries.Any()) return;

            var countries = Entities.Constants.Country.GetCountryList()
                .Select(i => mapper.Map<Models.PayrollDataModels.Country>(i));

            var state = Entities.Constants.States.GetStateList()
                .Select(i => mapper.Map<Models.PayrollDataModels.State>(i));

            await payrollDbContext.Countries.AddRangeAsync(countries);
            await payrollDbContext.States.AddRangeAsync(state);
            await payrollDbContext.SaveChangesAsync();
        }

        private async Task TimeOffCategoryAndAccrualFreqSeedingAsync()
        {
            if (payrollDbContext.TimeOffCategories.Any()) return;

            var timeOffCategories = Entities.Constants.TimeOffCategory.GetTimeOffCategoryList()
                .Select(i => mapper.Map<Models.PayrollDataModels.TimeOffCategory>(i));

            var accrualFrequencies = Entities.Constants.AccrualFrequency.GetAccrualFrequencyList()
                .Select(i => mapper.Map<Models.PayrollDataModels.AccrualFrequency>(i));

            await payrollDbContext.TimeOffCategories.AddRangeAsync(timeOffCategories);
            await payrollDbContext.AccrualFrequencies.AddRangeAsync(accrualFrequencies);
            await payrollDbContext.SaveChangesAsync();
        }
    }
}