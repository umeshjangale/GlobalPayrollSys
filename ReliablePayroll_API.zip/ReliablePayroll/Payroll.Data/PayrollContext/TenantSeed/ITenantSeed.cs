﻿using Payroll.Data.Models.PayrollDataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext
{
    public interface ITenantSeed
    {
        Task MigrationAsync(string companyCode, IEnumerable<TenantFeature> tenantFeatures);

        Task MigrationAsync();

        Task AddDefaultUserAsync(ApplicationUser user);

        Task AddRoleFeatureAsync(List<UserRoleFeature> employerFeatures, List<UserRoleFeature> employeeFeatures);
    }
}