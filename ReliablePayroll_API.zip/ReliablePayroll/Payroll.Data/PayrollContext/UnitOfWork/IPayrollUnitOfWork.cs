﻿using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;

namespace Payroll.Data.PayrollContext.UnitOfWork
{
    public interface IPayrollUnitOfWork : IUnitOfWork<ApplicationUser>
    {
        IUserRepository UserRepository { get; }

        IPayFrequencyRepository PayFrequencyRepository { get; }

        IBankAccountRepository BankAccountRepository { get; }

        IEmployerRepository EmployerRepository { get; }

        IEmployeeRepository EmployeeRepository { get; }

        IEarningDeductionRepository EarningDeductionRepository { get; }
    }
}