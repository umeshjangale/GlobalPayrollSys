﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Payroll.Data.IdentityRepository;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.Contracts;
using Payroll.Data.PayrollContext.Repository;
using Payroll.Entities.Login;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Data.PayrollContext.UnitOfWork
{
    public class PayrollUnitOfWork : IPayrollUnitOfWork
    {
        private PayrollDbContext payrollDbContext;
        private readonly IMapper mapper;
        private IUserRepository userRepository;
        private IPayFrequencyRepository payFrequencyRepository;
        private IBankAccountRepository bankAccountRepository;
        private IEmployerRepository employerRepository;
        private IEmployeeRepository employeeRepository;
        private IEarningDeductionRepository earningDeductionRepository;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly IOptions<ServerSettings> serverSettings;
        private IIdentityUserRepository<ApplicationUser> identityUsers;
        private readonly IHttpContextAccessor httpContextAccessor;

        public PayrollUnitOfWork(IMapper mapper, UserManager<ApplicationUser> userManager,
            RoleManager<ApplicationRole> roleManager, IOptions<ServerSettings> serverSettings,
            PayrollDbContext payrollDbContext, IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.payrollDbContext = payrollDbContext;
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.serverSettings = serverSettings;
            this.httpContextAccessor = httpContextAccessor;
        }

        public IUserRepository UserRepository
        {
            get
            {
                if (userRepository == null)
                {
                    userRepository = new UserRepository(payrollDbContext, mapper, userManager, roleManager);
                }
                return userRepository;
            }
        }

        public IEmployeeRepository EmployeeRepository
        {
            get
            {
                if (employeeRepository == null)
                {
                    employeeRepository = new EmployeeRepository(payrollDbContext, mapper);
                }
                return employeeRepository;
            }
        }

        public IPayFrequencyRepository PayFrequencyRepository
        {
            get
            {
                if (payFrequencyRepository == null)
                {
                    payFrequencyRepository = new PayFrequencyRepository(payrollDbContext, mapper);
                }
                return payFrequencyRepository;
            }
        }

        public IBankAccountRepository BankAccountRepository
        {
            get
            {
                if (bankAccountRepository == null)
                {
                    bankAccountRepository = new BankAccountRepository(payrollDbContext, mapper);
                }
                return bankAccountRepository;
            }
        }

        public IEmployerRepository EmployerRepository
        {
            get
            {
                if (employerRepository == null)
                {
                    employerRepository = new EmployerRepository(payrollDbContext, mapper);
                }
                return employerRepository;
            }
        }

        //public IEmployeeRepository EmployeeRepository
        //{
        //    get
        //    {
        //        if(employeeRepository==null)
        //        {
        //            employeeRepository = new EmployeeRepository(payrollDbContext, mapper);
        //        }
        //        return employeeRepository;
        //    }
        //}

        public IIdentityUserRepository<ApplicationUser> IdentityUsersRepository
        {
            get
            {
                if (identityUsers == null)
                {
                    identityUsers = new IdentityUserRepository<ApplicationUser>(userManager, null, roleManager);
                }
                return identityUsers;
            }
        }
        public IEarningDeductionRepository EarningDeductionRepository
        {
            get
            {
                if (earningDeductionRepository == null)
                {
                    earningDeductionRepository = new EarningDeductionRepository(payrollDbContext, mapper);
                }
                return earningDeductionRepository;
            }
        }

        public async Task SaveChangesAsync()
        {
            await payrollDbContext.SaveChangesAsync();
        }

        public void SaveChanges()
        {
            TenantAuditLogEntries auditLogEntries = new TenantAuditLogEntries(payrollDbContext, httpContextAccessor.HttpContext.User.Identity.Name);
            auditLogEntries.SetAuditableFields();
            var retryEntities = auditLogEntries.LogAuditEntries();
            if (retryEntities.Any())
            {
                payrollDbContext.SaveChanges();
                auditLogEntries.LogAuditEntries(retryEntities, true);
                payrollDbContext.SaveChanges();
            }
            else
            {
                payrollDbContext.SaveChanges();
            }
        }
    }
}