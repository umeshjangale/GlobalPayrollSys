﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Payroll.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Payroll.Data.PayrollContext.UnitOfWork
{
    public class TenantAuditLogEntries
    {
        private readonly PayrollDbContext payrollDbContext;
        private readonly string userName;

        public TenantAuditLogEntries(PayrollDbContext payrollDbContext, string userName)
        {
            this.payrollDbContext = payrollDbContext;
            this.userName = userName;
        }

        public void SetAuditableFields()
        {
            var modifiedEntities = this.payrollDbContext.ChangeTracker.Entries<IAuditableEntity>()
                 .Where(p => p.State.Equals(EntityState.Modified) || p.State.Equals(EntityState.Added) || p.State.Equals(EntityState.Deleted)).ToList();

            DateTime now = DateTime.UtcNow;

            modifiedEntities.ForEach(entity =>
            {
                if (entity.State.Equals(EntityState.Modified))
                {
                    entity.Entity.UpdatedBy = userName;
                    entity.Entity.UpdatedDateTime = now;
                }
                else if (entity.State.Equals(EntityState.Added))
                {
                    entity.Entity.CreatedBy = userName;
                    entity.Entity.CreatedDateTime = now;
                    entity.Entity.UpdatedBy = userName;
                    entity.Entity.UpdatedDateTime = now;
                }
            });
        }

        public List<EntityEntry> LogAuditEntries(List<EntityEntry> defaultModifiedEntities = null, bool specialInsert = false)
        {
            List<EntityEntry> modifiedEntities;

            modifiedEntities = defaultModifiedEntities ?? payrollDbContext.ChangeTracker.Entries()
              .Where(p => p.State.Equals(EntityState.Modified) || p.State.Equals(EntityState.Added) || p.State.Equals(EntityState.Deleted)).ToList();

            var now = DateTime.UtcNow;

            List<AuditLog> listLogs = new List<AuditLog>();
            var savedForAfterCommit = new List<EntityEntry>();

            string primaryKey;
            foreach (var change in modifiedEntities)
            {
                var entityName = change.Entity.GetType().Name;
                primaryKey = GetPrimaryKeyValue(change).ToString();

                var propertyNames = (change.State.Equals(EntityState.Deleted)) ?
                    change.OriginalValues.Properties : change.CurrentValues.Properties;

                if ((primaryKey == null || primaryKey.ToString() == "0") && change.State.Equals(EntityState.Added))
                {
                    savedForAfterCommit.Add(change);
                    continue;
                }

                foreach (var prop in propertyNames)
                {
                    if (change.State.Equals(EntityState.Modified))
                    {
                        string originalValue = "";
                        if (change.OriginalValues[prop] is DateTime originalDate)
                            originalValue = originalDate.ToString("MM/dd/yyyy");
                        else
                            originalValue = change.OriginalValues[prop]?.ToString();

                        string currentValue = "";
                        if (change.CurrentValues[prop] is DateTime currentDate)
                            currentValue = currentDate.ToString("MM/dd/yyyy");
                        else
                            currentValue = change.CurrentValues[prop]?.ToString();

                        if (originalValue != currentValue) //Only create a log if the value changes
                        {
                            //Create the Change Log
                            var log = new AuditLog()
                            {
                                AuditType = "M",
                                TableName = entityName,
                                RefId = primaryKey,
                                ColumnName = prop.Name,
                                OldValue = originalValue,
                                NewValue = currentValue,
                                CreatedDateTime = now,
                                CreatedBy = userName
                            };

                            listLogs.Add(log);
                        }
                    }
                    else if (change.State.Equals(EntityState.Added) || specialInsert)
                    {
                        string currentValue = change.CurrentValues[prop]?.ToString();
                        if (!string.IsNullOrEmpty(currentValue)) //Only create a log if the value changes
                        {
                            //Create the Change Log
                            var log = new AuditLog()
                            {
                                AuditType = "A",
                                TableName = entityName,
                                RefId = primaryKey.ToString(),
                                ColumnName = prop.Name,
                                NewValue = currentValue,
                                CreatedDateTime = now,
                                CreatedBy = userName
                            };

                            listLogs.Add(log);
                        }
                    }
                    else if (change.State.Equals(EntityState.Deleted))
                    {
                        string currentValue = change.OriginalValues[prop]?.ToString();
                        if (!string.IsNullOrEmpty(currentValue)) //Only create a log if the value changes
                        {
                            //Create the Change Log
                            var log = new AuditLog()
                            {
                                AuditType = "D",
                                TableName = entityName,
                                RefId = primaryKey.ToString(),
                                ColumnName = prop.Name,
                                OldValue = currentValue,
                                CreatedDateTime = now,
                                CreatedBy = userName
                            };

                            listLogs.Add(log);
                        }
                    }
                }
            }
            if (listLogs.Count > 0)
            {
                this.payrollDbContext.AuditLog.AddRangeAsync(listLogs);
            }

            return savedForAfterCommit;
        }

        private object GetPrimaryKeyValue(EntityEntry entry)
        {
            //var objectStateEntry = ((IObjectContextAdapter)this.payrollDbContext).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);

            //if (objectStateEntry.EntityKey.EntityKeyValues == null)
            //{
            //    return 0;
            //}

            //return objectStateEntry.EntityKey.EntityKeyValues[0].Value;
            return 0;
        }
    }
}