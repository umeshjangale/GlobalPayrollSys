﻿namespace Payroll.Utils.Auth
{
    public class PrivateClaimNames
    {
        /// <summary>
        /// Roles
        /// </summary>
        public static string Role => "role";

        /// <summary>
        /// ApplicationUserId
        /// </summary>
        public static string Id => "id";

        /// <summary>
        /// Application TenantName
        /// </summary>
        public static string TenantName => "tenant";

        public static string Feature => "feature";
    }
}