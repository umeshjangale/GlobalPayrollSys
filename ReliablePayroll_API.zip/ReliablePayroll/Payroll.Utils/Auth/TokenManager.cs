﻿using Microsoft.AspNetCore.Http;
using Payroll.Entities.Login;
using Payroll.Utils.Cache;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Utils.Auth
{
    public class TokenManager : ITokenManager
    {
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ILoginResponseCache loginResponseCache;

        public TokenManager(IHttpContextAccessor httpContextAccessor, ILoginResponseCache loginResponseCache)
        {
            this.httpContextAccessor = httpContextAccessor;
            this.loginResponseCache = loginResponseCache;
        }

        public async Task<bool> IsActiveToken()
        {
            return await Task.Run(() =>
            {
                string userId = httpContextAccessor.HttpContext.User.GetLoggedInUserId();

                if (!String.IsNullOrWhiteSpace(userId))
                {
                    var authorizationHeader = httpContextAccessor.HttpContext.Request.Headers["authorization"];

                    LoginResponse loginResponse = loginResponseCache.Get(userId ?? string.Empty);
                    if (loginResponse == null)
                    {
                        throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidToken");
                    }

                    string token = authorizationHeader.ToString().Split(' ').Last();
                    if (!loginResponse.AuthToken.Equals(token))
                    {
                        throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidToken");
                    }
                }
                return true;
            });
        }
    }
}