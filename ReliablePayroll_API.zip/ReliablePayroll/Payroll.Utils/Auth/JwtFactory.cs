﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace Payroll.Utils.Auth
{
    public class JwtFactory : IJwtFactory
    {
        private readonly JwtIssuerOptions jwtIssuerOptions;
        private readonly JwtOptions jwtOptions;

        public JwtFactory(IOptions<JwtIssuerOptions> jwtIssuerOptions, IOptions<JwtOptions> jwtOptions)
        {
            this.jwtIssuerOptions = jwtIssuerOptions.Value;
            this.jwtOptions = jwtOptions.Value;
            ThrowIfInvalidOptions(this.jwtIssuerOptions);
        }

        public async Task<ClaimsIdentity> GenerateClaimsIdentity(string userName, string id, IEnumerable<string> roles, string tenantName, IEnumerable<string> features)
        {
            return new ClaimsIdentity(new GenericIdentity(userName, "Token"),
                new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, userName),
                    new Claim(JwtRegisteredClaimNames.Jti, await jwtIssuerOptions.JtiGenerator()),
                    new Claim(JwtRegisteredClaimNames.Iat, ToUnixEpochDate(jwtIssuerOptions.IssuedAt).ToString(), ClaimValueTypes.Integer64),
                    new Claim(PrivateClaimNames.Id, id, ClaimValueTypes.String, jwtIssuerOptions.Issuer),
                    new Claim(PrivateClaimNames.TenantName, tenantName),
                }
                .Concat(
                    roles.Select(it => new Claim(PrivateClaimNames.Role, it, ClaimValueTypes.String, jwtIssuerOptions.Issuer))
                )
                .Concat(
                    features.Select(it => new Claim(PrivateClaimNames.Feature, it, ClaimValueTypes.String, jwtIssuerOptions.Issuer))
                )
            );
        }

        public string GenerateEncodedTokenAsync(ClaimsIdentity identity)
        {
            var credentials = jwtOptions.GetSigningCredentials();
            // Create the JWT security token and encode it.
            var jwt = new JwtSecurityToken(
                issuer: jwtIssuerOptions.Issuer,
                audience: jwtIssuerOptions.Audience,
                claims: identity.Claims,
                notBefore: jwtIssuerOptions.NotBefore,
                expires: jwtIssuerOptions.Expiration,
                signingCredentials: credentials);

            var encodedJwt = new JwtSecurityTokenHandler().WriteToken(jwt);
            return encodedJwt;
        }

        public string GenerateRefreshTokenAsync()
        {
            Random rand = new Random(Environment.TickCount);
            List<char> chars = new List<char>();
            string randomChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789!_-";

            for (int i = chars.Count; i < 20; i++)
            {
                char c = randomChars[rand.Next(0, randomChars.Length)];
                chars.Add(c);
            }
            String refreshToken = new string(chars.ToArray());
            return refreshToken;
        }

        /// <returns>Date converted to seconds since Unix epoch (Jan 1, 1970, midnight UTC).</returns>

        private static long ToUnixEpochDate(DateTime date)
          => (long)Math.Round((date.ToUniversalTime() -
                               new DateTimeOffset(1970, 1, 1, 0, 0, 0, TimeSpan.Zero))
                              .TotalSeconds);

        private static void ThrowIfInvalidOptions(JwtIssuerOptions options)
        {
            if (options == null) throw new ArgumentNullException(nameof(options));

            if (options.ValidFor <= TimeSpan.Zero) throw new ArgumentException("Must be a non-zero TimeSpan." + nameof(JwtIssuerOptions.ValidFor));

            if (options.JtiGenerator == null) throw new ArgumentNullException(string.Empty, nameof(JwtIssuerOptions.JtiGenerator));
        }
    }
}