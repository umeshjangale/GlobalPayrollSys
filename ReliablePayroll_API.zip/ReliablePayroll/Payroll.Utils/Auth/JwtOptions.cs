﻿using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace Payroll.Utils.Auth
{
    public class JwtOptions
    {
        public string SigningKey { get; set; }

        public SecurityKey GetSecurityKey()
        {
            return new SymmetricSecurityKey(Encoding.ASCII.GetBytes(SigningKey));
        }

        public SigningCredentials GetSigningCredentials()
        {
            return new SigningCredentials(
                GetSecurityKey(),
                SecurityAlgorithms.HmacSha256
            );
        }
    }
}