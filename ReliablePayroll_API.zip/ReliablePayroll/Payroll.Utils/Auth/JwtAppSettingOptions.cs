﻿using System;

namespace Payroll.Utils.Auth
{
    public class JwtAppSettingOptions
    {
        public String Issuer { get; set; }

        public String Audience { get; set; }

        public int ValidForSeconds { get; set; }
    }
}