﻿using System.Threading.Tasks;

namespace Payroll.Utils.Auth
{
    public interface ITokenManager
    {
        Task<bool> IsActiveToken();
    }
}