﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Payroll.Utils.Auth
{
    public interface IJwtFactory
    {
        string GenerateEncodedTokenAsync(ClaimsIdentity identity);

        Task<ClaimsIdentity> GenerateClaimsIdentity(string userName, string id, IEnumerable<string> roles, string tenantName, IEnumerable<string> features);

        string GenerateRefreshTokenAsync();
    }
}