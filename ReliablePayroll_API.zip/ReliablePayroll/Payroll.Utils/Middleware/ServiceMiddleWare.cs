﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Payroll.Utils.Auth;
using Payroll.Utils.Exceptions;
using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Payroll.Utils.Middleware
{
    public class ServiceMiddleWare
    {
        private readonly RequestDelegate next;
        private readonly ILogger logger;
        private readonly ITokenManager tokenManager;

        public ServiceMiddleWare(RequestDelegate next, ILogger<ServiceMiddleWare> logger, ITokenManager tokenManager)
        {
            this.next = next;
            this.logger = logger;
            this.tokenManager = tokenManager;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                context.Response.ContentType = "application/json";
                if (await tokenManager.IsActiveToken())
                {
                    await next(context); // calling next middleware
                }
            }
            catch (ServiceException se)
            {
                await context.Response.WriteAsync(MakeErrorResponse(se.Message));
                logger.LogError(se.InnerException, se.Message);
            }
            catch (SerializationException sze)
            {
                await context.Response.WriteAsync(MakeErrorResponse(sze.Message));
                logger.LogError(sze, sze.Message);
            }
            catch (ValidationException ve)
            {
                await context.Response.WriteAsync(MakeErrorResponse(ve.Message));
                logger.LogError(ve, ve.Message);
            }
            catch (Exception e)
            {
                await context.Response.WriteAsync(MakeErrorResponse("Unexpected server error"));
                logger.LogError(e, e.Message);
            }
        }

        private string MakeErrorResponse(string message)
        {
            var errorObject = ResponseModelWrapper.CreateError(message);
            return JsonConvert.SerializeObject(errorObject);
        }
    }
}