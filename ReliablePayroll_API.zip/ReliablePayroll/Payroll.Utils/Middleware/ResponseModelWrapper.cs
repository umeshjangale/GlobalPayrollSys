﻿using Newtonsoft.Json;
using System.Dynamic;

namespace Payroll.Utils.Middleware
{
    public enum ResponseStatus
    {
        Info = 0,
        Success = 1,
        Error = 2
    }

    public class ResponseModelWrapper<T> where T : class
    {
        [JsonProperty("status")]
        public ResponseStatus Status { get; set; }

        [JsonProperty("data")]
        public T Data { get; }

        [JsonProperty("lookups")]
        public dynamic Lookups { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        public ResponseModelWrapper(T model)
        {
            Status = ResponseStatus.Info;
            Data = model;
            Lookups = new ExpandoObject();
        }
    }

    public static class ResponseModelWrapper
    {
        public static ResponseModelWrapper<object> CreateSuccess(string message, object data = null)
        {
            return new ResponseModelWrapper<object>(data)
            {
                Status = ResponseStatus.Success,
                Message = message
            };
        }

        public static ResponseModelWrapper<T> CreateSuccess<T>(string message, T data = null) where T : class
        {
            return new ResponseModelWrapper<T>(data)
            {
                Status = ResponseStatus.Success,
                Message = message
            };
        }

        public static ResponseModelWrapper<object> CreateError(string message, object data = null)
        {
            return new ResponseModelWrapper<object>(data)
            {
                Status = ResponseStatus.Error,
                Message = message
            };
        }

        public static ResponseModelWrapper<T> CreateError<T>(string message, T data = null) where T : class
        {
            return new ResponseModelWrapper<T>(data)
            {
                Status = ResponseStatus.Error,
                Message = message
            };
        }

        public static ResponseModelWrapper<object> CreateInfo(string message, object data = null)
        {
            return new ResponseModelWrapper<object>(data)
            {
                Status = ResponseStatus.Info,
                Message = message
            };
        }

        public static ResponseModelWrapper<T> CreateInfo<T>(string message, T data = null) where T : class
        {
            return new ResponseModelWrapper<T>(data)
            {
                Status = ResponseStatus.Info,
                Message = message
            };
        }
    }
}