﻿using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using MsLogLevel = Microsoft.Extensions.Logging.LogLevel;

namespace Payroll.Utils.Logging
{
    public class LoggingConfiguration
    {
        public LogLevel? LogLevel { get; set; }
        public LogLevel? EFLogLevel { get; set; }
        public string LogstashUri { get; set; }
        public string LogFile { get; set; }
        public bool LogArguments { get; set; }
        public bool DisableConsole { get; set; }
        public bool DetailedConsole { get; set; }

        private static readonly Dictionary<MsLogLevel, LogEventLevel> serilogLevelMapper = new Dictionary<MsLogLevel, LogEventLevel>
        {
            { MsLogLevel.Trace, LogEventLevel.Verbose },
            { MsLogLevel.Debug, LogEventLevel.Debug },
            { MsLogLevel.Information, LogEventLevel.Information },
            { MsLogLevel.Warning, LogEventLevel.Warning },
            { MsLogLevel.Error, LogEventLevel.Error },
            { MsLogLevel.Critical, LogEventLevel.Fatal },
            { MsLogLevel.None, LogEventLevel.Fatal },
        };

        private static readonly Dictionary<LogEventLevel, int> severityMapper = new Dictionary<LogEventLevel, int>
        {
            { LogEventLevel.Verbose, 6 },
            { LogEventLevel.Debug, 0 },
            { LogEventLevel.Information, 1 },
            { LogEventLevel.Warning, 2 },
            { LogEventLevel.Error, 3 },
            { LogEventLevel.Fatal, 5 }
        };

        private class PropertyEnricher : ILogEventEnricher
        {
            public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
            {
                string typeName = String.Empty;
                if (logEvent.Properties.TryGetValue("SourceContext", out var propertyValue))
                    typeName = propertyValue.ToString().Trim(new[] { '"', ' ' });
                var pos = typeName.LastIndexOf('.');
                typeName = typeName.Substring(pos + 1, typeName.Length - pos - 1);
                logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty("SourceContext", typeName));
                logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty("ThreadId", Thread.CurrentThread.ManagedThreadId));
                logEvent.AddOrUpdateProperty(propertyFactory.CreateProperty("Severity", severityMapper[logEvent.Level]));
            }
        }

        public void Setup(ILoggerFactory loggerFactory)
        {
            // General logging configuration
            var level = serilogLevelMapper[LogLevel.GetValueOrDefault(MsLogLevel.Information)];
            var efLogLevel = serilogLevelMapper[EFLogLevel.GetValueOrDefault(MsLogLevel.Warning)];
            var serilogConfig = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .Enrich.WithProperty("ApplicationName", Assembly.GetEntryAssembly().GetName(true).Name)
                .Enrich.With<PropertyEnricher>()
                .MinimumLevel.Is(level)

                // Configure EntityMeta Framework logging differently
                .MinimumLevel.Override("Microsoft.EntityFrameworkCore", efLogLevel);

            // Logstash sink
            if (!String.IsNullOrEmpty(LogstashUri))
            {
                serilogConfig.WriteTo.LogstashHttp(LogstashUri);
            }

            // Rolling File sink
            if (!string.IsNullOrEmpty(LogFile))
            {
                serilogConfig.WriteTo.RollingFile(
                    pathFormat: LogFile,
                    outputTemplate: "{Severity}\t{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz}\t{{{ThreadId:X4}}}\t[{SourceContext}]\t{RequestId} {Scope}\t{Message}{NewLine}{Exception}",
                    fileSizeLimitBytes: 1073741824,
                    retainedFileCountLimit: 31,
                    buffered: false,
                    shared: false
                );
            }

            //if (!DisableConsole)
            //{
            //    // Console sink
            //    serilogConfig.WriteTo.Console(
            //        outputTemplate:
            //            DetailedConsole
            //            ? "{Severity}\t{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz}\t{{{ThreadId:X4}}}\t[{SourceContext}]\t{RequestId} {Scope}\t{Message}{NewLine}{Exception}"
            //            : "[{Timestamp:HH:mm:ss} {SourceContext} {RequestId} {Level:u3}] {Message:lj}{NewLine}{Exception}"
            //    );
            //}

            // Create the Serilog logger
            Log.Logger = serilogConfig.CreateLogger();
            loggerFactory.AddSerilog();
        }
    }
}