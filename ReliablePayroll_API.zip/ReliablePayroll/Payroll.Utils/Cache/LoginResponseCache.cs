﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Payroll.Entities.Login;
using Payroll.Utils.Auth;
using System;

namespace Payroll.Utils.Cache
{
    public class LoginResponseCache : ILoginResponseCache
    {
        private readonly IMemoryCache memCache;
        public JwtAppSettingOptions JwtSettings { get; }

        public LoginResponseCache(IMemoryCache cache, IOptions<JwtAppSettingOptions> jwtSettings)
        {
            JwtSettings = jwtSettings.Value;
            memCache = cache;
        }

        public void Add(string userId, LoginResponse loginResponse) =>
            memCache.Set(userId, loginResponse, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromSeconds(JwtSettings.ValidForSeconds)));

        public void Remove(string userId) => memCache.Remove(userId);

        public LoginResponse Get(string userId) => memCache.Get<LoginResponse>(userId);
    }

    public class OtpCache : IOtpCache
    {
        private readonly IMemoryCache memCache;

        public OtpCache(IMemoryCache cache)
        {
            memCache = cache;
        }

        public void Add(string userId, string otp) =>
            memCache.Set(userId, otp, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(10)));

        public void Remove(string userId) => memCache.Remove(userId);

        public string Get(string userId) => memCache.Get<string>(userId);

        public void AddRemeberToken(string userId, string otp) =>
            memCache.Set(userId, otp, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromDays(30)));

        public void RemoveRemeberToken(string userId) => memCache.Remove(userId);

        public string GetRemeberToken(string userId) => memCache.Get<string>(userId);
    }
}