﻿using Payroll.Entities.Login;

namespace Payroll.Utils.Cache
{
    public interface ILoginResponseCache
    {
        void Add(string userId, LoginResponse loginResponse);

        void Remove(string userId);

        LoginResponse Get(string userId);
    }

    public interface IOtpCache
    {
        void Add(string userId, string otp);

        void Remove(string userId);

        string Get(string userId);

        void AddRemeberToken(string userId, string token);

        void RemoveRemeberToken(string userId);

        string GetRemeberToken(string userId);
    }
}