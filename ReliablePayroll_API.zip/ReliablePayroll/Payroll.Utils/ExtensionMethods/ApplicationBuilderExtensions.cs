﻿using Microsoft.AspNetCore.Builder;
using Payroll.Utils.Middleware;

namespace Payroll.Utils.ExtensionMethods
{
    public static class ApplicationBuilderExtensions
    {
        /// <summary>
        /// Configure the HTTP-communication stack, adding additionalAuthorizationMiddlewares params will be inserted between ServiceContextMiddleware and ServiceMiddleware
        /// </summary>
        /// <param name="additionalAuthorizationMiddlewares"></param>
        /// <returns>IApplicationBuilder</returns>
        public static IApplicationBuilder UseHttp(this IApplicationBuilder app)
        {
            return app.UseMiddleware<ServiceMiddleWare>();
        }
    }
}