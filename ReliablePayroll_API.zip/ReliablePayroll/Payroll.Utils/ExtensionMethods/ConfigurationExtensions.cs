﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Payroll.Utils.ExtensionMethods
{
    public static class ConfigurationExtensions
    {
        private static HashSet<string> environmentVariablesToLog = new HashSet<string>(new[] { "ASPNETCORE_ENVIRONMENT" }, StringComparer.InvariantCultureIgnoreCase);

        /// <summary>
        /// Logs the current configuration including the source of each setting
        /// Also a list of environment variables specified by <c>environmentVariablesToLog</c> will be logged.
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="loggerFactory"></param>
        /// <returns></returns>
        public static IConfigurationRoot LogConfiguration(this IConfigurationRoot configuration, ILoggerFactory loggerFactory)
        {
            ILogger logger = loggerFactory.CreateLogger("LogConfiguration");

            // Unfortunately the Data-property is protected, so we use Reflection here
            PropertyInfo dataProperty = typeof(ConfigurationProvider).GetProperty("Data", BindingFlags.NonPublic | BindingFlags.Instance);

            // Find all Keys/Paths' of the Json configuration files
            var configFileInfo = configuration.Providers
                .Select((it, i) => new { Provider = it as JsonConfigurationProvider, Index = i })
                .Where(it => it.Provider != null)
                .SelectMany(it => (IDictionary<string, string>)dataProperty.GetValue(it.Provider),
                    (a, b) => new { a.Provider.Source.Path, a.Index, b.Key, IsFile = true });

            // Find all Keys of the Environment variables
            var environmentInfo = configuration.Providers
                .Select((it, i) => new { Provider = it as Microsoft.Extensions.Configuration.EnvironmentVariables.EnvironmentVariablesConfigurationProvider, Index = i })
                .Where(it => it.Provider != null)
                .SelectMany(it => (IDictionary<string, string>)dataProperty.GetValue(it.Provider),
                    // On some platforms a colon is not supported but double underscores will be used instead
                    (a, b) => new { Path = "ENV", a.Index, Key = b.Key.Replace("__", ":"), IsFile = false });

            var combinedInfo = configFileInfo.Concat(environmentInfo);

            // Combine by grouping on Key
            var grouped = combinedInfo.GroupBy(it => it.Key, StringComparer.InvariantCultureIgnoreCase)
                // Filter on environment variables - they should either override the Json configuration file or appear in environmentVariablesToLog
                .Where(it => it.Any(info => info.IsFile) || environmentVariablesToLog.Contains(it.Key))
                // The one with the highest index determines the result
                .Select(it => it.OrderBy(info => info.Index).Last())
                .ToList();

            foreach (var logs in grouped)
            {
                logger.LogInformation("{Key} = {Value} [{Path}]", logs.Key, configuration.GetValue<string>(logs.Key), logs.Path);
            }
            return configuration;
        }
    }
}