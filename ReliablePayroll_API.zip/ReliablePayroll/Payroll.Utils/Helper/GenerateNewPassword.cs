﻿using Payroll.Entities.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;

namespace Payroll.Utils.Helper
{
    public static class GenerateNewPassword
    {
        public static string GenerateRandomPassword(IdentitySettings opts)
        {
            if (opts == null) opts = new IdentitySettings()
            {
                RequiredLength = 8,
                RequiredUniqueChars = 3,
                RequireDigit = true,
                RequireLowercase = true,
                RequireNonAlphanumeric = true,
                RequireUppercase = true
            };

            string[] randomChars = new[] {
                "ABCDEFGHJKLMNOPQRSTUVWXYZ",    // uppercase
                "abcdefghijkmnopqrstuvwxyz",    // lowercase
                "0123456789",                   // digits
                "!@$?_-"                        // non-alphanumeric
            };
            Random rand = new Random(Environment.TickCount);
            List<char> chars = new List<char>();

            if (opts.RequireUppercase)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[0][rand.Next(0, randomChars[0].Length)]);

            if (opts.RequireLowercase)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[1][rand.Next(0, randomChars[1].Length)]);

            if (opts.RequireDigit)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[2][rand.Next(0, randomChars[2].Length)]);

            if (opts.RequireNonAlphanumeric)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[3][rand.Next(0, randomChars[3].Length)]);

            for (int i = chars.Count; i < opts.RequiredLength
                || chars.Distinct().Count() < opts.RequiredUniqueChars; i++)
            {
                string rcs = randomChars[rand.Next(0, randomChars.Length)];
                chars.Insert(rand.Next(0, chars.Count),
                    rcs[rand.Next(0, rcs.Length)]);
            }

            return new string(chars.ToArray());
        }
    }

    public static class GenerateNewOtp
    {
        public static string GetRandomOtpNumber(int min, int max)
        {
            Random _random = new Random();
            return _random.Next(min, max).ToString("D5");
        }
    }

    public static class GenerateIdByEmailHost
    {
        public static string GetCompanyCode(string email)
        {
            var domain = new MailAddress(email).Host;
            domain = domain.Substring(0, domain.IndexOf('.'));
            return domain.ToUpper();
        }
    }
}