﻿namespace Payroll.Entities
{
    public class LoginEntity
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string CompanyCode { get; set; }
        public string OtpRememberToken { get; set; }
    }

    public class OtpEntity
    {
        public string UserName { get; set; }
        public string CompanyCode { get; set; }
        public string Otp { get; set; }
        public bool RememberLogin { get; set; }
        public string OtpToken { get; set; }
    }
}