﻿namespace Payroll.Entities.Login
{
    public class ServerSettings
    {
        public string ServerName { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public string IntegratedSequirity { get; set; }
    }
}