﻿namespace Payroll.Entities.Login
{
    public class LoginResponse
    {
        public string AuthToken { get; set; }

        public string RefreshToken { get; set; }
    }
}