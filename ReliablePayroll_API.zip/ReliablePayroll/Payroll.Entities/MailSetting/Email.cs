﻿namespace Payroll.Entities.MailSetting
{
    public class Email
    {
        public string FromName { get; set; }
        public string ToAddress { get; set; }
        public string Subject { get; set; }
        public string HtmlBody { get; set; }
        public string FromAddress { get; set; }
    }
}