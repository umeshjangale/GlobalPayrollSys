﻿namespace Payroll.Entities.MailSetting
{
    public class MailSettings
    {
        public string SmtpHost { get; set; }

        public int PortNumber { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public string FromAddress { get; set; }

        public string FromName { get; set; }
    }

    public class Configuration
    {
        public string MasterConnString { get; set; }
        public string PayrollConnString { get; set; }
    }
}