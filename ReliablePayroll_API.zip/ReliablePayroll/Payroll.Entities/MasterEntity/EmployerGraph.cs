﻿namespace Payroll.Entities.MasterEntity
{
    public class EmployerGraph
    {
        public long TotalEmployer { get; set; }
        public int LatestEmployer { get; set; }
        public decimal TotalAmount { get; set; }
    }

    public class EmployerTrendsGraph
    {
        public int Year { get; set; }
        public int TotalEmployer { get; set; }
        public decimal TotalAmount { get; set; }
    }
}