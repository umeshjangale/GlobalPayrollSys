﻿namespace Payroll.Entities.MasterEntity
{
    public class EmployersEntityModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string UserId { get; set; }
        public string CompanyName { get; set; }
        public string CompanyCode { get; set; }
        public double NumberOfEmployees { get; set; }
        public bool IsActive { get; set; }
    }


    public class EmployerSearchModel
    {
        public string? EmployerName{ get; set; }
        public int NoOfEmployeeFrom { get; set; }
        public int NoOfEmployeeTo { get; set; }
        public bool EmployeeStatus { get; set; }
    }

}