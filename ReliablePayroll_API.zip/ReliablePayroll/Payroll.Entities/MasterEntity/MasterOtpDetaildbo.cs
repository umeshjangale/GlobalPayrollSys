﻿using System;

namespace Payroll.Entities.MasterEntity
{
    public class MasterOtpDetaildbo
    {
        public int id { get; set; }

        public string Otp { get; set; }
        public bool IsActive { get; set; }
        public DateTime Timer { get; set; }
    }
}