﻿using System;

namespace Payroll.Entities.MasterEntity
{
    public class SubscriptionEntity
    {
        public Guid SubscriptionId { get; set; }

        public string SubscriptionName { get; set; }

        public double Amount { get; set; }
    }

    public class RoleEntity
    {
        public string RoleId { get; set; }

        public string RoleName { get; set; }
    }

    public class FeatureEntity
    {
        public int FeatureId { get; set; }

        public string FeatureName { get; set; }
        public string Description { get; set; }
    }
}