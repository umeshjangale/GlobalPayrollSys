﻿namespace Payroll.Entities.MasterEntity
{
    public class VerifyUserEntity
    {
        public bool IsUsernameExists { get; set; }
        public bool IsEmailExists { get; set; }
    }
}