﻿namespace Payroll.Entities.MasterEntity
{
    public class SetPasswordEntity
    {
        public string UserName { get; set; }
        public string NewPassword { get; set; }
        public string TenantName { get; set; }
    }
}