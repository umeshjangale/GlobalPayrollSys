﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class Country
    {
        public static List<CountryEntity> GetCountryList()
        {
            var countries = new List<CountryEntity>()
            {
                new CountryEntity{Name = "United States", CountryCode ="US"}
            };
            return countries;
        }
    }
}
