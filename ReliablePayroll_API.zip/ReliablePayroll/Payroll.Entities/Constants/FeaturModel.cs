﻿using Payroll.Entities.MasterEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class FeaturModel
    {
        public static List<FeatureListModel> GetFeatureList()
        {
            var featureList = new List<FeatureListModel>()
            {
                new FeatureListModel {
                FeatureName = "Super Admin",
                Description = "This features allows to view admin dashbaord and details of all employers and their employees",
                Code = "SuperAdmin"
                },
                new FeatureListModel {
                FeatureName = "Provide Payroll",
                Description = "This feature allows to see settings page with features excluding 'Super Admin Access' and Employers will be allowed to provide access to features to their employee",
                Code = "Payroll"
                },
                new FeatureListModel {
                FeatureName = "View and Add Employee",
                Description = "This feature allows to see settings page with features excluding 'Super Admin Access' and Employers will be allowed to provide access to features to their employee",
                Code = "ViewEditEmpoyee"
                },
                new FeatureListModel {
                FeatureName = "Run Payroll",
                Description = "This features allows process the payroll of employees",
                Code = "RunPayroll"
                },
                new FeatureListModel {
                FeatureName = "View/Edit Employer",
                Description = "This features allows to view employer info and/or update their details",
                Code = "ViewEditEmployer"
                },
                new FeatureListModel {
                FeatureName = "View/Edit Employer Bank",
                Description = "This features allows to view and/or update bank account info",
                Code = "ViewEditEmployerBank"
                },
                new FeatureListModel {
                FeatureName = "Add or View Pay Frequency",
                Description = "This features allows to add a new pay frequency and also allows to view and/or update pay frequency",
                Code = "AddViewPayFrequency"
                },
                new FeatureListModel {
                FeatureName = "View/Edit Tax Info",
                Description = "This features allows to view and/or update tax info",
                Code = "ViewEditTax"
                },
                new FeatureListModel {
                FeatureName = "Add or View Earnings Deductions",
                Description = "This features allows to add a new earnings and/or deductions and also allows to view and/or update the exsiting earnings and deductions",
                Code = "AddViewEarningDeductiions"
                },
                new FeatureListModel {
                FeatureName = "Add or View Paid Time Off",
                Description = "This features allows to add a new PTO and to update existing PTO",
                Code = "AddViewPaidTimeOff"
                },
                new FeatureListModel {
                FeatureName = "View and print Employer Tax Reports",
                Description = "This Features allows to view all the tax reports, update and print them",
                Code = "ViewPrintEmployerTaxReports"
                },
                new FeatureListModel {
                FeatureName = "View Employee reports",
                Description = "This features allows to view reports related to the payroll of their employees",
                Code = "ViewEmployeeReports"
                },
                new FeatureListModel {
                FeatureName = "View Paystub",
                Description = "This feature allows to view paystub of employee of their associated company",
                Code = "ViewPayStub"
                },
                new FeatureListModel {
                FeatureName = "View Earnings and Deductions",
                Description = "This feature allows to view earnings and deductions of employee of their associated company",
                Code = "ViewEarningDeductions"
                },
            };
            return featureList;
        }
    }
}