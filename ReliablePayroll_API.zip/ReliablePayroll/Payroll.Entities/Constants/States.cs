﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class States
    {
        public static List<StateEntity> GetStateList()
        {
            var province = new List<StateEntity>()
            {
                new StateEntity{ Name ="Alabama", StateCode="AL", CountryId = 1 },
                new StateEntity{ Name ="Alaska", StateCode="AK", CountryId = 1 },
                new StateEntity{ Name ="Arizona", StateCode="AZ", CountryId = 1 },
                new StateEntity{ Name ="Arkansas", StateCode="AR", CountryId = 1 },
                new StateEntity{ Name ="California", StateCode="CA", CountryId = 1 },
                new StateEntity{ Name ="Colorado", StateCode="CO", CountryId = 1 },
                new StateEntity{ Name ="Connecticut", StateCode="CT", CountryId = 1 },
                new StateEntity{ Name ="Delaware", StateCode="DE", CountryId = 1 },
                new StateEntity{ Name ="Florida", StateCode="FL", CountryId = 1 },
                new StateEntity{ Name ="Georgia", StateCode="GA", CountryId = 1 },
                new StateEntity{ Name ="Hawaii", StateCode="HI", CountryId = 1 },
                new StateEntity{ Name ="Idaho", StateCode="ID", CountryId = 1 },
                new StateEntity{ Name ="Illinois", StateCode="IL", CountryId = 1 },
                new StateEntity{ Name ="Indiana", StateCode="IN", CountryId = 1 },
                new StateEntity{ Name ="Iowa", StateCode="IA", CountryId = 1 },
                new StateEntity{ Name ="Kansas", StateCode="KS", CountryId = 1 },
                new StateEntity{ Name ="Kentucky", StateCode="KY", CountryId = 1 },
                new StateEntity{ Name ="Louisiana", StateCode="LA", CountryId = 1 },
                new StateEntity{ Name ="Maine", StateCode="ME", CountryId = 1 },
                new StateEntity{ Name ="Maryland", StateCode="MD", CountryId = 1 },
                new StateEntity{ Name ="Massachusetts", StateCode="MA", CountryId = 1 },
                new StateEntity{ Name ="Michigan", StateCode="MI", CountryId = 1 },
                new StateEntity{ Name ="Minnesota", StateCode="MN", CountryId = 1 },
                new StateEntity{ Name ="Mississippi", StateCode="MS", CountryId = 1 },
                new StateEntity{ Name ="Missouri", StateCode="MO", CountryId = 1 },
                new StateEntity{ Name ="Montana", StateCode="MT", CountryId = 1 },
                new StateEntity{ Name ="Nebraska", StateCode="NE", CountryId = 1 },
                new StateEntity{ Name ="Nevada", StateCode="NV", CountryId = 1 },
                new StateEntity{ Name ="New Hampshire", StateCode="NH", CountryId = 1 },
                new StateEntity{ Name ="New Jersey", StateCode="NJ", CountryId = 1 },
                new StateEntity{ Name ="New Mexico", StateCode="NM", CountryId = 1 },
                new StateEntity{ Name ="New York", StateCode="NY", CountryId = 1 },
                new StateEntity{ Name ="North Carolina", StateCode="NC", CountryId = 1 },
                new StateEntity{ Name ="North Dakota", StateCode="ND", CountryId = 1 },
                new StateEntity{ Name ="Ohio", StateCode="OH", CountryId = 1 },
                new StateEntity{ Name ="Oklahoma", StateCode="OK", CountryId = 1 },
                new StateEntity{ Name ="Oregon", StateCode="OR", CountryId = 1 },
                new StateEntity{ Name ="Pennsylvania", StateCode="PA", CountryId = 1 },
                new StateEntity{ Name ="Rhode Island", StateCode="RI", CountryId = 1 },
                new StateEntity{ Name ="South Carolina", StateCode="SC", CountryId = 1 },
                new StateEntity{ Name ="South Dakota", StateCode="SD", CountryId = 1 },
                new StateEntity{ Name ="Tennessee", StateCode="TN", CountryId = 1 },
                new StateEntity{ Name ="Texas", StateCode="TX", CountryId = 1 },
                new StateEntity{ Name ="Utah", StateCode="UT", CountryId = 1 },
                new StateEntity{ Name ="Vermont", StateCode="VT", CountryId = 1 },
                new StateEntity{ Name ="Virginia", StateCode="VA", CountryId = 1 },
                new StateEntity{ Name ="Washington", StateCode="WA", CountryId = 1 },
                new StateEntity{ Name ="West Virginia", StateCode="WV", CountryId = 1 },
                new StateEntity{ Name ="Wisconsin", StateCode="WI", CountryId = 1 },
                new StateEntity{ Name ="Wyoming", StateCode="WY", CountryId = 1 }
            };
            return province;
        }
    }
}
