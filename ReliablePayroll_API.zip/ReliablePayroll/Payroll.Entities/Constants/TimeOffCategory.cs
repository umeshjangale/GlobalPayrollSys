﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class TimeOffCategory
    {
        public static List<TimeOffCategoryEntity> GetTimeOffCategoryList()
        {
            var timeOffCategories = new List<TimeOffCategoryEntity>()
            {
                new TimeOffCategoryEntity{TimeOffCategoryName = "Sick",IsActive=true},
                new TimeOffCategoryEntity{TimeOffCategoryName = "Vacation",IsActive=true},
                new TimeOffCategoryEntity{TimeOffCategoryName = "Paid time off",IsActive=true},
                new TimeOffCategoryEntity{TimeOffCategoryName = "Unpaid time off",IsActive=true}
            };
            return timeOffCategories;
        }
    }
}