﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class AccrualFrequency
    {
        public static List<AccrualFrequencyEntity> GetAccrualFrequencyList()
        {
            var accrualFrequencyEntities = new List<AccrualFrequencyEntity>()
            {
                new AccrualFrequencyEntity{AccrualFrequencyName = "At beginning of year",IsActive=true},
                new AccrualFrequencyEntity{AccrualFrequencyName = "Each pay period",IsActive=true},
                new AccrualFrequencyEntity{AccrualFrequencyName = "Per hour worked",IsActive=true},
                new AccrualFrequencyEntity{AccrualFrequencyName = "On anniversary date",IsActive=true},
                new AccrualFrequencyEntity{AccrualFrequencyName = "Unlimited",IsActive=true}
            };
            return accrualFrequencyEntities;
        }
    }
}