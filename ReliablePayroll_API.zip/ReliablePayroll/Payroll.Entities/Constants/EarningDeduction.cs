﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public class EarningDeduction
    {
        public static List<EarningDeductionEntity> GetEarningDeductionList()
        {
            var earningDeductionEntities = new List<EarningDeductionEntity>()
            {
                new EarningDeductionEntity{Name = "Paid Time Off",IsActive=true},
                new EarningDeductionEntity{Name = "Fringe Benefits",IsActive=true},
                new EarningDeductionEntity{Name = "Reimbersed expenses",IsActive=true},
                new EarningDeductionEntity{Name = "Unions",IsActive=true},
            };
            return earningDeductionEntities;
        }
    }
}