﻿namespace Payroll.Entities.Constants
{
    public enum PaymentStatus
    {
        Paid = 1,
        Failed = 2,
        Pending = 3,
        unauthorised = 4
    }
}
