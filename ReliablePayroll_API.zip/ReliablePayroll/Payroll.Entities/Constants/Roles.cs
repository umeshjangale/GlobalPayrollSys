﻿namespace Payroll.Entities.Constants
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string Employee = "Employee";
        public const string Employer = "Employer";
    }

    public static class Subscriptions
    {
        public const string CorePlan = "Core Plan";
        public const string CompletePlan = "Complete Plan";
    }

    public static class EmailConstants
    {
        public const string CompanyLogo = "<div style='background-color:#007bff;'><img src='cid:companyEmailLogo' alt='Image' style='display:block;margin:0 auto'/></div> <br>";
        public const string ButtonStyle = "style='display:block;width:115px;height:25px;background:#007bff;padding:10px;text-align:center;border-radius:5px;color:white;font-weight:bold;line-height:25px'";
    }
}