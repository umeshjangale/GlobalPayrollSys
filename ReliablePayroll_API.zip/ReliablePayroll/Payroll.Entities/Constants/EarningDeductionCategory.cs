﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;

namespace Payroll.Entities.Constants
{
    public static class EarningDeductionCategory
    {
        public static List<EarningDeductionCategoryEntity> GetEarningDeductionCategoryList()
        {
            var earningDeductionCategoryEntities = new List<EarningDeductionCategoryEntity>()
            {
                new EarningDeductionCategoryEntity{CategoryName = "Paid Time Off",IsActive=true},
                new EarningDeductionCategoryEntity{CategoryName = "Fringe Benefits",IsActive=true},
                new EarningDeductionCategoryEntity{CategoryName = "Reimbersed expenses",IsActive=true},
                new EarningDeductionCategoryEntity{CategoryName = "Unions",IsActive=true},
            };
            return earningDeductionCategoryEntities;
        }
    }
}