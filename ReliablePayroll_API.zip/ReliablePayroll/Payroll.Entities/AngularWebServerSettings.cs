﻿namespace Payroll.Entities
{
    public class AngularWebServerSettings
    {
        public string WebUrl { get; set; }
    }
}