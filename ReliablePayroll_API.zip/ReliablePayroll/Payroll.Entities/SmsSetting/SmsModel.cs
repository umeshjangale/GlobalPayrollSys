﻿namespace Payroll.Entities.SmsSetting
{
    public class SmsModel
    {
        public string ToPhoneNumber { get; set; }
        public string MessageBody { get; set; }
    }
}