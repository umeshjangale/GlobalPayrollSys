﻿namespace Payroll.Entities.PayrollEntity
{
    public class CountryEntity
    {
        public int CountryId { get; set; }
        public string Name { get; set; }
        public string CountryCode { get; set; }
    }
}
