﻿using System;

namespace Payroll.Entities.PayrollEntity
{
    public class TerminationEntity
    {
        public long TerminationId { get; set; }
        public string TerminationReason { get; set; }
        public DateTime? TerminationDate { get; set; }
        public DateTime? LastDateOfWork { get; set; }
        public string LengthOfService { get; set; }
        public string UserId { get; set; }
    }
}