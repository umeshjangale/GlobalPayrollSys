﻿namespace Payroll.Entities.PayrollEntity
{
    public class WorkContactEntity
    {
        public long WorkContactId { get; set; }

        public string UserId { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string City { get; set; }

        public int StateId { get; set; }

        public string ZipCode { get; set; }

        public string WorkPhoneNumber { get; set; }
        public string WorkEmail { get; set; }
    }
}