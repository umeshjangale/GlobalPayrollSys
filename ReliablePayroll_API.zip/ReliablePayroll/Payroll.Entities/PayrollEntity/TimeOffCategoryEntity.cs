﻿namespace Payroll.Entities.PayrollEntity
{
    public class TimeOffCategoryEntity
    {
        public int TimeOffCategoryId { get; set; }

        public string TimeOffCategoryName { get; set; }

        public bool IsActive { get; set; }
    }
}