﻿namespace Payroll.Entities.PayrollEntity
{
    public class PaidTimeOffEntity
    {
        public long PaidTimeOffId { get; set; }

        public int TimeOffCategoryId { get; set; }

        public string TimeOffCategoryName { get; set; }

        public string Description { get; set; }

        public int AccrualFrequencyId { get; set; }

        public string AccrualFrequencyName { get; set; }

        public string HoursEarnedPerYear { get; set; }

        public string MaximumAvailable { get; set; }
    }
}