﻿namespace Payroll.Entities.PayrollEntity
{
    public class BankAccountInfoEntity
    {
        public int BankAccountInfoId { get; set; }

        public bool ActivateEmpDirectDeposit { get; set; }

        public string Name { get; set; }

        public string RoutingNumber { get; set; }

        public string AccountNumber { get; set; }

        public bool IncludeEmpAddressOnCheck { get; set; }

        public string NameAndAddressOrTransitNumber { get; set; }

        public bool ShouldPrintOnCheck { get; set; }

        public bool PrintBusinessPhoneOnPayStube { get; set; }
        
    }
}