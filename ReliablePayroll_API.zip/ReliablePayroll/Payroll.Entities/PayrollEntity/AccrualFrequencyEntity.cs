﻿namespace Payroll.Entities.PayrollEntity
{
    public class AccrualFrequencyEntity
    {
        public int AccrualFrequencyId { get; set; }

        public string AccrualFrequencyName { get; set; }

        public bool IsActive { get; set; }
    }
}