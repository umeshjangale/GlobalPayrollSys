﻿using System;

namespace Payroll.Entities.PayrollEntity
{
    public class EmployerTaxInfoEntity
    {
        public int TaxInfoId { get; set; }
        public string UserId { get; set; }
        public string EIN { get; set; }
        public string StateUIN { get; set; }
        public string IncomeTaxState { get; set; }
        public DepositFrerquency DepositFrerquency { get; set; }        
        public DateTime EffectiveDate { get; set; }
        public decimal SUIRate { get; set; }

        //Is Company Exempt From Federal Unemployment Tax
        public bool IsCompanyExemptFromFUTA { get; set; }

        public bool IsEmployeeWorkingInThisState { get; set; }
        public string CompanyType { get; set; }
        public TaxType TaxType { get; set; }
        public string TaxTypeName { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
    }

    public enum TaxType
    {
        StateTax = 1,
        LocalTax = 2,
        FederalTax = 3
    }

    
    public enum DepositFrerquency
    {
        // TODO: Add Deposite Frerquency enum values
    }
}