﻿namespace Payroll.Entities.PayrollEntity
{
    public class EarningDeductionCategoryEntity
    {
        public int CategoryId { get; set; }

        public string CategoryName { get; set; }

        public string UserId { get; set; }

        public CategoryType Type { get; set; }

        public bool IsActive { get; set; }
    }

    public enum CategoryType
    {
        Earning = 1,
        Deduction = 2
    }
}