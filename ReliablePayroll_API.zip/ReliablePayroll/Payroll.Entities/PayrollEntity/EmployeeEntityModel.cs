﻿using System;

namespace Payroll.Entities.PayrollEntity
{
    public class EmployeeEntityModel
    {
        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string SocialSecurityNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string EmailAddress { get; set; }

        public DateTime HireDate { get; set; }

        public bool IsPersonalTaxInfoChecked { get; set; }

        public string TIN { get; set; }

        public string CompanyName { get; set; }

        public bool IsContractor { get; set; }
    }

    public class EmployeeEntityViewModel
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string PhoneNumber { get; set; }
        public bool IsContractor { get; set; }
        public string Status { get; set; }
    }

    public class EmployeeSearchModel
    {
        public DateTime? JoiningDateFrom { get; set; }
        public DateTime? JoiningDateTo { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public EmployeeStatus EmployeeStatus { get; set; }
    }

    public enum EmployeeStatus
    {
        // All value we are using to get all employee list
        All = 0,
        Active = 1,
        InActive = 2,
        Terminate = 3,
        NewHire = 4
    }
}