﻿namespace Payroll.Entities.PayrollEntity
{
    public class EmployerEarningEntity
    {
        public int EmployerEarningId { get; set; }

        public string UserId { get; set; }

        public int CategoryId { get; set; }

        public int EarningDeductionId { get; set; }

        public string Description { get; set; }

        public bool W2Box14 { get; set; }

        public string W2Box14Literal { get; set; }

        public string Name { get; set; }

        public string WorksheetName { get; set; }

        public bool IsAmountEnabled { get; set; }

        public bool IsHoursEnabled { get; set; }
    }
}