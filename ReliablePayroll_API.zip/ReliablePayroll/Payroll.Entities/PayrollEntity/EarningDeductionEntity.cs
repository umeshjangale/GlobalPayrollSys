﻿namespace Payroll.Entities.PayrollEntity
{
    public class EarningDeductionEntity
    {
        public int EarningDeductionId { get; set; }

        public string UserId { get; set; }

        public string CategoryId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; }
    }
}