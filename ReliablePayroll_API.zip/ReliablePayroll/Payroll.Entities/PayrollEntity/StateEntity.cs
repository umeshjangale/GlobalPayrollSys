﻿namespace Payroll.Entities.PayrollEntity
{
    public class StateEntity
    {
        public int StateId { get; set; }
        public string Name { get; set; }
        public string StateCode { get; set; }
        public int CountryId { get; set; }
    }
}
