﻿using System;

namespace Payroll.Entities.PayrollEntity
{
    public class EmploymentInfoEntity
    {
        public string UserId { get; set; }

        public DateTime HireDate { get; set; }

        public string SocialSecurityNumber { get; set; }

        public DateTime BirthDate { get; set; }

        public string GenderId { get; set; }

        public long TerminationId { get; set; }

        public DateTime TerminationDate { get; set; }

        public DateTime LastDayWorked { get; set; }

        public string TerminationReason { get; set; }

        public bool CompanyPaidPension { get; set; }

        public bool JobTaxCredit { get; set; }

        public bool StatutoryEmployee { get; set; }

        public string EmployeeStatus { get; set; }
    }
}