﻿namespace Payroll.Entities.PayrollEntity
{
    public class TerminationReasonEntity
    {
        public int TerminationReasonId { get; set; }
        public string Reason { get; set; }
    }
}