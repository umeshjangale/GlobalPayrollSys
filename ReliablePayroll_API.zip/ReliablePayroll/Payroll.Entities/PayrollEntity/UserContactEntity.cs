﻿namespace Payroll.Entities.PayrollEntity
{
    public class UserContactEntity
    {
        public long UserContactId { get; set; }

        public string UserId { get; set; }

        public string FirstName { get; set; }

        public string MiddleInitial { get; set; }

        public string LastName { get; set; }

        public string PreferredName { get; set; }

        public string AlternateName { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string City { get; set; }

        public int StateId { get; set; }

        public string ZipCode { get; set; }

        public string HomePhoneNumber { get; set; }

        public string WorkPhoneNumber { get; set; }

        public string WorkExtension { get; set; }

        public string AlternatePhoneNumber { get; set; }

        public string AlternateExtension { get; set; }
    }
}