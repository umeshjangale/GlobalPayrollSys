﻿using System;

namespace Payroll.Entities.PayrollEntity
{
    public class PayFrequencyEntity
    {
        public int PayFrequencyId { get; set; }

        public string PayFrequencyType { get; set; }

        public DateTime CheckDate { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}