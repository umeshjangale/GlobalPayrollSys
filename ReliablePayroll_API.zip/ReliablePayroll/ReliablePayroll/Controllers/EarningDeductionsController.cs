﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Services.PayrollServices.Contracts;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EarningDeductionsController : ControllerBase
    {
        private readonly IEarningDeductionService earningDeductionService;

        public EarningDeductionsController(IEarningDeductionService earningDeductionService)
        {
            this.earningDeductionService = earningDeductionService;
        }
    }
}