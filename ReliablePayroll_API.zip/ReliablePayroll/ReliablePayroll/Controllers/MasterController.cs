﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.MasterEntity;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Utils.Middleware;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly IMasterUserService masterService;

        public MasterController(IMasterUserService masterService)
        {
            this.masterService = masterService;
        }

        [HttpGet]
        public async Task<ResponseModelWrapper<LoggedInUserEntity>> GeLoginUser()
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.GetUserAsync());
        }

        [HttpPost]
        [Route("signup")]
        public async Task<ResponseModelWrapper<object>> SignUp([FromBody] MasterSignupEntity signupModel)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.SignUpUserAsync(signupModel));
        }

        [HttpGet]
        [Route("verifyuser")]
        public async Task<ResponseModelWrapper<object>> VerifyUser(string UserName)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.VerifyUserAsync(UserName));
        }

        [HttpPost]
        [Route("resetpassword")]
        public async Task<ResponseModelWrapper<object>> ResetPassword([FromBody] ForgotPasswordModel forgotPassword)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.ResetUserPasswordAsync(forgotPassword));
        }

        [HttpGet]
        [Route("subscriptions")]
        public async Task<ResponseModelWrapper<IEnumerable<SubscriptionEntity>>> GetSubscriptions()
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.GetSubscriptionAsync());
        }

        [HttpGet]
        [Route("roles")]
        public async Task<ResponseModelWrapper<IEnumerable<RoleEntity>>> GetRoles()
        {
            IEnumerable<RoleEntity> roles = await masterService.GetRolesAsync();
            return ResponseModelWrapper.CreateSuccess(string.Empty, roles);
        }

        [HttpGet]
        [Route("employers")]
        public async Task<ResponseModelWrapper<IEnumerable<EmployersEntityModel>>> GetEmployers([FromQuery] EmployerSearchModel employerSearchModel)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.GetEmployersAsync(employerSearchModel));
        }

        [HttpPost]
        [Route("companycode")]
        public async Task<ResponseModelWrapper<string>> AddCompanyCode([FromBody]CompanyCode companyCode)
        {
            await masterService.AddCompanyCodeAsync(companyCode.UserId);
            return ResponseModelWrapper.CreateSuccess(string.Empty, string.Empty);
        }

        [HttpGet]
        [Route("checkcompanycodeexist")]
        public async Task<ResponseModelWrapper<object>> CheckCompanyCodeExist(string companyCode)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.CheckCompanyCodeExistAsync(companyCode));
        }

        [HttpGet]
        [Route("getfeaturesbysubscriptionandrole")]
        public async Task<ResponseModelWrapper<IEnumerable<FeatureEntity>>> GetFeaturesBySubscriptionAndRole(Guid subscriptionId, Guid roleId)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await masterService.GetFeaturesBySubscriptionAndRoleAsync(subscriptionId, roleId));
        }

       
    }
}