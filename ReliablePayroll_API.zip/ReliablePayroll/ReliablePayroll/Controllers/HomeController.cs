﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Middleware;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IEmployerService employerService;

        public HomeController(IEmployerService employerService)
        {
            this.employerService = employerService;
        }

        [HttpGet]
        [Route("states")]
        public async Task<ResponseModelWrapper<IEnumerable<StateEntity>>> GetStatesAsync()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await employerService.GetStatesAsync());
        }
    }
}