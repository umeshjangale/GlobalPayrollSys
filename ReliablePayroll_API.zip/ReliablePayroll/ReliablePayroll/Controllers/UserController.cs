﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Middleware;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }

        [HttpGet]
        public async Task<ResponseModelWrapper<LoggedInUserEntity>> GeLoginUser()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.GetUserAsync());
        }

        [HttpPost]
        [Route("changepassword")]
        public async Task<IActionResult> ChangePassword(ResetPasswordModel resetPasswordModel)
        {
            await userService.ChangeUserPasswordAsync(resetPasswordModel);
            return Ok();
        }

        [HttpGet]
        [Route("verifyuser")]
        public async Task<ResponseModelWrapper<object>> VerifyUser(string UserName)
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.VerifyUserAsync(UserName));
        }

        [HttpPost]
        [Route("employee")]
        public async Task<ResponseModelWrapper<object>> AddEmployeeAsync(EmployeeEntityModel employee)
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.AddEmployeeAsync(employee, false));
        }

        [HttpPost]
        [Route("contractor")]
        public async Task<ResponseModelWrapper<object>> AddUpdateContractor(EmployeeEntityModel employee)
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.AddEmployeeAsync(employee, true));
        }

        [HttpGet]
        [Route("employees")]
        public async Task<ResponseModelWrapper<IEnumerable<EmployeeEntityViewModel>>> GetEmployees([FromQuery] EmployeeSearchModel employeeSearch)
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.GetEmployeesAsync(employeeSearch));
        }

        [HttpGet]
        [Route("employee/{userId}")]
        public async Task<ResponseModelWrapper<EmployeeEntityModel>> GetEmployeeById(string userId)
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await userService.GetEmployeeAsync(userId));
        }
    }
}