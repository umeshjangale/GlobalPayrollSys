﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Payroll.Entities;
using Payroll.Entities.Login;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Auth;
using Payroll.Utils.Cache;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using Payroll.Utils.Middleware;
using System;
using System.Net;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : Controller
    {
        private readonly IMasterUserService masterUserService;
        private readonly IUserService userService;
        private readonly IOtpCache otpCache;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IJwtFactory jwtFactory;
        private readonly ILoginResponseCache loginResponseCache;

        private const string CompanyCode = "001";
        private const string otpCachePrefix = "otp_";

        public AccountController(IMasterUserService masterUserService, IUserService userService,
            IOtpCache otpCache, IHttpContextAccessor httpContextAccessor,
            IJwtFactory jwtFactory, ILoginResponseCache loginResponseCache)
        {
            this.masterUserService = masterUserService;
            this.userService = userService;
            this.otpCache = otpCache;
            this.httpContextAccessor = httpContextAccessor;
            this.jwtFactory = jwtFactory;
            this.loginResponseCache = loginResponseCache;
        }

        [HttpPost]
        [Route("login")]
        public async Task<ResponseModelWrapper<LoginResponse>> LoginAsync([FromBody] LoginEntity loginModel)
        {
            LoginResponse loginResponse;
            string remeberToken = otpCache.GetRemeberToken(loginModel.UserName);
            if (!String.IsNullOrWhiteSpace(remeberToken) && !remeberToken.Equals(loginModel.OtpRememberToken))
            {
                remeberToken = null;
            }

            if (loginModel.CompanyCode.Equals(CompanyCode))
            {
                loginResponse = await masterUserService.LoginAsync(loginModel, remeberToken);
            }
            else
            {
                if (!(await masterUserService.CheckCompanyCodeExistAsync(loginModel.CompanyCode)))
                {
                    throw new ServiceException(HttpStatusCode.NotFound, "InvalidCompany");
                }
                loginResponse = await userService.LoginAsync(loginModel, remeberToken);
            }
            otpCache.Add(otpCachePrefix + loginModel.UserName, loginResponse.RefreshToken);
            return ResponseModelWrapper.CreateSuccess(String.Empty, loginResponse);
        }

        [HttpPost]
        [Route("otpvefication")]
        public async Task<ResponseModelWrapper<LoginResponse>> VerifyOtpAsync([FromBody] OtpEntity otpModel)
        {
            LoginResponse loginResponse;

            VerifyOtpToken(otpModel.UserName, otpModel.OtpToken);

            if (otpModel.CompanyCode.Equals(CompanyCode))
            {
                loginResponse = await masterUserService.LoginWithOtpAsync(otpModel);
            }
            else
            {
                loginResponse = await userService.LoginWithOtpAsync(otpModel);
            }
            otpCache.Remove(otpCachePrefix + otpModel.UserName);
            return ResponseModelWrapper.CreateSuccess(AddRemoveTokenFromCache(otpModel.UserName, otpModel.RememberLogin), loginResponse);
        }

        [HttpPost]
        [Route("sendotp")]
        public async Task<ResponseModelWrapper<object>> SendOtp([FromBody] OtpEntity otpModel)
        {
            VerifyOtpToken(otpModel.UserName, otpModel.OtpToken);
            if (otpModel.CompanyCode.Equals(CompanyCode))
            {
                await masterUserService.SendOtpAsync(otpModel.UserName);
            }
            else
            {
                await userService.SendOtpAsync(otpModel.UserName);
            }
            return ResponseModelWrapper.CreateSuccess(String.Empty, true);
        }

        [HttpPost]
        [Route("resetpassword/sendotp")]
        public async Task<ResponseModelWrapper<string>> ResetPasswordSendOtp([FromBody] OtpEntity otpModel)
        {
            if (otpModel.CompanyCode.Equals(CompanyCode))
            {
                await masterUserService.SendOtpAsync(otpModel.UserName);
            }
            else
            {
                await userService.SendOtpAsync(otpModel.UserName);
            }
            string refToken = jwtFactory.GenerateRefreshTokenAsync();
            otpCache.Add(otpCachePrefix + otpModel.UserName, refToken);
            return ResponseModelWrapper.CreateSuccess(String.Empty, refToken);
        }

        [HttpPost]
        [Route("resetpassword")]
        public async Task<ResponseModelWrapper<object>> ResetPassword([FromBody] ForgotPasswordModel forgotPassword)
        {
            VerifyOtpToken(forgotPassword.UserName, forgotPassword.OtpToken);
            if (forgotPassword.CompanyCode.Equals(CompanyCode))
            {
                await masterUserService.ResetUserPasswordAsync(forgotPassword);
            }
            else
            {
                if (!(await masterUserService.CheckCompanyCodeExistAsync(forgotPassword.CompanyCode)))
                {
                    throw new ServiceException(HttpStatusCode.NotFound, "InvalidCompany");
                }
                await userService.ResetUserPasswordAsync(forgotPassword);
            }
            otpCache.Remove(otpCachePrefix + forgotPassword.UserName);
            return ResponseModelWrapper.CreateSuccess(String.Empty, true);
        }

        [HttpGet]
        [Route("logout")]
        public async Task Logout()
        {
            await Task.Run(() =>
            {
                string userId = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                loginResponseCache.Remove(userId);
            });
        }

        private void VerifyOtpToken(string userName, string otpToken)
        {
            if (!otpToken.Equals(otpCache.Get(otpCachePrefix + userName)))
                throw new ServiceException(HttpStatusCode.Unauthorized, "OtpExpired");
        }

        private string AddRemoveTokenFromCache(string userName, bool rememberLogin)
        {
            otpCache.RemoveRemeberToken(userName);
            if (rememberLogin)
            {
                string otpToken = jwtFactory.GenerateRefreshTokenAsync();
                otpCache.AddRemeberToken(userName, otpToken);
                return otpToken;
            }
            return string.Empty;
        }
    }
}