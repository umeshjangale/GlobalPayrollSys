﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Middleware;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }

        [HttpPost]
        [Route("termination")]
        public async Task<ResponseModelWrapper<string>> AddUpdateTermination([FromBody] TerminationEntity terminationEntity)
        {
            await employeeService.AddUpdateTerminationyAsync(terminationEntity);           
            return ResponseModelWrapper.CreateSuccess(string.Empty, string.Empty);
        }

        [HttpGet]
        [Route("termination/{userId}")]        
        public async Task<ResponseModelWrapper<TerminationEntity>> GetTerminationByUserId(string userId)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await employeeService.GetTerminationByUserIdAsync(userId));
        }

        [HttpGet]
        [Route("workcontact/{userId}")]
        public async Task<ResponseModelWrapper<WorkContactEntity>> GetWorkContactByUserId(string userId)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await employeeService.GetWorkContactByUserIdAsync(userId));
        }

        [HttpPost]
        [Route("workcontact")]
        public async Task<ResponseModelWrapper<string>> AddUpdateWorkContact([FromBody] WorkContactEntity workContactEntity)
        {
            await employeeService.AddUpdateWorkContactAsync(workContactEntity);
            return ResponseModelWrapper.CreateSuccess(string.Empty, string.Empty);
        }

        [HttpPost]
        [Route("usercontact")]
        public async Task<ResponseModelWrapper<string>> AddUpdateUserContact(UserContactEntity userContactEntity)
        {
            await employeeService.AddUpdateUserContactAsync(userContactEntity);
            return ResponseModelWrapper.CreateSuccess(string.Empty, string.Empty);
        }

        [HttpGet]
        [Route("usercontact/{userid}")]
        public async Task<ResponseModelWrapper<UserContactEntity>> GetUserContactByUserId(string userId)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await employeeService.GetUserContactByUserIdAsync(userId));
        }

        [HttpPost]
        [Route("employmentinfo")]
        public async Task<ResponseModelWrapper<string>> UpdateEmploymentInfo(EmploymentInfoEntity employmentInfoEntity)
        {
            await employeeService.UpdateEmploymentInfoAsync(employmentInfoEntity);
            return ResponseModelWrapper.CreateSuccess(string.Empty, string.Empty);
        }

        [HttpGet]
        [Route("employmentinfo/{userid}")]
        public async Task<ResponseModelWrapper<EmploymentInfoEntity>> GetEmploymentInfoByUserId(string userId)
        {
            return ResponseModelWrapper.CreateSuccess(string.Empty, await employeeService.GetEmploymentInfoByUserIdAsync(userId));
        }
    }
}