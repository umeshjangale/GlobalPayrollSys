﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.MasterEntity;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Utils.Middleware;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterReportController : ControllerBase
    {
        private readonly IGraphService graphService;

        public MasterReportController(IGraphService graphService)
        {
            this.graphService = graphService;
        }

        [HttpGet]
        [Route("employergraphcount")]
        public async Task<ResponseModelWrapper<EmployerGraph>> GetEmployerGraphCount()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await graphService.GetEmployerGraphCountAsync());
        }

        [HttpGet]
        [Route("employertrendsgraphcount")]
        public async Task<ResponseModelWrapper<IEnumerable<EmployerTrendsGraph>>> GetEmployerTrendsGraphCount()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await graphService.GetEmployerTrendsGraphCountAsync());
        }
}
}