﻿using Microsoft.AspNetCore.Mvc;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Middleware;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ReliablePayroll.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployerController : ControllerBase
    {
        private readonly IEmployerService employerService;

        public EmployerController(IEmployerService employerService)
        {
            this.employerService = employerService;
        }

        [HttpPost]
        [Route("payfrequency")]
        public async Task<ResponseModelWrapper<string>> AddUpdatePayFrequency([FromBody] PayFrequencyEntity payFrequencyEntity)
        {
            await employerService.AddUpdatePayFrequencyAsync(payFrequencyEntity);
            return ResponseModelWrapper.CreateSuccess(String.Empty, string.Empty);
        }

        [HttpGet]
        [Route("payfrequency")]
        public async Task<ResponseModelWrapper<IEnumerable<PayFrequencyEntity>>> GetPayFrequencies()
        {
            IEnumerable<PayFrequencyEntity> payFrequencies = await employerService.GetPayFrequencyAsync();
            return ResponseModelWrapper.CreateSuccess(String.Empty, payFrequencies);
        }

        [HttpGet]
        [Route("payfrequency/{id}")]
        public async Task<ResponseModelWrapper<string>> DeletePayFrequencies(int id)
        {
            await employerService.DeletePayFrequencyAsync(id);
            return ResponseModelWrapper.CreateSuccess(String.Empty, String.Empty);
        }

        [HttpPost]
        [Route("bankaccountinfo")]
        public async Task<ResponseModelWrapper<string>> AddUpdateBankAccountInfo([FromBody] BankAccountInfoEntity bankAccountInfoEntity)
        {
            await employerService.AddUpdateBankAccountInfoAsync(bankAccountInfoEntity);
            return ResponseModelWrapper.CreateSuccess(String.Empty, string.Empty);
        }

        [HttpGet]
        [Route("bankaccountinfo")]
        public async Task<ResponseModelWrapper<BankAccountInfoEntity>> GetBankAccountInfos()
        {
            BankAccountInfoEntity bankAccountInfo = await employerService.GetBankAccountInfoAsync();
            return ResponseModelWrapper.CreateSuccess(String.Empty, bankAccountInfo);
        }

        [HttpPost]
        [Route("employerinfo")]
        public async Task<ResponseModelWrapper<string>> AddUpdateEmployerInfo([FromBody] EmployerEntityModel employerInfoEntity)
        {
            await employerService.AddUpdateEmployerInfoAsync(employerInfoEntity);
            return ResponseModelWrapper.CreateSuccess(String.Empty, string.Empty);
        }

        [HttpGet]
        [Route("employerinfo")]
        public async Task<ResponseModelWrapper<EmployerEntityModel>> GetEmployerInfo()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await employerService.GetEmployerInfoAsync());
        }

        [HttpPost]
        [Route("paidtimeoff")]
        public async Task<ResponseModelWrapper<string>> AddUpdatePaidTimeOff([FromBody] PaidTimeOffEntity paidTimeOffEntity)
        {
            await employerService.AddUpdatePaidTimeOffAsync(paidTimeOffEntity);
            return ResponseModelWrapper.CreateSuccess(String.Empty, string.Empty);
        }

        [HttpGet]
        [Route("paidtimeoff")]
        public async Task<ResponseModelWrapper<IEnumerable<PaidTimeOffEntity>>> GetPaidTimeOff()
        {
            IEnumerable<PaidTimeOffEntity> paidTimeOffs = await employerService.GetPaidTimeOffAsync();
            return ResponseModelWrapper.CreateSuccess(String.Empty, paidTimeOffs);
        }

        [HttpGet]
        [Route("paidtimeoff/remove/{id}")]
        public async Task<ResponseModelWrapper<string>> DeletePaidTimeOff(long Id)
        {
            await employerService.DeletePaidTimeOffAsync(Id);
            return ResponseModelWrapper.CreateSuccess(String.Empty, String.Empty);
        }

        [HttpPost]
        [Route("employertaxinfo")]
        public async Task AddUpdateEmployerTaxInfo([FromBody] EmployerTaxInfoEntity employerTaxInfoEntity)
        {
            await employerService.AddUpdateEmployerTaxInfoAsync(employerTaxInfoEntity);
        }

        [HttpGet]
        [Route("employertaxinfo")]
        public async Task<ResponseModelWrapper<IEnumerable<EmployerTaxInfoEntity>>> GetEmployerTaxInfo()
        {
            return ResponseModelWrapper.CreateSuccess(String.Empty, await employerService.GetEmployerTaxInfoAsync());
        }
    }
}