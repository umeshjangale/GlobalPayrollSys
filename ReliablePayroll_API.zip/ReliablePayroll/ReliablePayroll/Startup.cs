using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Payroll.Data.MasterContext;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext;
using Payroll.Data.Seed;
using Payroll.Entities;
using Payroll.Entities.Login;
using Payroll.Entities.MailSetting;
using Payroll.Entities.SmsSetting;
using Payroll.Services.ServiceExtensions;
using Payroll.Utils.Auth;
using Payroll.Utils.ExtensionMethods;
using Payroll.Utils.Logging;
using System;
using System.IO;

namespace ReliablePayroll
{
    public class Startup
    {
        private readonly IConfigurationRoot Configuration;

        public Startup(IWebHostEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContextService(Configuration.GetConnectionString("MasterConnString"));

            services.AddIdentityCore<ApplicationTenantUsers>().AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<MasterDbContext>()
            .AddDefaultTokenProviders();

            services.AddIdentity<ApplicationUser, ApplicationRole>(opt =>
            {
                opt.User.RequireUniqueEmail = true;
                opt.SignIn.RequireConfirmedEmail = true;
            })
            .AddEntityFrameworkStores<PayrollDbContext>()
            .AddDefaultTokenProviders();

            services
                .Configure<LoggingConfiguration>(Configuration.GetSection("Logging"))
                .Configure<MailSettings>(Configuration.GetSection("SmtpSettings"))
                .Configure<SmsSettings>(Configuration.GetSection("TwilioAccountDetails"))
                .Configure<JwtOptions>(Configuration.GetSection("JwtOptions"))
                .Configure<JwtAppSettingOptions>(Configuration.GetSection("JwtIssuerOptions"))
                .Configure<IdentitySettings>(Configuration.GetSection("IdentitySettings"))
                .Configure<AngularWebServerSettings>(Configuration.GetSection("AngularWebServerSettings"))
                .Configure<ServerSettings>(Configuration.GetSection("ServerSettings"));

            services
                .AddServices()
                .AddAutoMapper()
                .AddMemoryCache()
                .AddRepository();

            services.AddCors(options => options.AddPolicy("PayrollPolicy", p => p
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
            ));

            JwtAppSettingOptions jwtOptions;
            IdentitySettings identitySettings;
            JwtAppSettingOptions jwtAppSettingOptions;
            using (var optionsServiceProvider = services.BuildServiceProvider())
            {
                jwtOptions = optionsServiceProvider.GetService<IOptions<JwtAppSettingOptions>>().Value;
                jwtAppSettingOptions = optionsServiceProvider.GetService<IOptions<JwtAppSettingOptions>>().Value;
                identitySettings = optionsServiceProvider.GetService<IOptions<IdentitySettings>>().Value;
            }

            services.Configure<IdentityOptions>(options =>
            {
                options.SignIn.RequireConfirmedEmail = identitySettings.RequireConfirmedEmail;
                options.SignIn.RequireConfirmedPhoneNumber = identitySettings.RequireConfirmedPhoneNumber;

                options.Password.RequireDigit = identitySettings.RequireDigit;
                options.Password.RequiredLength = identitySettings.RequiredLength;
                options.Password.RequireNonAlphanumeric = identitySettings.RequireNonAlphanumeric;
                options.Password.RequireUppercase = identitySettings.RequireUppercase;
                options.Password.RequireLowercase = identitySettings.RequireLowercase;
                options.Password.RequiredUniqueChars = identitySettings.RequiredUniqueChars;

                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(identitySettings.DefaultLockoutTimeSpanMinutes);
                options.Lockout.MaxFailedAccessAttempts = identitySettings.MaxFailedAccessAttempts;
                options.Lockout.AllowedForNewUsers = identitySettings.AllowedForNewUsers;

                options.User.RequireUniqueEmail = identitySettings.RequireUniqueEmail;
            });

            // Configure JwtIssuerOptions
            services.Configure<JwtIssuerOptions>(options =>
            {
                options.Issuer = jwtOptions.Issuer;
                options.Audience = jwtOptions.Audience;
                options.ValidFor = TimeSpan.FromSeconds(jwtOptions.ValidForSeconds);
            });

            var jwtSigningKey = new JwtOptions
            {
                SigningKey = Configuration.GetSection("JwtOptions").GetValue<string>("SigningKey")
            }.GetSecurityKey();

            // Token validation parameters
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(configureOptions =>
            {
                var tokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = jwtAppSettingOptions.Issuer,

                    ValidateAudience = true,
                    ValidAudience = jwtAppSettingOptions.Audience,

                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = jwtSigningKey,

                    RequireExpirationTime = false,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };

                configureOptions.ClaimsIssuer = jwtAppSettingOptions.Issuer;
                configureOptions.TokenValidationParameters = tokenValidationParameters;
                configureOptions.SaveToken = true;
            });

            services.AddHttpContextAccessor();

            services.AddControllers()
                    .AddNewtonsoftJson();

            services.AddSwagger();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory,
            IOptions<LoggingConfiguration> loggingConfiguration, ISeeder defaultInitializer)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<MasterDbContext>();
                defaultInitializer.AddMigrationAsync().GetAwaiter().GetResult();
            }

            loggingConfiguration.Value.Setup(loggerFactory);
            Configuration.LogConfiguration(loggerFactory);

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("PayrollPolicy");
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseHttp();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/V1.0/swagger.json",
                "Payroll System API V1.0");
            });

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(
                                Path.Combine(Directory.GetCurrentDirectory(), "PayrollStaticFiles")),
                RequestPath = "/StaticFiles"
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}