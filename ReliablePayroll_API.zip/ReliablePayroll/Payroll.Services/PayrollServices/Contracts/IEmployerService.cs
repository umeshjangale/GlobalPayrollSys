﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface IEmployerService
    {
        Task AddUpdatePayFrequencyAsync(PayFrequencyEntity payFrequencyEntity);

        Task<IEnumerable<PayFrequencyEntity>> GetPayFrequencyAsync();

        Task DeletePayFrequencyAsync(int Id);

        Task AddUpdateBankAccountInfoAsync(BankAccountInfoEntity bankAccountInfoEntity);

        Task<BankAccountInfoEntity> GetBankAccountInfoAsync();

        Task AddUpdateEmployerInfoAsync(EmployerEntityModel bankAccountInfoEntity);

        Task<EmployerEntityModel> GetEmployerInfoAsync();

        Task<IEnumerable<StateEntity>> GetStatesAsync();

        Task AddUpdatePaidTimeOffAsync(PaidTimeOffEntity paidTimeOffEntity);

        Task<IEnumerable<PaidTimeOffEntity>> GetPaidTimeOffAsync();

        Task DeletePaidTimeOffAsync(long id);

        Task<IEnumerable<EmployerTaxInfoEntity>> GetEmployerTaxInfoAsync();

        Task AddUpdateEmployerTaxInfoAsync(EmployerTaxInfoEntity employerTaxInfoEntity);
    }
}