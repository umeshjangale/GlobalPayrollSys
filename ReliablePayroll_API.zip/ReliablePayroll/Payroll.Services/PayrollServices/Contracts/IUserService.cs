﻿using Payroll.Data.Models.PayrollDataModels;
using Payroll.Entities;
using Payroll.Entities.Login;
using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface IUserService
    {
        Task<LoginResponse> LoginAsync(LoginEntity loginModel, string userId);

        Task<LoginResponse> LoginWithOtpAsync(OtpEntity loginModel);

        Task<IEnumerable<ApplicationUser>> GetUsersAsync();

        Task<LoggedInUserEntity> GetUserAsync();

        Task<bool> ChangeUserPasswordAsync(ResetPasswordModel resetPasswordModel);

        Task<bool> ResetUserPasswordAsync(ForgotPasswordModel forgotPassword);

        Task<bool> SignUpUserAsync(SignupEntityModel signupModel);

        Task SendOtpAsync(string userName);

        Task<bool> VerifyUserAsync(string UserName);

        Task<bool> AddEmployeeAsync(EmployeeEntityModel employee, bool isContractor);

        Task<IEnumerable<EmployeeEntityViewModel>> GetEmployeesAsync(EmployeeSearchModel employeeSearch);

        Task<EmployeeEntityModel> GetEmployeeAsync(string id);
    }
}