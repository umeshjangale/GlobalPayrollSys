﻿using Payroll.Entities.MailSetting;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface IMailService
    {
        Task SendMailAsync(Email email);
    }
}