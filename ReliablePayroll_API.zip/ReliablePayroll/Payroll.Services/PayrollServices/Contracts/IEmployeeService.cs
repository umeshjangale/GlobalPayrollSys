﻿using Payroll.Entities.PayrollEntity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface IEmployeeService
    {
        Task AddUpdateTerminationyAsync(TerminationEntity termination);

        Task<TerminationEntity> GetTerminationByUserIdAsync(string userId);

        //Task<IEnumerable<TerminationReasonEntity>> GetTerminationReasonAsync();

        Task AddUpdateUserContactAsync(UserContactEntity userContactEntity);

        Task<UserContactEntity> GetUserContactByUserIdAsync(string userId);

        Task UpdateEmploymentInfoAsync(EmploymentInfoEntity employmentInfoEntity);

        Task<EmploymentInfoEntity> GetEmploymentInfoByUserIdAsync(string userId);

        Task<WorkContactEntity> GetWorkContactByUserIdAsync(string UserId);

        Task AddUpdateWorkContactAsync(WorkContactEntity workContactEntity);
        
    }
}