﻿namespace Payroll.Services.PayrollServices.Contracts
{
    public class IEarningDeductionService
    {
    }
}