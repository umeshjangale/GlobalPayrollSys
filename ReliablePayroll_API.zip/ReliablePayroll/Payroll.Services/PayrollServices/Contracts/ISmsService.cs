﻿using Payroll.Entities.SmsSetting;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface ISmsService
    {
        Task SendSmsAsync(SmsModel sms);
    }
}