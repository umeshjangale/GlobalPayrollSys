﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll.Services.PayrollServices.Contracts
{
    public interface IPayCheckPrintService
    {
    }
}
