﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Payroll.Entities.SmsSetting;
using Payroll.Services.PayrollServices.Contracts;
using System;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace Payroll.Services.PayrollServices.Services
{
    public class SmsService : ISmsService
    {
        private readonly ILogger logger;
        private readonly SmsSettings smsSettings;

        public SmsService(ILogger<SmsService> logger, IOptions<SmsSettings> smsSettings)
        {
            this.logger = logger;
            this.smsSettings = smsSettings.Value;
        }

        public async Task SendSmsAsync(SmsModel sms)
        {
            await ExecuteAsyc(smsSettings, sms);
        }

        private async Task ExecuteAsyc(SmsSettings smsSettings, SmsModel sms)
        {
            try
            {
                TwilioClient.Init(smsSettings.AccountSid, smsSettings.AuthToken);
                var message = await MessageResource.CreateAsync(
                body: sms.MessageBody,
                from: new Twilio.Types.PhoneNumber(smsSettings.FromPhoneNumber),
                to: new Twilio.Types.PhoneNumber(sms.ToPhoneNumber)
                );
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
            }
        }
    }
}