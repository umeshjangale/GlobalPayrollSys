﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.UnitOfWork;
using Payroll.Entities.Constants;
using Payroll.Entities.MailSetting;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Services
{
    public class EmployerService : IEmployerService
    {
        private readonly IPayrollUnitOfWork payrollUnitOfWork;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IMailService mailService;
        private readonly ILogger<EmployerService> logger;

        public EmployerService(IPayrollUnitOfWork payrollUnitOfWork,
              IMapper mapper, IHttpContextAccessor httpContextAccessor,
              IMailService mailService, ILogger<EmployerService> logger)
        {
            this.payrollUnitOfWork = payrollUnitOfWork;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
            this.mailService = mailService;
            this.logger = logger;
        }

        public async Task AddUpdatePayFrequencyAsync(PayFrequencyEntity payFrequencyEntity)
        {
            if (payFrequencyEntity.PayFrequencyId == 0)
            {
                PayFrequency payFrequency = mapper.Map<PayFrequencyEntity, PayFrequency>(payFrequencyEntity);

                payFrequency.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                payFrequency.CreatedDateTime = DateTime.UtcNow;
                payFrequency.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                payFrequency.UpdatedDateTime = DateTime.UtcNow;
                payFrequency.IsActive = true;

                await payrollUnitOfWork.PayFrequencyRepository.AddAsync(payFrequency);
            }
            else
            {
                PayFrequency payFrequency = await payrollUnitOfWork.PayFrequencyRepository.GetPayFrequencyByIdAsync(payFrequencyEntity.PayFrequencyId);

                if (payFrequency == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "PayFrequencyNotFound");

                payFrequency.CheckDate = payFrequencyEntity.CheckDate;
                payFrequency.EndDate = payFrequencyEntity.EndDate;
                payFrequency.PayFrequencyType = payFrequencyEntity.PayFrequencyType;
                payFrequency.StartDate = payFrequencyEntity.StartDate;
                payFrequency.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                payFrequency.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.PayFrequencyRepository.Update(payFrequency);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<IEnumerable<PayFrequencyEntity>> GetPayFrequencyAsync()
        {
            IEnumerable<PayFrequency> payFrequencies = await payrollUnitOfWork.PayFrequencyRepository.GetPayFrequencyInfoAsync();
            return mapper.Map<IEnumerable<PayFrequency>, IEnumerable<PayFrequencyEntity>>(payFrequencies);
        }

        public async Task DeletePayFrequencyAsync(int id)
        {
            PayFrequency payFrequency = await payrollUnitOfWork.PayFrequencyRepository.GetPayFrequencyByIdAsync(id);

            if (payFrequency == null)
            {
                throw new ServiceException(HttpStatusCode.NotFound, "PayFrequencyNotFound");
            }

            payFrequency.IsActive = false;
            payFrequency.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            payFrequency.UpdatedDateTime = DateTime.UtcNow;

            await payrollUnitOfWork.PayFrequencyRepository.Update(payFrequency);
            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task AddUpdateBankAccountInfoAsync(BankAccountInfoEntity bankAccountInfoEntity)
        {
            if (bankAccountInfoEntity.BankAccountInfoId == 0)
            {
                BankAccountInfo bankAccountInfo = mapper.Map<BankAccountInfoEntity, BankAccountInfo>(bankAccountInfoEntity);

                bankAccountInfo.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                bankAccountInfo.UpdatedDateTime = DateTime.UtcNow;
                bankAccountInfo.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                bankAccountInfo.CreatedDateTime = DateTime.UtcNow;
                bankAccountInfo.IsActive = true;
                await payrollUnitOfWork.BankAccountRepository.AddAsync(bankAccountInfo);
            }
            else
            {
                BankAccountInfo bankAccountDetail = await payrollUnitOfWork.BankAccountRepository.GetByIdAsync(bankAccountInfoEntity.BankAccountInfoId);
                if (bankAccountDetail == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "BankAccountNotFound");

                bankAccountDetail.ActivateEmpDirectDeposit = bankAccountInfoEntity.ActivateEmpDirectDeposit;
                bankAccountDetail.Name = bankAccountInfoEntity.Name;
                bankAccountDetail.RoutingNumber = bankAccountInfoEntity.RoutingNumber;
                bankAccountDetail.AccountNumber = bankAccountInfoEntity.AccountNumber;
                bankAccountDetail.IncludeEmpAddressOnCheck = bankAccountInfoEntity.IncludeEmpAddressOnCheck;
                bankAccountDetail.NameAndAddressOrTransitNumber = bankAccountInfoEntity.NameAndAddressOrTransitNumber;
                bankAccountDetail.ShouldPrintOnCheck = bankAccountInfoEntity.ShouldPrintOnCheck;
                bankAccountDetail.PrintBusinessPhoneOnPayStube = bankAccountInfoEntity.PrintBusinessPhoneOnPayStube;
                bankAccountDetail.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                bankAccountDetail.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.BankAccountRepository.Update(bankAccountDetail);
            }

            await payrollUnitOfWork.SaveChangesAsync();

            if (bankAccountInfoEntity.BankAccountInfoId > 0)
            {
                ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(httpContextAccessor.HttpContext.User.GetLoggedInUserId());

                if (user == null)
                    throw new ServiceException(HttpStatusCode.Unauthorized, "UserNotFound");

                Email email = new Email
                {
                    ToAddress = httpContextAccessor.HttpContext.User.GetLoggedInUserName(),
                    Subject = "Payroll - Bank Details Update",
                    HtmlBody = String.Format(@"{0} Dear {1}, <br><br> Your bank account information has been updated successfully.<br><br>" +
                    "If you have any questions or need any support at all,please email us at" +
                    " TestEmail@payroll.com <br><br><br> Thank you <br> Team Payroll", EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName)),
                };
                await mailService.SendMailAsync(email);
            }
        }

        public async Task<BankAccountInfoEntity> GetBankAccountInfoAsync()
        {
            BankAccountInfo bankAccountInfo = await payrollUnitOfWork.BankAccountRepository.GetBankAccountInfoAsync();
            return mapper.Map<BankAccountInfo, BankAccountInfoEntity>(bankAccountInfo);
        }

        public async Task AddUpdateEmployerInfoAsync(EmployerEntityModel employerInfoEntity)
        {
            if (employerInfoEntity.EmployerInfo.EmployerInfoId == 0)
            {
                EmployerInfo employerInfo = mapper.Map<EmployerInfoEntity, EmployerInfo>(employerInfoEntity.EmployerInfo);
                employerInfo.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                employerInfo.CreatedDateTime = DateTime.UtcNow;
                employerInfo.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                employerInfo.UpdatedDateTime = DateTime.UtcNow;
                employerInfo.IsActive = true;

                await payrollUnitOfWork.EmployerRepository.AddAsync(employerInfo);

                EmployerContactInfo employerContactInfo = mapper.Map<EmployerContactInfoEntity, EmployerContactInfo>(employerInfoEntity.EmployerContactInfo);
                employerContactInfo.IsActive = true;
                await payrollUnitOfWork.EmployerRepository.AddEmployerContactAsync(employerContactInfo);
            }
            else
            {
                EmployerInfo employerInfo = await payrollUnitOfWork.EmployerRepository.GetByIdAsync(employerInfoEntity.EmployerInfo.EmployerInfoId);
                if (employerInfo == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "EmployerInfoNotFound");

                EmployerContactInfo employerContactInfo = await payrollUnitOfWork.EmployerRepository.GetEmployerContactByIdAsync(employerInfoEntity.EmployerContactInfo.ContactInformationId);
                if (employerContactInfo == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "EmployerContactInfoNotFound");

                employerInfo = SetEmployerInfoData(employerInfo, employerInfoEntity);
                await payrollUnitOfWork.EmployerRepository.Update(employerInfo);

                employerContactInfo = SetEmployerContactData(employerContactInfo, employerInfoEntity);
                await payrollUnitOfWork.EmployerRepository.UpdateEmployerContactAsync(employerContactInfo);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<EmployerEntityModel> GetEmployerInfoAsync()
        {
            EmployerInfo employerInfo = await payrollUnitOfWork.EmployerRepository.GetEmployerInfoAsync();
            EmployerContactInfo employerContactInfo = await payrollUnitOfWork.EmployerRepository.GetEmployerContactAsync();

            return new EmployerEntityModel()
            {
                EmployerContactInfo = mapper.Map<EmployerContactInfo, EmployerContactInfoEntity>(employerContactInfo),
                EmployerInfo = mapper.Map<EmployerInfo, EmployerInfoEntity>(employerInfo)
            };
        }

        public async Task<IEnumerable<StateEntity>> GetStatesAsync()
        {
            var states = await payrollUnitOfWork.EmployerRepository.GetStateAsync();
            if (states == null)
            {
                logger.LogInformation("StatesDoesNotExist");
            }

            var state = mapper.Map<IEnumerable<State>, IEnumerable<StateEntity>>(states);
            return state.OrderBy(it => it.Name).ToList() ?? Enumerable.Empty<StateEntity>();
        }

        private EmployerInfo SetEmployerInfoData(EmployerInfo employerInfo, EmployerEntityModel employerInfoEntity)
        {
            employerInfo.LegalName = employerInfoEntity.EmployerInfo.LegalName;
            employerInfo.LegalAddress1 = employerInfoEntity.EmployerInfo.LegalAddress1;
            employerInfo.LegalAddress2 = employerInfoEntity.EmployerInfo.LegalAddress2;
            employerInfo.City = employerInfoEntity.EmployerInfo.City;
            employerInfo.State = employerInfoEntity.EmployerInfo.State;
            employerInfo.ZipCode = employerInfoEntity.EmployerInfo.ZipCode;
            employerInfo.Country = employerInfoEntity.EmployerInfo.Country;
            employerInfo.BusinessPhone = employerInfoEntity.EmployerInfo.BusinessPhone;
            employerInfo.BusinessFax = employerInfoEntity.EmployerInfo.BusinessFax;
            employerInfo.SameAsLegalInfo = employerInfoEntity.EmployerInfo.SameAsLegalInfo;
            employerInfo.BusinessName = employerInfoEntity.EmployerInfo.BusinessName;
            employerInfo.BusinessAddress1 = employerInfoEntity.EmployerInfo.BusinessAddress1;
            employerInfo.BusinessAddress2 = employerInfoEntity.EmployerInfo.BusinessAddress2;
            employerInfo.BusinessCity = employerInfoEntity.EmployerInfo.BusinessCity;
            employerInfo.BusinessState = employerInfoEntity.EmployerInfo.BusinessState;
            employerInfo.BusinessZipCode = employerInfoEntity.EmployerInfo.BusinessZipCode;
            employerInfo.BusinessCountry = employerInfoEntity.EmployerInfo.BusinessCountry;
            employerInfo.NAICSCode = employerInfoEntity.EmployerInfo.NAICSCode;
            employerInfo.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            employerInfo.UpdatedDateTime = DateTime.UtcNow;

            return employerInfo;
        }

        private EmployerContactInfo SetEmployerContactData(EmployerContactInfo employerContactInfo, EmployerEntityModel employerInfoEntity)
        {
            employerContactInfo.PayrollFirstName = employerInfoEntity.EmployerContactInfo.PayrollFirstName;
            employerContactInfo.PayrollLastName = employerInfoEntity.EmployerContactInfo.PayrollLastName;
            employerContactInfo.PayrollTitle = employerInfoEntity.EmployerContactInfo.PayrollTitle;
            employerContactInfo.PayrollPhone = employerInfoEntity.EmployerContactInfo.PayrollPhone;
            employerContactInfo.PayrollExtension = employerInfoEntity.EmployerContactInfo.PayrollExtension;
            employerContactInfo.PayrollEmail = employerInfoEntity.EmployerContactInfo.PayrollEmail;
            employerContactInfo.BillingFirstName = employerInfoEntity.EmployerContactInfo.BillingFirstName;
            employerContactInfo.BillingLastName = employerInfoEntity.EmployerContactInfo.BillingLastName;
            employerContactInfo.BillingTitle = employerInfoEntity.EmployerContactInfo.BillingTitle;
            employerContactInfo.BillingPhone = employerInfoEntity.EmployerContactInfo.BillingPhone;
            employerContactInfo.BillingExtension = employerInfoEntity.EmployerContactInfo.BillingExtension;
            employerContactInfo.BillingEmail = employerInfoEntity.EmployerContactInfo.BillingEmail;

            return employerContactInfo;
        }

        public async Task AddUpdatePaidTimeOffAsync(PaidTimeOffEntity paidTimeOffEntity)
        {
            if (paidTimeOffEntity.PaidTimeOffId == 0)
            {
                PaidTimeOff paidTimeOff = mapper.Map<PaidTimeOffEntity, PaidTimeOff>(paidTimeOffEntity);

                paidTimeOff.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                paidTimeOff.CreatedDateTime = DateTime.UtcNow;
                paidTimeOff.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                paidTimeOff.UpdatedDateTime = DateTime.UtcNow;
                paidTimeOff.IsActive = true;

                await payrollUnitOfWork.EmployerRepository.AddPaidTimeOffAsync(paidTimeOff);
            }
            else
            {
                PaidTimeOff paidTimeOff = await payrollUnitOfWork.EmployerRepository.GetPaidTimeOffByIdAsync(paidTimeOffEntity.PaidTimeOffId);

                if (paidTimeOff == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "PaidTimeOffNotFound");

                paidTimeOff.TimeOffCategoryId = paidTimeOffEntity.TimeOffCategoryId;
                paidTimeOff.Description = paidTimeOffEntity.Description;
                paidTimeOff.AccrualFrequencyId = paidTimeOffEntity.AccrualFrequencyId;
                paidTimeOff.HoursEarnedPerYear = paidTimeOffEntity.HoursEarnedPerYear;
                paidTimeOff.MaximumAvailable = paidTimeOffEntity.MaximumAvailable;
                paidTimeOff.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                paidTimeOff.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployerRepository.UpdatePaidTimeOffAsync(paidTimeOff);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<IEnumerable<PaidTimeOffEntity>> GetPaidTimeOffAsync()
        {
            return await payrollUnitOfWork.EmployerRepository.GetPaidTimeOffAsync();
        }

        public async Task DeletePaidTimeOffAsync(long id)
        {
            PaidTimeOff paidTimeOff = await payrollUnitOfWork.EmployerRepository.GetPaidTimeOffByIdAsync(id);

            if (paidTimeOff == null)
                throw new ServiceException(HttpStatusCode.NotFound, "PaidTimeOffNotFound");

            paidTimeOff.IsActive = false;
            paidTimeOff.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            paidTimeOff.UpdatedDateTime = DateTime.UtcNow;

            await payrollUnitOfWork.EmployerRepository.UpdatePaidTimeOffAsync(paidTimeOff);
            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<IEnumerable<EmployerTaxInfoEntity>> GetEmployerTaxInfoAsync()
        {
            var taxInfo = await payrollUnitOfWork.EmployerRepository.GetEmployerTaxInfoAsync();
            return mapper.Map<IEnumerable<EmployerTaxInfo>, IEnumerable<EmployerTaxInfoEntity>>(taxInfo);
        }

        public async Task AddUpdateEmployerTaxInfoAsync(EmployerTaxInfoEntity employerTaxInfoEntity)
        {
            var employerTaxInfo = mapper.Map<EmployerTaxInfoEntity, EmployerTaxInfo>(employerTaxInfoEntity);

            employerTaxInfo.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            employerTaxInfo.UpdatedDateTime = DateTime.UtcNow;

            if (employerTaxInfo.TaxInfoId == 0)
            {
                employerTaxInfo.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                employerTaxInfo.CreatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployerRepository.AddEmployerTaxInfoAsync(employerTaxInfo);
            }
            else
            {
                await payrollUnitOfWork.EmployerRepository.UpdateEmployerTaxInfoAsync(employerTaxInfo);
            }
            await payrollUnitOfWork.SaveChangesAsync();
        }
    }
}