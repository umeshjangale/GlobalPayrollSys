﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext;
using Payroll.Data.PayrollContext.UnitOfWork;
using Payroll.Entities;
using Payroll.Entities.Constants;
using Payroll.Entities.Login;
using Payroll.Entities.MailSetting;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Auth;
using Payroll.Utils.Cache;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using Payroll.Utils.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Services
{
    public class UserService : IUserService
    {
        private readonly IJwtFactory jwtFactory;
        private readonly IPayrollUnitOfWork payrollUnitOfWork;
        private readonly IMapper mapper;
        private readonly ILogger<UserService> logger;
        private readonly IMailService mailService;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ILoginResponseCache loginResponseCache;
        private readonly AngularWebServerSettings webServerSettings;
        private readonly ITenantSeed tenantSeed;

        public UserService(IPayrollUnitOfWork payrollUnitOfWork, IJwtFactory jwtFactory,
            IMapper mapper, ILogger<UserService> logger,
            IMailService mailService, IHttpContextAccessor httpContextAccessor,
            ILoginResponseCache loginResponseCache, IOptions<AngularWebServerSettings> options,
            ITenantSeed tenantSeed)
        {
            this.payrollUnitOfWork = payrollUnitOfWork;
            this.jwtFactory = jwtFactory;
            this.mapper = mapper;
            this.logger = logger;
            this.mailService = mailService;
            this.httpContextAccessor = httpContextAccessor;
            this.loginResponseCache = loginResponseCache;
            this.webServerSettings = options.Value;
            this.tenantSeed = tenantSeed;
        }

        public async Task<LoginResponse> LoginAsync(LoginEntity loginModel, string userId)
        {
            await RunMigrationAsync();

            ApplicationUser user = await payrollUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(loginModel.UserName);

            if (user.EmployeeStatus == EmployeeStatus.Terminate)
            {
                throw new ServiceException(HttpStatusCode.Unauthorized, "EmployeeTerminate");
            }

            if (!user.IsAccessGiven)
            {
                throw new ServiceException(HttpStatusCode.Unauthorized, "AccessNotGiven");
            }

            if (!await payrollUnitOfWork.IdentityUsersRepository.CheckUserPasswordAsync(user, loginModel.Password))
                throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidCredentials");

            if (String.IsNullOrWhiteSpace(userId))
            {
                await SendOtpAsync(user);
                return new LoginResponse
                {
                    AuthToken = null,
                    RefreshToken = jwtFactory.GenerateRefreshTokenAsync()
                };
            }

            return await CreateToken(user, loginModel.CompanyCode);
        }

        private async Task<LoginResponse> CreateToken(ApplicationUser user, string companyCode)
        {
            IEnumerable<string> roles = await payrollUnitOfWork.IdentityUsersRepository.GetUserRolesAsync(user);
            IEnumerable<string> features = await payrollUnitOfWork.UserRepository.GetUserFeaturesByRoleAsync(await GetUserRoleId(roles.FirstOrDefault()));
            var claimsIdentity = await jwtFactory.GenerateClaimsIdentity(user.UserName, user.Id, roles, companyCode, features);

            LoginResponse loginResponse = new LoginResponse
            {
                AuthToken = jwtFactory.GenerateEncodedTokenAsync(claimsIdentity),
                RefreshToken = jwtFactory.GenerateRefreshTokenAsync()
            };

            loginResponseCache.Add(user.Id, loginResponse);
            return loginResponse;
        }

        public async Task<LoginResponse> LoginWithOtpAsync(OtpEntity loginModel)
        {
            ApplicationUser user = await payrollUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(loginModel.UserName);

            TenantOtpInfo otpInfo = await payrollUnitOfWork.UserRepository.GetOtpAsync(user.Id);

            if (DateTime.UtcNow.Subtract(otpInfo.SentDateTine).TotalMinutes > 10)
                throw new ServiceException(HttpStatusCode.BadRequest, "OtpExpired");

            if (loginModel.Otp != otpInfo.OtpCode)
                throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidOtp");

            return await CreateToken(user, loginModel.CompanyCode);
        }

        public async Task<bool> SignUpUserAsync(SignupEntityModel signup)
        {
            ApplicationUser user = mapper.Map<SignupEntityModel, ApplicationUser>(signup);
            var res = await payrollUnitOfWork.IdentityUsersRepository.CreateUserAsync(user, signup.Password);

            if (!res.Succeeded)
            {
                throw new ServiceException(HttpStatusCode.BadRequest, "UserNotCreated");
            }
            return res.Succeeded;
        }

        public async Task<IEnumerable<ApplicationUser>> GetUsersAsync()
        {
            return await payrollUnitOfWork.UserRepository.GetAllAsync();
        }

        public async Task<LoggedInUserEntity> GetUserAsync()
        {
            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(httpContextAccessor.HttpContext.User.GetLoggedInUserId());
            return mapper.Map<ApplicationUser, LoggedInUserEntity>(user);
        }

        public async Task<bool> ChangeUserPasswordAsync(ResetPasswordModel resetPassword)
        {
            var userName = httpContextAccessor.HttpContext.User.Identity.Name;
            var result = await payrollUnitOfWork.IdentityUsersRepository.ChangeUserPasswordAsync(userName, resetPassword.CurrentPassword, resetPassword.NewPassword);
            if (!result.Succeeded)
            {
                throw new ServiceException(HttpStatusCode.NotModified, "PasswordMissmatch");
            }
            return result.Succeeded;
        }

        public async Task<bool> ResetUserPasswordAsync(ForgotPasswordModel forgotPassword)
        {
            await RunMigrationAsync();

            var user = await payrollUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(forgotPassword.UserName);
            if (user == null)
                throw new ServiceException(HttpStatusCode.NotFound, "UserNotFound");

            var otpInfo = await payrollUnitOfWork.UserRepository.GetOtpAsync(user.Id);

            if (otpInfo.OtpCode != forgotPassword.Otp)
                throw new ServiceException(HttpStatusCode.InternalServerError, "InvalidOtp");

            if (DateTime.UtcNow.Subtract(otpInfo.SentDateTine).TotalMinutes > 10)
                throw new ServiceException(HttpStatusCode.InternalServerError, "OtpExpired");

            bool result = await payrollUnitOfWork.IdentityUsersRepository.ResetUserPasswordAsync(user, forgotPassword.NewPassword);
            if (!result)
                throw new ServiceException(HttpStatusCode.Unauthorized, "PasswordNotReset");

            await payrollUnitOfWork.SaveChangesAsync();

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll - Reset Password",
                HtmlBody = String.Format("{0} Dear {1},<br><br> Your password has been changed succesfully.<br><br>" +
                "Login with new password..please click below link to login <br> <a href='{2}' {3}'>Login</a>" +
                "<br><br><br> Thank you <br> Team Payroll", EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName), webServerSettings.WebUrl, EmailConstants.ButtonStyle)
            };
            await mailService.SendMailAsync(email);
            return true;
        }

        private async Task SendOtpAsync(ApplicationUser user)
        {
            string userOtp = GenerateNewOtp.GetRandomOtpNumber(10000, 99999);
            await payrollUnitOfWork.UserRepository.InActiveUserOtpAsync(user.Id);
            TenantOtpInfo tentOtpInfo = new TenantOtpInfo
            {
                OtpCode = userOtp,
                SentDateTine = DateTime.UtcNow,
                IsActive = true,
                UserId = user.Id
            };
            await payrollUnitOfWork.UserRepository.AddOtpAsync(tentOtpInfo);
            await payrollUnitOfWork.SaveChangesAsync();

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll System - One Time Password",
                HtmlBody = String.Format("{0} Dear {1},<br><br> Please enter OTP to reset your password: <b>{2}</b> <br><br><br> Thank you <br> Team Payroll", EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName), userOtp)
            };
            await mailService.SendMailAsync(email);
        }

        public async Task SendOtpAsync(string userName)
        {
            ApplicationUser user = await payrollUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(userName);
            await SendOtpAsync(user);
        }

        private async Task<Guid> GetUserRoleId(string roleName)
        {
            ApplicationRole role = await payrollUnitOfWork.IdentityUsersRepository.FindTenantRoleByNameAsync(roleName);
            return Guid.Parse(role.Id);
        }

        /// <summary>
        /// Asynchronously applies any pending migrations for the context to the database.
        /// Before Login or reset password run this migration.
        /// </summary>
        /// <returns></returns>
        private async Task RunMigrationAsync()
        {
            await tenantSeed.MigrationAsync();
        }

        public async Task<bool> VerifyUserAsync(string UserName)
        {
            var userByName = await payrollUnitOfWork.IdentityUsersRepository.IsUserExistAsync(UserName);
            return userByName != null;
        }

        public async Task<bool> AddEmployeeAsync(EmployeeEntityModel employee, bool isContractor)
        {
            await payrollUnitOfWork.UserRepository.IsEmailExistAsync(employee.EmailAddress);

            ApplicationUser user = mapper.Map<EmployeeEntityModel, ApplicationUser>(employee);

            user.IsAccessGiven = !isContractor;
            user.IsContractor = isContractor;
            user.IsActive = true;

            user.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.UpdatedDateTime = DateTime.UtcNow;
            user.EmployeeStatus = EmployeeStatus.NewHire;

            user.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.CreatedDateTime = DateTime.UtcNow;

            IdentityResult identityResult = await payrollUnitOfWork.IdentityUsersRepository.CreateUserAsync(user);

            if (!identityResult.Succeeded)
            {
                throw new ServiceException(HttpStatusCode.BadRequest, $"UserNotCreated. Error: {String.Join(", ", identityResult)}");
            }

            user = await payrollUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(user.UserName);
            await payrollUnitOfWork.IdentityUsersRepository.AddUserToRoleAsync(user, Roles.Employee);
            return identityResult.Succeeded;
        }

        public async Task<IEnumerable<EmployeeEntityViewModel>> GetEmployeesAsync(EmployeeSearchModel employeeSearch)
        {
            return await payrollUnitOfWork.UserRepository.GetEmployeesAsync(employeeSearch);
        }

        public async Task<EmployeeEntityModel> GetEmployeeAsync(string id)
        {
            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(id);
            return mapper.Map<ApplicationUser, EmployeeEntityModel>(user);
        }
    }
}