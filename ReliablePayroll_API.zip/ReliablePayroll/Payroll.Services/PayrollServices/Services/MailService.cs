﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Payroll.Entities.MailSetting;
using Payroll.Services.PayrollServices.Contracts;
using System;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Services
{
    public class MailService : IMailService
    {
        private readonly ILogger logger;
        private readonly MailSettings smtpSettings;

        public MailService(ILogger<MailService> logger, IOptions<MailSettings> smtpSettings)
        {
            this.smtpSettings = smtpSettings.Value;
            this.logger = logger;
        }

        public async Task SendMailAsync(Email email)
        {
            await ExecuteAsyc(smtpSettings, email);
        }

        private async Task ExecuteAsyc(MailSettings mailSetting, Email email)
        {
            try
            {
                logger.LogInformation("Using mailserver {SmtpHost}:{SmtpPort}.", mailSetting.SmtpHost, mailSetting.PortNumber);
                using (SmtpClient smtpClient = new SmtpClient(mailSetting.SmtpHost, mailSetting.PortNumber)
                {
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(mailSetting.UserName, mailSetting.Password)
                }
                   )
                {
                    MailMessage message = new MailMessage
                    {
                        From = new MailAddress(mailSetting.FromAddress, mailSetting.FromName),
                        Subject = email.Subject,
                        IsBodyHtml = true
                    };

                    message.AlternateViews.Add(GetAlternateViews(email.HtmlBody));

                    var Tos = email.ToAddress.Split(";");
                    foreach (string to in Tos)
                    {
                        message.To.Add(to);
                    }

                    smtpClient.EnableSsl = true;

                    //Add this line to bypass the certificate validation
                    ServicePointManager.ServerCertificateValidationCallback = delegate (object s,
                            System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                            System.Security.Cryptography.X509Certificates.X509Chain chain,
                            System.Net.Security.SslPolicyErrors sslPolicyErrors)
                    {
                        return true;
                    };

                    await smtpClient.SendMailAsync(message);
                    logger.LogDebug("Mail sent successfully");
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
            }
        }

        private AlternateView GetAlternateViews(string body)
        {
            string path = Environment.CurrentDirectory + "//PayrollStaticFiles//EmailImages//logo.png";
            LinkedResource Img = new LinkedResource(path)
            {
                TransferEncoding = TransferEncoding.Base64,
                ContentType = new ContentType("image/png"),
                ContentId = "companyEmailLogo"
            };

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(
              body, null, MediaTypeNames.Text.Html);

            htmlView.LinkedResources.Add(Img);
            return htmlView;
        }
    }
}