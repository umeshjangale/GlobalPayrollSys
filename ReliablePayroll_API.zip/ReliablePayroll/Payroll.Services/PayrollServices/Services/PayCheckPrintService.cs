﻿using Payroll.Services.PayrollServices.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Payroll.Services.PayrollServices.Services
{
    public class PayCheckPrintService : IPayCheckPrintService
    {
        public PayCheckPrintService()
        {

        }
    }
}
