﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext.UnitOfWork;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Payroll.Services.PayrollServices.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IPayrollUnitOfWork payrollUnitOfWork;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;

        public EmployeeService(IPayrollUnitOfWork payrollUnitOfWork,
              IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            this.payrollUnitOfWork = payrollUnitOfWork;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task AddUpdateTerminationyAsync(TerminationEntity terminationEntity)
        {
            if (terminationEntity.TerminationDate == DateTime.MinValue)
            {
                return;
            }

            if (terminationEntity.TerminationId == 0)
            {
                Termination termination = mapper.Map<TerminationEntity, Termination>(terminationEntity);
                termination.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                termination.UpdatedDateTime = DateTime.UtcNow;
                termination.UserId = terminationEntity.UserId;
                termination.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                termination.CreatedDateTime = DateTime.UtcNow;
                await payrollUnitOfWork.EmployeeRepository.AddAsync(termination);
            }
            else
            {
                Termination termination = await payrollUnitOfWork.EmployeeRepository.GetByIdAsync(terminationEntity.TerminationId);

                if (termination == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "EmployeeTerminationRecordNotFound");

                if (termination.UserId != terminationEntity.UserId)
                    throw new ServiceException(HttpStatusCode.NotFound, "UserNotValidForUpdate");

                termination.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                termination.UpdatedDateTime = DateTime.UtcNow;
                termination.TerminationDate = terminationEntity.TerminationDate.Value.Date;
                termination.LastDateOfWork = terminationEntity.LastDateOfWork.Value.Date;
                termination.TerminationReason = terminationEntity.TerminationReason;
                await payrollUnitOfWork.EmployeeRepository.Update(termination);
            }

            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(terminationEntity.UserId);

            if (user == null)
                throw new ServiceException(HttpStatusCode.Unauthorized, "UserNotFound");

            user.EmployeeStatus = EmployeeStatus.Terminate;
            user.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.UpdatedDateTime = DateTime.Now;
            await payrollUnitOfWork.UserRepository.Update(user);

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<TerminationEntity> GetTerminationByUserIdAsync(string userId)
        {
            Termination termination = await payrollUnitOfWork.EmployeeRepository.GetTerminationByUserIdAsync(userId);
            return mapper.Map<Termination, TerminationEntity>(termination);
        }

        public async Task<WorkContactEntity> GetWorkContactByUserIdAsync(string userId)
        {
            WorkContact workContact = await payrollUnitOfWork.EmployeeRepository.GetWorkContactByUserIdAsync(userId);
            return mapper.Map<WorkContact, WorkContactEntity>(workContact);
        }

        public async Task AddUpdateWorkContactAsync(WorkContactEntity workContactEntity)
        {
            if (workContactEntity.WorkContactId == 0)
            {
                WorkContact workContact = mapper.Map<WorkContactEntity, WorkContact>(workContactEntity);
                workContact.UserId = workContactEntity.UserId;
                workContact.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                workContact.CreatedDateTime = DateTime.UtcNow;
                workContact.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                workContact.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployeeRepository.AddWorkContactAsync(workContact);
            }
            else
            {
                WorkContact workContact = await payrollUnitOfWork.EmployeeRepository.GetWorkContactByIdAsync(workContactEntity.WorkContactId);

                if (workContact == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "WorkContactNotFound");

                if (workContact.UserId != workContactEntity.UserId)
                    throw new ServiceException(HttpStatusCode.NotFound, "UserNotValidForUpdate");

                workContact.AddressLine1 = workContactEntity.AddressLine1;
                workContact.AddressLine2 = workContactEntity.AddressLine2;
                workContact.City = workContactEntity.City;
                workContact.StateId = workContactEntity.StateId;
                workContact.WorkEmail = workContactEntity.WorkEmail;
                workContact.WorkPhoneNumber = workContactEntity.WorkPhoneNumber;
                workContact.ZipCode = workContactEntity.ZipCode;
                workContact.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                workContact.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployeeRepository.UpdateWorkContactAsync(workContact);
            }

            var user = await payrollUnitOfWork.UserRepository.GetByIdAsync(workContactEntity.UserId);
            if (user.EmployeeStatus == EmployeeStatus.NewHire)
            {
                await UpdateEmployeeStatusAsync(user.Id);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task AddUpdateUserContactAsync(UserContactEntity userContactEntity)
        {
            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(userContactEntity.UserId);

            if (user == null)
                throw new ServiceException(HttpStatusCode.Unauthorized, "UserNotFound");

            user.FirstName = userContactEntity.FirstName;
            user.LastName = userContactEntity.LastName;
            user.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.UpdatedDateTime = DateTime.Now;

            await payrollUnitOfWork.UserRepository.Update(user);

            if (userContactEntity.UserContactId == 0)
            {
                UserContact userContact = mapper.Map<UserContactEntity, UserContact>(userContactEntity);

                userContact.UserId = userContactEntity.UserId;
                userContact.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                userContact.CreatedDateTime = DateTime.UtcNow;
                userContact.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                userContact.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployeeRepository.AddUserContactAsync(userContact);
            }
            else
            {
                UserContact userContact = await payrollUnitOfWork.EmployeeRepository.GetUserContactByIdAsync(userContactEntity.UserContactId);

                if (userContact == null)
                    throw new ServiceException(HttpStatusCode.NotFound, "UserContactNotFound");

                if (userContact.UserId != userContactEntity.UserId)
                    throw new ServiceException(HttpStatusCode.NotFound, "UserNotValidForUpdate");

                userContact.MiddleInitial = userContactEntity.MiddleInitial;
                userContact.PreferredName = userContactEntity.PreferredName;
                userContact.AlternateName = userContactEntity.AlternateName;
                userContact.AddressLine1 = userContactEntity.AddressLine1;
                userContact.AddressLine2 = userContactEntity.AddressLine2;
                userContact.City = userContactEntity.City;
                userContact.StateId = userContactEntity.StateId;
                userContact.ZipCode = userContactEntity.ZipCode;
                userContact.HomePhoneNumber = userContactEntity.HomePhoneNumber;
                userContact.WorkPhoneNumber = userContactEntity.WorkPhoneNumber;
                userContact.WorkExtension = userContactEntity.WorkExtension;
                userContact.AlternatePhoneNumber = userContactEntity.AlternatePhoneNumber;
                userContact.AlternateExtension = userContactEntity.AlternateExtension;
                userContact.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
                userContact.UpdatedDateTime = DateTime.UtcNow;

                await payrollUnitOfWork.EmployeeRepository.UpdateUserContactAsync(userContact);
            }

            if (user.EmployeeStatus == EmployeeStatus.NewHire)
            {
                await UpdateEmployeeStatusAsync(user.Id);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<UserContactEntity> GetUserContactByUserIdAsync(string userId)
        {
            UserContactEntity userContactEntity = await payrollUnitOfWork.EmployeeRepository.GetUserContactByUserIdAsync(userId);

            if (userContactEntity == null)
            {
                ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(userId);
                return new UserContactEntity
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName
                };
            }

            return userContactEntity;
        }

        public async Task UpdateEmploymentInfoAsync(EmploymentInfoEntity employmentInfoEntity)
        {
            if (employmentInfoEntity.TerminationDate != DateTime.MinValue && employmentInfoEntity.HireDate > employmentInfoEntity.TerminationDate)
            {
                throw new ServiceException(HttpStatusCode.ExpectationFailed, "TerminationDateGreaterThanHireDate");
            }

            TerminationEntity terminationEntity = mapper.Map<EmploymentInfoEntity, TerminationEntity>(employmentInfoEntity);

            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(employmentInfoEntity.UserId);

            if (user == null)
                throw new ServiceException(HttpStatusCode.NotFound, "UserNotFound");

            user.HireDate = employmentInfoEntity.HireDate;
            user.SocialSecurityNumber = employmentInfoEntity.SocialSecurityNumber;
            user.CompanyPaidPension = employmentInfoEntity.CompanyPaidPension;
            user.JobTaxCredit = employmentInfoEntity.JobTaxCredit;
            user.StatutoryEmployee = employmentInfoEntity.StatutoryEmployee;
            user.DateOfBirth = employmentInfoEntity.BirthDate;
            user.GenderId = employmentInfoEntity.GenderId;
            user.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.UpdatedDateTime = DateTime.UtcNow;

            await payrollUnitOfWork.UserRepository.Update(user);
            await AddUpdateTerminationyAsync(terminationEntity);

            if (user.EmployeeStatus == EmployeeStatus.NewHire)
            {
                await UpdateEmployeeStatusAsync(user.Id);
            }

            await payrollUnitOfWork.SaveChangesAsync();
        }

        public async Task<EmploymentInfoEntity> GetEmploymentInfoByUserIdAsync(string userId)
        {
            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(userId);

            EmploymentInfoEntity employmentInfoEntity = mapper.Map<ApplicationUser, EmploymentInfoEntity>(user);
            employmentInfoEntity.EmployeeStatus = user.EmployeeStatus.ToString();

            Termination termination = await payrollUnitOfWork.EmployeeRepository.GetTerminationByUserIdAsync(userId);
            if (termination != null)
            {
                employmentInfoEntity.TerminationDate = termination.TerminationDate;
                employmentInfoEntity.LastDayWorked = termination.LastDateOfWork;
                employmentInfoEntity.TerminationReason = termination.TerminationReason;
            }
            return employmentInfoEntity;
        }

        private async Task UpdateEmployeeStatusAsync(string userId)
        {
            var employeeContactDetail = await payrollUnitOfWork.EmployeeRepository.GetUserContactByUserIdAsync(userId);
            if (employeeContactDetail == null)
                return;

            var employeeWorkDetail = await payrollUnitOfWork.EmployeeRepository.GetWorkContactByUserIdAsync(userId);
            if (employeeWorkDetail == null)
                return;

            ApplicationUser user = await payrollUnitOfWork.UserRepository.GetByIdAsync(userId);
            user.EmployeeStatus = EmployeeStatus.Active;
            user.CreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.CreatedDateTime = DateTime.UtcNow;
            user.UpdatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.UpdatedDateTime = DateTime.UtcNow;
            await payrollUnitOfWork.UserRepository.Update(user);
        }
    }
}