﻿using Payroll.Data.PayrollContext.UnitOfWork;

namespace Payroll.Services.PayrollServices.Services
{
    public class EarningDeductionService
    {
        private readonly IPayrollUnitOfWork payrollUnitOfWork;

        public EarningDeductionService(IPayrollUnitOfWork payrollUnitOfWork)
        {
            this.payrollUnitOfWork = payrollUnitOfWork;
        }
    }
}