﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Payroll.Data.AutoMapper;
using Payroll.Data.IdentityRepository;
using Payroll.Data.MasterContext;
using Payroll.Data.MasterContext.Contracts;
using Payroll.Data.MasterContext.Repository;
using Payroll.Data.MasterContext.UnitOfWork;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext;
using Payroll.Data.PayrollContext.Contracts;
using Payroll.Data.PayrollContext.Repository;
using Payroll.Data.PayrollContext.UnitOfWork;
using Payroll.Data.Seed;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Services.MasterServices.Services;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Services.PayrollServices.Services;
using Payroll.Utils.Auth;
using Payroll.Utils.Cache;
using System;

namespace Payroll.Services.ServiceExtensions
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddDbContextService(this IServiceCollection services, string connectionString)
        {
            return services
                .AddDbContext<MasterDbContext>(options => options.UseSqlServer(connectionString))
                .AddDbContext<PayrollDbContext>();
        }

        public static IServiceCollection AddServices(this IServiceCollection services) =>
            services
            .AddScoped<ISeeder, Seed>()
                .AddTransient<ILoginResponseCache, LoginResponseCache>()
                .AddTransient<IOtpCache, OtpCache>()
                .AddTransient<ITokenManager, TokenManager>()
                .AddTransient<IUserService, UserService>()
                .AddTransient<IJwtFactory, JwtFactory>()
                .AddTransient<IMailService, MailService>()
                .AddTransient<ITenantService, TenantService>()
                .AddTransient<IMasterUserService, MasterUserService>()
                .AddTransient<IPayrollUnitOfWork, PayrollUnitOfWork>()
                .AddTransient<IMasterUnitOfWork, MasterUnitOfWork>()
                .AddTransient<ISmsService, SmsService>()
                .AddTransient<ITenantSeed, TeanantSeed>()
                .AddTransient<IGraphService, GraphService>()
                .AddTransient<ITenantSeed, TeanantSeed>()
                .AddTransient<IEmployerService, EmployerService>()
              .AddTransient<IEmployeeService, EmployeeService>()
              .AddTransient<IEarningDeductionService, IEarningDeductionService>();

        public static IServiceCollection AddRepository(this IServiceCollection services) =>
            services
                .AddTransient<IUserRepository, UserRepository>()
                .AddTransient<IMasterRepository, MasterRepository>()
                .AddTransient<ITenantDetailsRepository, TenantDetailsRepository>()
                .AddTransient<IIdentityUserRepository<ApplicationUser>, IdentityUserRepository<ApplicationUser>>()
                .AddTransient<IIdentityUserRepository<ApplicationTenantUsers>, IdentityUserRepository<ApplicationTenantUsers>>()
                .AddTransient<IEmployerRepository, EmployerRepository>()
                .AddTransient<IPayFrequencyRepository, PayFrequencyRepository>()
                .AddTransient<IBankAccountRepository, BankAccountRepository>()
                .AddTransient<IEmployeeRepository, EmployeeRepository>()
                .AddTransient<IEarningDeductionRepository, EarningDeductionRepository>();

        public static IServiceCollection AddSwagger(this IServiceCollection services)
        {
            var contact = new OpenApiContact()
            {
                Name = "Payroll System",
                Email = "test123@gmail.com",
                Url = new Uri("http://www.example.com")
            };

            var license = new OpenApiLicense()
            {
                Name = "License By Payroll System..",
                Url = new Uri("http://www.example.com")
            };

            var info = new OpenApiInfo()
            {
                Version = "V1.0",
                Title = "Payroll System API",
                Description = "Payroll System Api Description",
                TermsOfService = new Uri("http://www.example.com"),
                Contact = contact,
                License = license
            };
            return services.AddSwaggerGen(sw =>
            {
                sw.SwaggerDoc("V1.0", info);
            });
        }

        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            // Auto Mapper Configurations
            var config = new global::AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new DataEntityMappingProfile());
                cfg.AddProfile(new PayrollDbMappingProfile());
            });

            services.AddSingleton(config.CreateMapper());

            //var payrollConfig = new global::AutoMapper.MapperConfiguration(cfg =>
            //{
            //    cfg.AddProfile(new PayrollDbMappingProfile());
            //});

            //services.AddSingleton(payrollConfig.CreateMapper());
            return services;
        }
    }
}