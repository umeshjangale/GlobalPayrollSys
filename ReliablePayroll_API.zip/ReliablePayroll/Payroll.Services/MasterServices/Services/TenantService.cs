﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Payroll.Data.MasterContext.UnitOfWork;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Utils.Cache;

namespace Payroll.Services.MasterServices.Services
{
    public class TenantService : ITenantService
    {
        private readonly IMasterUnitOfWork masterUnitOfWork;
        private readonly ILogger<TenantService> logger;
        private readonly IMapper mapper;
        private readonly ILoginResponseCache loginResponseCache;

        public TenantService(IMasterUnitOfWork masterUnitOfWork, ILogger<TenantService> logger,
            ILoginResponseCache loginResponseCache, IMapper mapper)
        {
            this.masterUnitOfWork = masterUnitOfWork;
            this.logger = logger;
            this.loginResponseCache = loginResponseCache;
            this.mapper = mapper;
        }
    }
}