﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Payroll.Data.MasterContext.UnitOfWork;
using Payroll.Data.Models.MasterDataModels;
using Payroll.Data.Models.PayrollDataModels;
using Payroll.Data.PayrollContext;
using Payroll.Entities;
using Payroll.Entities.Constants;
using Payroll.Entities.Login;
using Payroll.Entities.MailSetting;
using Payroll.Entities.MasterEntity;
using Payroll.Entities.PayrollEntity;
using Payroll.Services.MasterServices.Contracts;
using Payroll.Services.PayrollServices.Contracts;
using Payroll.Utils.Auth;
using Payroll.Utils.Cache;
using Payroll.Utils.Exceptions;
using Payroll.Utils.ExtensionMethods;
using Payroll.Utils.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Payroll.Services.MasterServices.Services
{
    public class MasterUserService : IMasterUserService
    {
        private readonly IMasterUnitOfWork masterUnitOfWork;
        private readonly ILogger<MasterUserService> logger;
        private readonly IMapper mapper;
        private readonly IJwtFactory jwtFactory;
        private readonly IMailService mailService;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ILoginResponseCache loginResponseCache;
        private readonly AngularWebServerSettings webServerSettings;
        private readonly ITenantSeed tenantSeed;

        public MasterUserService(IMasterUnitOfWork masterUnitOfWork, ILogger<MasterUserService> logger,
            ILoginResponseCache loginResponseCache, IMapper mapper,
            IJwtFactory jwtFactory, IOptions<AngularWebServerSettings> options,
            IMailService mailService, IHttpContextAccessor httpContextAccessor,
            ITenantSeed tenantSeed)
        {
            this.masterUnitOfWork = masterUnitOfWork;
            this.logger = logger;
            this.mapper = mapper;
            this.jwtFactory = jwtFactory;
            this.mailService = mailService;
            this.httpContextAccessor = httpContextAccessor;
            this.loginResponseCache = loginResponseCache;
            this.webServerSettings = options.Value;
            this.tenantSeed = tenantSeed;
        }

        public async Task<LoginResponse> LoginAsync(LoginEntity loginModel, string userId)
        {
            ApplicationTenantUsers user = await masterUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(loginModel.UserName);

            if (!await masterUnitOfWork.IdentityUsersRepository.CheckUserPasswordAsync(user, loginModel.Password))
                throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidCredentials");

            if (String.IsNullOrWhiteSpace(userId))
            {
                await SendOtpAsync(user);
                return new LoginResponse
                {
                    AuthToken = null,
                    RefreshToken = jwtFactory.GenerateRefreshTokenAsync()
                };
            }

            return await CreateToken(user, loginModel.CompanyCode);
        }

        private async Task<LoginResponse> CreateToken(ApplicationTenantUsers user, string companyCode)
        {
            IEnumerable<string> roles = await masterUnitOfWork.IdentityUsersRepository.GetUserRolesAsync(user);
            IEnumerable<string> features = await masterUnitOfWork.MasterUsersRepository.GetFeaturesByRoleAsync(await GetUserRoleId(roles.FirstOrDefault()));
            ClaimsIdentity claimsIdentity = await jwtFactory.GenerateClaimsIdentity(user.UserName, user.Id, roles, companyCode, features);

            LoginResponse loginResponse = new LoginResponse
            {
                AuthToken = jwtFactory.GenerateEncodedTokenAsync(claimsIdentity),
                RefreshToken = jwtFactory.GenerateRefreshTokenAsync()
            };

            loginResponseCache.Add(user.Id, loginResponse);
            return loginResponse;
        }

        public async Task<LoginResponse> LoginWithOtpAsync(OtpEntity loginModel)
        {
            ApplicationTenantUsers user = await masterUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(loginModel.UserName);

            OtpInfo otpInfo = await masterUnitOfWork.MasterUsersRepository.GetOtpAsync(user.Id);

            if (DateTime.UtcNow.Subtract(otpInfo.SentDateTine).TotalMinutes > 10)
                throw new ServiceException(HttpStatusCode.BadRequest, "OtpExpired");

            if (loginModel.Otp != otpInfo.OtpCode)
                throw new ServiceException(HttpStatusCode.Unauthorized, "InvalidOtp");

            await masterUnitOfWork.MasterUsersRepository.InActiveUserOtpAsync(user.Id);

            return await CreateToken(user, loginModel.CompanyCode);
        }

        public async Task<bool> VerifyUserAsync(string UserName)
        {
            var userByName = await masterUnitOfWork.IdentityUsersRepository.IsUserExistAsync(UserName);
            return userByName != null;
        }

        private async Task AddSubcriptionDetailsAsync(string userId, Guid subscriptionId)
        {
            var tenant = await masterUnitOfWork.TenantDetailsRepository.AddAsync(new Tenant
            {
                CreatedOn = DateTime.UtcNow,
                ConnectionString = "",
                IsActive = true,
                UserId = userId
            });
            await masterUnitOfWork.TenantDetailsRepository.AddCompanySubscriptionDetails(new CompanySubscription
            {
                UserId = userId,
                SubscriptionId = subscriptionId,
                TenantId = tenant.TenantId,
                StartDateTime = DateTime.UtcNow,
                ExpiryDateTime = DateTime.MinValue
            });
            await masterUnitOfWork.SaveChangesAsync();
        }

        public async Task<bool> SignUpUserAsync(MasterSignupEntity signup)
        {
            ApplicationTenantUsers user = mapper.Map<MasterSignupEntity, ApplicationTenantUsers>(signup);
            user.IsActive = true;

            IdentityResult identityResult = await masterUnitOfWork.IdentityUsersRepository.CreateUserAsync(user, signup.Password);

            if (!identityResult.Succeeded)
            {
                throw new ServiceException(HttpStatusCode.BadRequest, $"UserNotCreated. Error: {String.Join(", ", identityResult)}");
            }

            user = await masterUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(user.UserName);
            await AddPaymentStatusAsync(signup, user.Id);

            await masterUnitOfWork.IdentityUsersRepository.AddUserToRoleAsync(user, Roles.Employer);
            await AddSubcriptionDetailsAsync(user.Id, signup.SubscriptionId);

            await SendEmailForSubscriptionInfoAsync(signup);
            return identityResult.Succeeded;
        }

        public async Task<IEnumerable<ApplicationTenantUsers>> GetUsersList()
        {
            return await masterUnitOfWork.MasterUsersRepository.GetAllAsync();
        }

        public async Task<bool> ChangeUserPasswordAsync(ResetPasswordModel resetPassword)
        {
            var userName = httpContextAccessor.HttpContext.User.Identity.Name;
            var result = await masterUnitOfWork.IdentityUsersRepository.ChangeUserPasswordAsync(userName, resetPassword.CurrentPassword, resetPassword.NewPassword);
            if (!result.Succeeded)
                throw new ServiceException(HttpStatusCode.NotModified, "PasswordMissmatch");

            return result.Succeeded;
        }

        public async Task<bool> ResetUserPasswordAsync(ForgotPasswordModel forgotPassword)
        {
            var user = await masterUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(forgotPassword.UserName);
            if (user == null)
                throw new ServiceException(HttpStatusCode.NotFound, "UserNotFound");

            var otpInfo = await masterUnitOfWork.MasterUsersRepository.GetOtpAsync(user.Id);

            if (DateTime.UtcNow.Subtract(otpInfo.SentDateTine).TotalMinutes > 10)
                throw new ServiceException(HttpStatusCode.InternalServerError, "OtpExpired");

            if (otpInfo.OtpCode != forgotPassword.Otp)
                throw new ServiceException(HttpStatusCode.InternalServerError, "InvalidOtp");

            bool result = await masterUnitOfWork.IdentityUsersRepository.ResetUserPasswordAsync(user, forgotPassword.NewPassword);
            if (!result)
                throw new ServiceException(HttpStatusCode.Unauthorized, "PasswordNotReset");

            await masterUnitOfWork.SaveChangesAsync();

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll Master - Reset Password",
                HtmlBody = String.Format("{0} Dear {1},<br><br> Your password has been changed succesfully.<br><br>" +
            "Login with new password..please click below link to login <br><br> <a href='{2}' {3}>Login</a> " +
            "<br><br><br> Thank you <br> Team Payroll", EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName), webServerSettings.WebUrl, EmailConstants.ButtonStyle)
            };
            await mailService.SendMailAsync(email);
            return true;
        }

        private async Task SendOtpAsync(ApplicationTenantUsers user)
        {
            string userOtp = GenerateNewOtp.GetRandomOtpNumber(10000, 99999);
            await masterUnitOfWork.MasterUsersRepository.InActiveUserOtpAsync(user.Id);
            OtpInfo otpInfo = new OtpInfo
            {
                OtpCode = userOtp,
                SentDateTine = DateTime.UtcNow,
                IsActive = true,
                UserId = user.Id
            };
            await masterUnitOfWork.MasterUsersRepository.AddOtpAsync(otpInfo);
            await masterUnitOfWork.SaveChangesAsync();

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll System - One Time Password",
                HtmlBody = String.Format("{0} Dear {1}, <br><br> Please enter OTP to reset your password: <b>{2}</b> <br><br><br> Thank you <br> Team Payroll", EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName), userOtp)
            };
            await mailService.SendMailAsync(email);
        }

        public async Task SendOtpAsync(string userName)
        {
            ApplicationTenantUsers user = await masterUnitOfWork.IdentityUsersRepository.FindUserByNameAsync(userName);
            await SendOtpAsync(user);
        }

        public async Task<IEnumerable<SubscriptionEntity>> GetSubscriptionAsync()
        {
            IEnumerable<Subscription> subscriptions = await masterUnitOfWork.MasterUsersRepository.GetSubscriptionAsync();
            return mapper.Map<IEnumerable<Subscription>, IEnumerable<SubscriptionEntity>>(subscriptions);
        }

        public async Task<IEnumerable<RoleEntity>> GetRolesAsync()
        {
            IEnumerable<IdentityRole> roles = await masterUnitOfWork.MasterUsersRepository.GetRolesAsync();
            roles = roles.Where(it => it.Name != Roles.Admin);
            return mapper.Map<IEnumerable<IdentityRole>, IEnumerable<RoleEntity>>(roles);
        }

        public async Task<IEnumerable<EmployersEntityModel>> GetEmployersAsync(EmployerSearchModel employerSearchModel)
        {
            List<ApplicationTenantUsers> users = await masterUnitOfWork.MasterUsersRepository.GetEmployerAsync(employerSearchModel);
            return mapper.Map<IEnumerable<ApplicationTenantUsers>, IEnumerable<EmployersEntityModel>>(users);
        }

        public async Task AddCompanyCodeAsync(string userId)
        {
            ApplicationTenantUsers user = await masterUnitOfWork.MasterUsersRepository.GetByIdAsync(userId);
            if (user == null)
                throw new ServiceException(HttpStatusCode.NotFound, "UserNotFound");

            var companyCodeIdentity = await masterUnitOfWork.MasterUsersRepository.GetCompanyCodeIdentity();
            
            string companyCode = string.Concat(user.CompanyName.ToUpper().Substring(0, user.CompanyName.Length >= 3 ? 3 : user.CompanyName.Length), companyCodeIdentity);

            user.CompanyCode = companyCode;
            user.CompanyCreatedBy = httpContextAccessor.HttpContext.User.GetLoggedInUserId();
            user.CompanyCreatedDateTime = DateTime.UtcNow;
            user.CompanyCodeIdentity = companyCodeIdentity;

            await masterUnitOfWork.MasterUsersRepository.Update(user);
            await masterUnitOfWork.SaveChangesAsync();

            await CreateMigrationForPayrollAsync(companyCode, user);

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll System - User Registration",
                HtmlBody = String.Format("{0} Dear {1},<br><br> We have created your company. Details are as below<br><br>" +
                                         "Your UserName : {2} and <br> Company code : {3} <br><br>" + "For login click on link below :<br>" +
                                         "<a href='{4}' {5}>Login</a><br><br><br> Thank you <br> Team Payroll",
                                         EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName),
                                         user.UserName, companyCode, webServerSettings.WebUrl, EmailConstants.ButtonStyle)
            };
            await mailService.SendMailAsync(email);
        }

        private async Task CreateMigrationForPayrollAsync(string companyCode, ApplicationTenantUsers masterUser)
        {
            var subscription = await masterUnitOfWork.TenantDetailsRepository.GetCompanySubscriptionByUserId(masterUser.Id);
            IEnumerable<Feature> feature = await masterUnitOfWork.MasterUsersRepository.GetFeaturesBySubscriptionIdAsync(subscription.SubscriptionId);

            IEnumerable<TenantFeature> tenantFeatures = mapper.Map<IEnumerable<Feature>, IEnumerable<TenantFeature>>(feature);
            ApplicationUser user = mapper.Map<ApplicationTenantUsers, ApplicationUser>(masterUser);
            user.EmployeeStatus = EmployeeStatus.Active;
            await tenantSeed.MigrationAsync(companyCode, tenantFeatures);
            await tenantSeed.AddDefaultUserAsync(user);

            // get role & associate features
            var role = await GetRolesAsync();
            Guid roleId = Guid.Parse(role.FirstOrDefault(it => it.RoleName == Roles.Employer).RoleId);
            var roleFeatures = await masterUnitOfWork.MasterUsersRepository.GetRoleFeaturesBySubscriptionIdAsync(subscription.SubscriptionId);

            IEnumerable<UserRoleFeature> employerFeature = mapper.Map<IEnumerable<RoleFeature>, IEnumerable<UserRoleFeature>>(
                                     roleFeatures.Where(it => it.RoleId == roleId).ToList());

            roleId = Guid.Parse(role.FirstOrDefault(it => it.RoleName == Roles.Employee).RoleId);

            var employeeFeature = mapper.Map<IEnumerable<RoleFeature>, IEnumerable<UserRoleFeature>>(
                                     roleFeatures.Where(it => it.RoleId == roleId).ToList());

            await tenantSeed.AddRoleFeatureAsync(employerFeature.ToList(), employeeFeature.ToList());
        }

        public async Task<bool> CheckCompanyCodeExistAsync(string companyCode)
        {
            return await masterUnitOfWork.MasterUsersRepository.CheckCompanyCodeExistAsync(companyCode.ToUpper());
        }

        public async Task<IEnumerable<FeatureEntity>> GetFeaturesBySubscriptionAndRoleAsync(Guid subscriptionId, Guid roleId)
        {
            IEnumerable<Feature> features = await masterUnitOfWork.MasterUsersRepository.GetFeaturesBySubscriptionAndRoleAsync(subscriptionId, roleId);
            return mapper.Map<IEnumerable<Feature>, IEnumerable<FeatureEntity>>(features);
        }

        private async Task<Guid> GetUserRoleId(string roleName)
        {
            IdentityRole role = await masterUnitOfWork.IdentityUsersRepository.FindRoleByNameAsync(roleName);
            return Guid.Parse(role.Id);
        }

        private async Task AddPaymentStatusAsync(MasterSignupEntity signup, string userId)
        {
            CompanyPayment companyPayment = mapper.Map<MasterSignupEntity, CompanyPayment>(signup);
            companyPayment.UserId = userId;
            companyPayment.PaymentStatus = PaymentStatus.Paid.ToString();

            await masterUnitOfWork.TenantDetailsRepository.AddPaymentStatusAsync(companyPayment);
            await masterUnitOfWork.SaveChangesAsync();
        }

        private async Task SendEmailForSubscriptionInfoAsync(MasterSignupEntity user)
        {
            Subscription subscription = await masterUnitOfWork.MasterUsersRepository.GetSubscriptionInfoAsync(user.SubscriptionId);

            string table = String.Format("<table border=1 style='margin:auto; width:300px;'>" +
                                         "<caption style='background-color:#007bff;color:white;'> Order Information</caption>");

            table += String.Format("<tbody> <tr><td> Date of purchase </td> <td> {0} </td></tr>" +
                                   "<tr><td> Payment Reference Number </td> <td> {1} </td></tr>" +
                                   "<tr><td> Bussniess Name </td> <td> {2} </td></tr>" +
                                   "<tr><td> Subscription Plan </td> <td> {3} </td></tr>" +
                                   "<tr><td> Total Amount </td> <td> ${4} </td></tr>" +
                                   "</tbody></table>",
                                   DateTime.UtcNow.Date, user.ReferenceNumber, user.CompanyName, subscription.SubscriptionName, user.Amount);

            Email email = new Email
            {
                ToAddress = user.Email,
                Subject = "Payroll System - User Registration",
                HtmlBody = String.Format("{0} Dear {1}, <br><br> Thank you for your purchase!<br> We appreciate that you have choosen Global Payroll System. " +
                                         "Please find the purchase details in the table below.<br><br> {2} <br>" +
                                         "If you have any questions or need any support at all, please email us at<br>" +
                                         "<p>{3}</p> <br><br><br> Thank you <br> Team Payroll",
                                         EmailConstants.CompanyLogo, ExtensionMethods.UppercaseFirst(user.FirstName), table, "testemail@payroll.com")
            };
            await mailService.SendMailAsync(email);
        }

        public async Task<LoggedInUserEntity> GetUserAsync()
        {
            ApplicationTenantUsers user = await masterUnitOfWork.MasterUsersRepository.GetByIdAsync(httpContextAccessor.HttpContext.User.GetLoggedInUserId());
            return mapper.Map<ApplicationTenantUsers, LoggedInUserEntity>(user);
        }
    }
}