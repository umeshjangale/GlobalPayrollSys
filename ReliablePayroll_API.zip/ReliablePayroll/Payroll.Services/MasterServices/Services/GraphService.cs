﻿using Microsoft.Extensions.Logging;
using Payroll.Data.MasterContext.UnitOfWork;
using Payroll.Entities.Constants;
using Payroll.Entities.MasterEntity;
using Payroll.Services.MasterServices.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Payroll.Services.MasterServices.Services
{
    public class GraphService : IGraphService
    {
        private readonly IMasterUnitOfWork masterUnitOfWork;
        private readonly ILogger<GraphService> logger;

        public GraphService(IMasterUnitOfWork masterUnitOfWork, ILogger<GraphService> logger)
        {
            this.masterUnitOfWork = masterUnitOfWork;
            this.logger = logger;
        }

        public async Task<EmployerGraph> GetEmployerGraphCountAsync()
        {
            DateTime firstDayOfMonth = new DateTime(DateTime.UtcNow.AddMonths(-1).Year, DateTime.UtcNow.AddMonths(-1).Month, 1);
            DateTime lastDayOfMonth = new DateTime(DateTime.UtcNow.AddMonths(-1).Year, DateTime.UtcNow.Month, 1);

            var totalEmployers = await masterUnitOfWork.IdentityUsersRepository.GetUsersInRoleAsync(Roles.Employer);
            var companyPayments = await masterUnitOfWork.TenantDetailsRepository.GetPaymentAsync();

            var employerGraph = new EmployerGraph
            {
                TotalEmployer = totalEmployers.Where(i => i.IsActive).Count(),
                LatestEmployer = totalEmployers.Where(i => i.CreatedDateTime >= firstDayOfMonth && i.CreatedDateTime < lastDayOfMonth && i.IsActive).Count(),
                TotalAmount = companyPayments.Where(i => Equals(i.PaymentStatus, PaymentStatus.Paid.ToString()) && i.IsRefund == false)
                                              .Select(i => i.Amount).Sum()
            };
            return employerGraph;
        }

        public async Task<IEnumerable<EmployerTrendsGraph>> GetEmployerTrendsGraphCountAsync()
        {
            var totalEmployers = await masterUnitOfWork.IdentityUsersRepository.GetUsersInRoleAsync(Roles.Employer);
            var companyPayments = await masterUnitOfWork.TenantDetailsRepository.GetPaymentAsync();

            return totalEmployers.Where(it => it.IsActive).GroupBy(it => it.CreatedDateTime.Year)
                                .Select(result => new EmployerTrendsGraph
                                {
                                    Year = result.Key,
                                    TotalEmployer = result.Count(),
                                    TotalAmount = companyPayments.Where(i => i.PaymentDate.Year == result.Key &&
                                                                  Equals(i.PaymentStatus, PaymentStatus.Paid.ToString()) && i.IsRefund == false)
                                                                 .Select(i => i.Amount).Sum()
                                });
        }
    }
}