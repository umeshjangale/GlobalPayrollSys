﻿namespace Payroll.Services.MasterServices.Contracts
{
    public interface ITenantService
    {
    }
}