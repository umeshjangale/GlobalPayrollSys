﻿using Payroll.Entities.MasterEntity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Services.MasterServices.Contracts
{
    public interface IGraphService
    {
        Task<EmployerGraph> GetEmployerGraphCountAsync();

        Task<IEnumerable<EmployerTrendsGraph>> GetEmployerTrendsGraphCountAsync();
    }
}