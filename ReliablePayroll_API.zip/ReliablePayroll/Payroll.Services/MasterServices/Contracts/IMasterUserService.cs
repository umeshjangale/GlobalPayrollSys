﻿using Payroll.Data.Models.MasterDataModels;
using Payroll.Entities;
using Payroll.Entities.Login;
using Payroll.Entities.MasterEntity;
using Payroll.Entities.PayrollEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Payroll.Services.MasterServices.Contracts
{
    public interface IMasterUserService
    {
        Task<LoginResponse> LoginAsync(LoginEntity loginModel, string userId);

        Task<LoginResponse> LoginWithOtpAsync(OtpEntity loginModel);

        Task<bool> ChangeUserPasswordAsync(ResetPasswordModel resetPasswordModel);

        Task<bool> ResetUserPasswordAsync(ForgotPasswordModel forgotPassword);

        Task<bool> VerifyUserAsync(string UserName);

        Task<bool> SignUpUserAsync(MasterSignupEntity signupModel);

        Task<IEnumerable<ApplicationTenantUsers>> GetUsersList();

        Task SendOtpAsync(string userName);

        Task<IEnumerable<SubscriptionEntity>> GetSubscriptionAsync();

        Task<IEnumerable<EmployersEntityModel>> GetEmployersAsync(EmployerSearchModel employerSearchModel);

        Task<IEnumerable<RoleEntity>> GetRolesAsync();

        Task AddCompanyCodeAsync(string userId);

        Task<bool> CheckCompanyCodeExistAsync(string companyCode);

        Task<IEnumerable<FeatureEntity>> GetFeaturesBySubscriptionAndRoleAsync(Guid subscriptionId, Guid roleId);

        Task<LoggedInUserEntity> GetUserAsync();

    }
}